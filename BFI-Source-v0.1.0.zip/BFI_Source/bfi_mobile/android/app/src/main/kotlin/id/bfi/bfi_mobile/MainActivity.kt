package id.bfi.bfi_mobile

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Intent
import android.app.Activity

class MainActivity : FlutterActivity() {
    private var pendingResult: MethodChannel.Result? = null
    private var pendingText: String? = null
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "id.bfi/files").setMethodCallHandler { call, result ->
            if (call.method != "saveCsv") { result.notImplemented(); return@setMethodCallHandler }
            if (pendingResult != null) { result.error("BUSY", "Ekspor lain masih terbuka", null); return@setMethodCallHandler }
            pendingText = call.argument<String>("content") ?: ""
            pendingResult = result
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/csv"
                putExtra(Intent.EXTRA_TITLE, call.argument<String>("name") ?: "BFI.csv")
            }
            try { startActivityForResult(intent, 8101) }
            catch (e: Exception) { pendingResult = null; pendingText = null; result.error("EXPORT", e.message, null) }
        }
    }
    @Deprecated("Activity callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 8101) return
        val result = pendingResult
        try {
            if (resultCode == Activity.RESULT_OK && data?.data != null) {
                val stream = contentResolver.openOutputStream(data.data!!) ?: throw IllegalStateException("Penyimpanan tidak tersedia")
                stream.use { it.write(("\uFEFF" + (pendingText ?: "")).toByteArray(Charsets.UTF_8)) }
                result?.success(true)
            } else result?.success(false)
        } catch (e: Exception) { result?.error("EXPORT", e.message, null) }
        finally { pendingResult = null; pendingText = null }
    }
}
