import 'dart:math' as math;

import 'package:flutter/material.dart';

const navy = Color(0xff092e38),
    teal = Color(0xff00796f),
    ice = Color(0xfff2f7fa),
    muted = Color(0xff607780),
    amber = Color(0xffa66213),
    red = Color(0xffb53d42);
const palette = [
  teal,
  navy,
  Color(0xff77b5be),
  Color(0xffd8a85d),
  Color(0xff96a5c7),
  Color(0xffd98689),
];
String money(num n) {
  final v = n.round();
  final s = v.abs().toString().replaceAllMapped(
        RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
        (m) => '${m[1]}.',
      );
  return '${v < 0 ? '−' : ''}Rp$s';
}

String shortMoney(num n) => n.abs() >= 1000000
    ? '${(n / 1000000).toStringAsFixed(1).replaceAll('.', ',')} jt'
    : money(n);
String percent(double? n) =>
    n == null ? 'N/A' : '${n.toStringAsFixed(1).replaceAll('.', ',')}%';
const monthNames = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'Mei',
  'Jun',
  'Jul',
  'Agu',
  'Sep',
  'Okt',
  'Nov',
  'Des',
];
String period(DateTime d) => '${monthNames[d.month - 1]} ${d.year}';
TextStyle numbers(double size, {Color color = navy}) => TextStyle(
      fontSize: size,
      fontWeight: FontWeight.w700,
      color: color,
      letterSpacing: -0.5,
      fontFeatures: const [FontFeature.tabularFigures()],
    );

class Panel extends StatelessWidget {
  final Widget child;
  final bool dark;
  final EdgeInsets? padding;
  const Panel({
    super.key,
    required this.child,
    this.dark = false,
    this.padding,
  });
  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        child: Material(
          color: dark ? navy : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: BorderSide(color: dark ? navy : const Color(0xffe5edf0)),
          ),
          child: Padding(
              padding: padding ?? const EdgeInsets.all(20), child: child),
        ),
      );
}

class Label extends StatelessWidget {
  final String text;
  final Color color;
  const Label(this.text, {super.key, this.color = muted});
  @override
  Widget build(BuildContext context) => Text(
        text,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
          color: color,
        ),
      );
}

class MoneyRow extends StatelessWidget {
  final String label;
  final num value;
  final bool bold;
  final Color? color;
  const MoneyRow(
    this.label,
    this.value, {
    super.key,
    this.bold = false,
    this.color,
  });
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: muted,
                  fontSize: 14,
                  fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Flexible(
              child: Text(
                money(value),
                textAlign: TextAlign.right,
                style: numbers(bold ? 17 : 14, color: color ?? navy),
              ),
            ),
          ],
        ),
      );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final Widget? action;
  const SectionTitle(this.title, {super.key, this.action});
  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.4,
              ),
            ),
          ),
          if (action != null) action!,
        ],
      );
}

void explain(BuildContext context, String title, String text) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (c) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, style: Theme.of(c).textTheme.headlineSmall),
            const SizedBox(height: 16),
            SelectableText(text, style: const TextStyle(height: 1.6)),
            const SizedBox(height: 12),
          ],
        ),
      ),
    ),
  );
}

class Ring extends StatelessWidget {
  final double? value;
  final String center, label, detail;
  final double maximum;
  final Color color;
  const Ring({
    super.key,
    required this.value,
    required this.center,
    required this.label,
    required this.detail,
    this.maximum = 100,
    this.color = teal,
  });
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => explain(context, label, detail),
        child: Semantics(
          label: '$label: $center. $detail',
          child: Column(
            children: [
              SizedBox(
                width: 112,
                height: 112,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 96,
                      height: 96,
                      child: CircularProgressIndicator(
                        value:
                            value == null ? 0 : (value! / maximum).clamp(0, 1),
                        strokeWidth: 8,
                        strokeCap: StrokeCap.round,
                        backgroundColor: const Color(0xffe6eff0),
                        color: color,
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(center, style: numbers(27, color: color)),
                        Text(
                          value == null
                              ? 'belum dinilai'
                              : 'dari ${maximum.toInt()}',
                          style: const TextStyle(fontSize: 12, color: muted),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 4),
              const Text(
                'Lihat perhitungan',
                style: TextStyle(fontSize: 12, color: muted),
              ),
            ],
          ),
        ),
      );
}

class Breakdown extends StatelessWidget {
  final Map<String, int> data;
  final String title, meta;
  const Breakdown({
    super.key,
    required this.data,
    required this.title,
    required this.meta,
  });
  @override
  Widget build(BuildContext context) {
    final total = data.values.fold<int>(0, (a, b) => a + b);
    final valid = total > 0 && data.values.every((n) => n >= 0);
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionTitle(
            title,
            action: IconButton(
              tooltip: 'Formula dan tabel',
              onPressed: () => explain(
                context,
                title,
                '$meta\n\n' +
                    data.entries
                        .map(
                          (e) =>
                              '${e.key}: ${money(e.value)} (${total == 0 ? 'N/A' : percent(e.value / total * 100)})',
                        )
                        .join('\n'),
              ),
              icon: const Icon(Icons.info_outline, size: 19),
            ),
          ),
          Text(meta, style: const TextStyle(fontSize: 12, color: muted)),
          const SizedBox(height: 20),
          if (valid)
            Center(
              child: SizedBox(
                width: 150,
                height: 150,
                child: CustomPaint(
                  painter: _Donut(data.values.toList()),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Label('TOTAL'),
                        Text(shortMoney(total), style: numbers(22)),
                      ],
                    ),
                  ),
                ),
              ),
            )
          else
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Belum ada komposisi positif. Lihat nilai pada tabel.',
              ),
            ),
          const SizedBox(height: 18),
          ...data.entries.toList().asMap().entries.map(
                (e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Container(
                        width: 9,
                        height: 9,
                        decoration: BoxDecoration(
                          color: palette[e.key % palette.length],
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          e.value.key,
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                      Text(
                        '${money(e.value.value)}  ·  ${total > 0 ? percent(e.value.value / total * 100) : 'N/A'}',
                        style: numbers(12),
                      ),
                    ],
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

class _Donut extends CustomPainter {
  final List<int> values;
  _Donut(this.values);
  @override
  void paint(Canvas canvas, Size size) {
    double angle = -math.pi / 2;
    final total = values.fold<int>(0, (a, b) => a + b);
    for (int i = 0; i < values.length; i++) {
      final sweep = values[i] / total * 2 * math.pi;
      canvas.drawArc(
        Rect.fromLTWH(10, 10, size.width - 20, size.height - 20),
        angle,
        sweep - 0.015,
        false,
        Paint()
          ..color = palette[i % palette.length]
          ..style = PaintingStyle.stroke
          ..strokeWidth = 16,
      );
      angle += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _Donut old) => true;
}

class Trend extends StatelessWidget {
  final String title, meta;
  final List<int> values;
  final List<String> labels;
  const Trend({
    super.key,
    required this.title,
    required this.meta,
    required this.values,
    required this.labels,
  });
  @override
  Widget build(BuildContext context) => Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionTitle(
              title,
              action: IconButton(
                tooltip: 'Tabel tren',
                onPressed: () => explain(
                  context,
                  title,
                  '$meta\n' +
                      List.generate(
                        values.length,
                        (i) => '${labels[i]}: ${money(values[i])}',
                      ).join('\n'),
                ),
                icon: const Icon(Icons.table_chart_outlined, size: 19),
              ),
            ),
            Text(meta, style: const TextStyle(fontSize: 12, color: muted)),
            const SizedBox(height: 16),
            SizedBox(
              height: 116,
              width: double.infinity,
              child: CustomPaint(painter: _Line(values)),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: labels
                  .map(
                    (l) => Text(l,
                        style: const TextStyle(fontSize: 12, color: muted)),
                  )
                  .toList(),
            ),
            const SizedBox(height: 8),
            Text('Terakhir ${money(values.last)}', style: numbers(14)),
          ],
        ),
      );
}

class _Line extends CustomPainter {
  final List<int> v;
  _Line(this.v);
  @override
  void paint(Canvas c, Size s) {
    final lo = v.reduce(math.min).toDouble(),
        hi = v.reduce(math.max).toDouble();
    double y(int n) =>
        s.height - 18 - (n - lo) / (hi == lo ? 1 : hi - lo) * (s.height - 36);
    for (int i = 0; i < 3; i++) {
      final dy = 12 + i * (s.height - 24) / 2;
      c.drawLine(
        Offset(0, dy),
        Offset(s.width, dy),
        Paint()
          ..color = const Color(0xffe8eff2)
          ..strokeWidth = 1,
      );
    }
    final path = Path();
    for (int i = 0; i < v.length; i++) {
      final x = 8 + i * (s.width - 16) / (v.length - 1);
      if (i == 0) {
        path.moveTo(x, y(v[i]));
      } else {
        path.lineTo(x, y(v[i]));
      }
    }
    final fill = Path.from(path)
      ..lineTo(s.width - 8, s.height)
      ..lineTo(8, s.height)
      ..close();
    c.drawPath(
      fill,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x3000796f), Color(0x0000796f)],
        ).createShader(Offset.zero & s),
    );
    c.drawPath(
      path,
      Paint()
        ..color = teal
        ..strokeWidth = 3
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round,
    );
    for (int i = 0; i < v.length; i++) {
      c.drawCircle(
        Offset(8 + i * (s.width - 16) / (v.length - 1), y(v[i])),
        3,
        Paint()..color = teal,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _Line old) => true;
}

class ProgressStat extends StatelessWidget {
  final String label;
  final int value, target;
  const ProgressStat(this.label, this.value, this.target, {super.key});
  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MoneyRow(label, value),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: LinearProgressIndicator(
              minHeight: 8,
              value: target <= 0 ? 0 : (value / target).clamp(0, 1),
              backgroundColor: ice,
              color: value > target ? amber : teal,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            'Target ${money(target)} · ${target > 0 ? percent(value / target * 100) : 'N/A'}',
            style: const TextStyle(fontSize: 12, color: muted),
          ),
        ],
      );
}

class Waterfall extends StatelessWidget {
  final List<String> labels;
  final List<int> values;
  final String meta;
  const Waterfall({
    super.key,
    required this.labels,
    required this.values,
    required this.meta,
  });
  @override
  Widget build(BuildContext context) => Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionTitle('Dari penjualan ke laba'),
            const SizedBox(height: 6),
            Text(meta, style: const TextStyle(fontSize: 12, color: muted)),
            const SizedBox(height: 16),
            SizedBox(
              height: 160,
              width: double.infinity,
              child: CustomPaint(painter: _Waterfall(values)),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: labels
                  .map(
                    (l) => Expanded(
                      child: Text(
                        l,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 11, color: muted),
                      ),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 12),
            ...List.generate(
              values.length,
              (i) =>
                  MoneyRow(labels[i], values[i], bold: i == values.length - 1),
            ),
          ],
        ),
      );
}

class _Waterfall extends CustomPainter {
  final List<int> v;
  _Waterfall(this.v);
  @override
  void paint(Canvas c, Size s) {
    final high = math.max(1, v.first.abs()).toDouble();
    final scale = (s.height - 24) / high;
    double running = 0;
    for (int i = 0; i < v.length; i++) {
      final total = i == 0 || i == v.length - 1;
      final start = total ? 0 : running;
      final end = total ? v[i].toDouble() : running + v[i];
      final x = i * s.width / v.length + 8;
      final top = s.height - 12 - math.max(start, end) * scale;
      final height = (end - start).abs() * scale;
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, top, s.width / v.length - 16, math.max(2, height)),
          const Radius.circular(5),
        ),
        Paint()..color = total ? teal : const Color(0xff8ba5ad),
      );
      running = end;
    }
  }

  @override
  bool shouldRepaint(covariant _Waterfall old) => true;
}
