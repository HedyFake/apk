import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../domain/ledger.dart';
import 'store.dart';

class BfiController extends ChangeNotifier {
  final BfiDatabase db;
  final secure = const FlutterSecureStorage();
  String mode = 'demo',
      url = '',
      token = '',
      userId = '',
      entity = 'personal',
      error = '';
  bool busy = false;
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  List<Entry> entries = [];
  List<Map<String, dynamic>> queue = [], audit = [];
  BfiController(this.db);
  bool get demo => mode == 'demo';
  Ledger get ledger => Ledger(entries);
  Future<void> init() async {
    if (await db.getSetting('demo.seeded') == null) {
      await db.append('demo', demoSeed(DateTime.now()), action: 'SEED_DEMO');
      await db.setSetting('demo.seeded', 'true');
    }
    await reload();
  }

  Future<void> reload() async {
    entries = await db.load(mode);
    queue = await db.pending(mode);
    audit = await db.events(mode);
    notifyListeners();
  }

  void selectEntity(String v) {
    entity = v;
    notifyListeners();
  }

  void selectMonth(DateTime v) {
    month = v;
    notifyListeners();
  }

  Future<http.Response> request(
    String path, {
    Map<String, dynamic>? body,
    String? key,
  }) async {
    final uri = Uri.parse('$url/api/v1/$path');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
      if (key != null) 'Idempotency-Key': key,
    };
    final r = body == null
        ? await http
            .get(uri, headers: headers)
            .timeout(const Duration(seconds: 15))
        : await http
            .post(uri, headers: headers, body: jsonEncode(body))
            .timeout(const Duration(seconds: 15));
    if (r.statusCode >= 400) {
      String message = 'Server ${r.statusCode}';
      try {
        final b = jsonDecode(r.body);
        message = b['detail'] ?? b['title'] ?? message;
      } catch (_) {}
      throw Exception(message);
    }
    return r;
  }

  Future<void> connect(
    String base,
    String email,
    String password, {
    bool register = false,
  }) async {
    final u = Uri.tryParse(base.trim());
    if (u == null ||
        u.scheme != 'https' ||
        u.host.isEmpty ||
        u.userInfo.isNotEmpty ||
        u.hasQuery ||
        u.hasFragment)
      throw const FormatException('Gunakan URL server HTTPS yang valid.');
    final oldUrl = url, oldToken = token, oldUser = userId, oldMode = mode;
    url = base.trim().replaceAll(RegExp(r'/+$'), '');
    try {
      final r = await request(
        'auth/${register ? 'register' : 'login'}',
        body: {'email': email.trim(), 'password': password},
      );
      final data = jsonDecode(r.body);
      token = data['token'];
      userId = data['userId'];
      await secure.write(key: 'bfi.token.$userId', value: token);
      mode = 'live:$url:$userId';
      await reload();
      await sync();
    } catch (e) {
      url = oldUrl;
      token = oldToken;
      userId = oldUser;
      mode = oldMode;
      await reload();
      rethrow;
    }
  }

  Future<void> useDemo() async {
    if (userId.isNotEmpty) await secure.delete(key: 'bfi.token.$userId');
    token = '';
    userId = '';
    mode = 'demo';
    await reload();
  }

  Future<String> save(TransactionDraft d) async {
    ledger.validateDraft(d);
    if (demo) {
      await db.append(mode, mapTransaction(d));
      await reload();
      return 'Transaksi DEMO tersimpan. Ledger dan laporan diperbarui.';
    }
    await db.enqueue(mode, d);
    await reload();
    return 'Draft tersimpan di perangkat. Buka antrean dan konfirmasi kirim ke server.';
  }

  Future<void> sync({bool sendDrafts = false}) async {
    if (demo) return;
    busy = true;
    error = '';
    notifyListeners();
    try {
      if (sendDrafts) {
        for (final row in await db.pending(mode)) {
          try {
            final d = TransactionDraft.fromJson(jsonDecode(row['payload']));
            await request('transactions', body: d.toJson(), key: d.id);
            await db.dequeue(d.id);
          } catch (e) {
            await db.queueError(row['id'], e.toString());
          }
        }
      }
      final r = await request('journals');
      final data = jsonDecode(r.body) as List;
      await db.replaceServerCache(
        mode,
        data.map((j) => Entry.fromJson(Map<String, dynamic>.from(j))).toList(),
      );
    } catch (e) {
      error = e.toString();
    } finally {
      busy = false;
      await reload();
    }
  }

  Future<void> reverse(Entry original, String reason) async {
    if (reason.trim().length < 5)
      throw const FormatException(
        'Jelaskan alasan koreksi (minimal 5 karakter).',
      );
    if (original.reverses.isNotEmpty ||
        original.kind == 'opening' ||
        ledger.reversed(original.id))
      throw const FormatException('Jurnal ini tidak dapat dibalik lagi.');
    if (entries.any((e) => e.sourceId == original.id))
      throw const FormatException(
        'Jurnal sudah memiliki pelunasan; koreksi memerlukan review akuntan.',
      );
    if (!demo) {
      await request(
        'journals/${original.id}/reverse',
        body: {'reason': reason},
        key: 'reverse-${original.id}',
      );
      await sync();
      return;
    }
    final source = original.pairId.isEmpty
        ? [original]
        : entries
            .where((e) => e.pairId == original.pairId && e.reverses.isEmpty)
            .toList();
    final reversalPair = source.length > 1 ? uid() : '';
    final reversed = source
        .map(
          (e) => Entry(
            id: uid(),
            entityId: e.entityId,
            date: dateOnly(DateTime.now()),
            description: 'Pembalikan: ${e.description} — $reason',
            kind: 'reversal',
            category: e.category,
            sourceId: e.sourceId,
            pairId: reversalPair,
            reverses: e.id,
            createdAt: DateTime.now().toUtc().toIso8601String(),
            lines: e.lines
                .map((l) => JournalLine(l.account, l.credit, l.debit))
                .toList(),
          ),
        )
        .toList();
    ledger.validateBatch(reversed);
    await db.append(mode, reversed, action: 'REVERSE_DEMO', reason: reason);
    await reload();
  }
}
