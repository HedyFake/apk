import 'dart:convert';
import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';

import '../domain/ledger.dart';

class BfiDatabase extends GeneratedDatabase {
  BfiDatabase(super.executor);
  @override
  int get schemaVersion => 1;
  @override
  Iterable<TableInfo<Table, Object?>> get allTables => [];
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [];
  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await customStatement(
            'CREATE TABLE journals (id TEXT NOT NULL, mode TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(id,mode))',
          );
          await customStatement(
            'CREATE TABLE events (id TEXT PRIMARY KEY, mode TEXT NOT NULL, payload TEXT NOT NULL)',
          );
          await customStatement(
            'CREATE TABLE queue (id TEXT PRIMARY KEY, mode TEXT NOT NULL, payload TEXT NOT NULL, error TEXT NOT NULL DEFAULT \'\')',
          );
          await customStatement(
            'CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)',
          );
        },
      );
  static Future<BfiDatabase> open() async {
    final dir = await getApplicationSupportDirectory();
    return BfiDatabase(
      NativeDatabase.createInBackground(File('${dir.path}/bfi_v1.sqlite')),
    );
  }

  Future<List<Entry>> load(String mode) async => (await customSelect(
        'SELECT payload FROM journals WHERE mode = ? ORDER BY id',
        variables: [Variable(mode)],
      ).get())
          .map((r) => Entry.fromJson(jsonDecode(r.read<String>('payload'))))
          .toList();
  Future<void> append(
    String mode,
    List<Entry> entries, {
    String action = 'POST_DEMO',
    String reason = '',
  }) async {
    await transaction(() async {
      for (final e in entries) {
        e.validate();
        await customStatement(
          'INSERT INTO journals(id,mode,payload) VALUES(?,?,?)',
          [e.id, mode, jsonEncode(e.toJson())],
        );
      }
      await customStatement(
        'INSERT INTO events(id,mode,payload) VALUES(?,?,?)',
        [
          uid(),
          mode,
          jsonEncode({
            'at': DateTime.now().toUtc().toIso8601String(),
            'action': action,
            'actor': 'local-demo-user',
            'reason': reason,
            'entries': entries.map((e) => e.id).toList(),
          }),
        ],
      );
    });
  }

  Future<void> replaceServerCache(String mode, List<Entry> entries) async {
    await transaction(() async {
      await customStatement('DELETE FROM journals WHERE mode=?', [mode]);
      for (final e in entries) {
        e.validate();
        await customStatement(
          'INSERT INTO journals(id,mode,payload) VALUES(?,?,?)',
          [e.id, mode, jsonEncode(e.toJson())],
        );
      }
    });
  }

  Future<List<Map<String, dynamic>>> events(String mode) async =>
      (await customSelect(
        'SELECT payload FROM events WHERE mode=? ORDER BY rowid DESC',
        variables: [Variable(mode)],
      ).get())
          .map(
            (r) => Map<String, dynamic>.from(
              jsonDecode(r.read<String>('payload')),
            ),
          )
          .toList();
  Future<String?> getSetting(String key) async => (await customSelect(
        'SELECT value FROM settings WHERE key=?',
        variables: [Variable(key)],
      ).getSingleOrNull())
          ?.read<String>('value');
  Future<void> setSetting(String key, String value) => customStatement(
        'INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',
        [key, value],
      );
  Future<void> enqueue(String mode, TransactionDraft d) => customStatement(
        'INSERT OR IGNORE INTO queue(id,mode,payload) VALUES(?,?,?)',
        [d.id, mode, jsonEncode(d.toJson())],
      );
  Future<List<Map<String, dynamic>>> pending(String mode) async =>
      (await customSelect(
        'SELECT id,payload,error FROM queue WHERE mode=?',
        variables: [Variable(mode)],
      ).get())
          .map((r) => r.data)
          .toList();
  Future<void> queueError(String id, String error) =>
      customStatement('UPDATE queue SET error=? WHERE id=?', [error, id]);
  Future<void> dequeue(String id) =>
      customStatement('DELETE FROM queue WHERE id=?', [id]);
}

List<Entry> demoSeed(DateTime today) {
  final out = <Entry>[];
  void opening(String entity, String account, int n) {
    out.add(
      Entry(
        id: 'seed-$entity-$account',
        entityId: entity,
        date: dateOnly(DateTime(today.year, today.month - 5, 1)),
        description: 'DEMO • Saldo awal ${accounts[account]}',
        kind: 'opening',
        createdAt: today.toUtc().toIso8601String(),
        lines: [JournalLine(account, n, 0), JournalLine('equity', 0, n)],
      ),
    );
  }

  opening('personal', 'bank', 30000000);
  opening('personal', 'reserve', 18000000);
  opening('personal', 'investment', 25000000);
  opening('household', 'bank', 8000000);
  opening('business', 'bank', 60000000);
  opening('business', 'inventory', 10000000);
  opening('business', 'fixed', 24000000);
  void add(
    String entity,
    String kind,
    int n,
    int month,
    int day,
    String note, {
    String category = 'direct',
    int cost = 0,
  }) {
    final d = TransactionDraft(
      id: 'seed-${out.length}',
      entityId: entity,
      date: dateOnly(DateTime(today.year, today.month - 5 + month,
          month == 5 && day > today.day ? today.day : day)),
      kind: kind,
      note: 'DEMO • $note',
      amount: n,
      category: category,
      cost: cost,
    );
    out.addAll(mapTransaction(d));
  }

  for (int i = 0; i < 6; i++) {
    add(
      'personal',
      'active',
      10500000 + i * 250000,
      i,
      1,
      'Pendapatan profesional',
    );
    add(
      'personal',
      'passive',
      1600000 + i * 100000,
      i,
      1,
      'Sewa bersih setelah biaya',
    );
    add('personal', 'expense', 3100000, i, 2, 'Kebutuhan harian');
    add(
      'personal',
      'expense',
      2800000,
      i,
      2,
      'Tagihan esensial',
      category: 'recurring',
    );
    add(
      'personal',
      'expense',
      950000,
      i,
      3,
      'Belajar dan sertifikasi',
      category: 'productive',
    );
    add(
      'personal',
      'expense',
      225000,
      i,
      3,
      'Langganan dan administrasi',
      category: 'invisible',
    );
    add(
      'personal',
      'expense',
      450000,
      i,
      3,
      'Donasi keluarga',
      category: 'giving',
    );
    add('business', 'stock', 14000000, i, 1, 'Pembelian stok');
    add(
      'business',
      'sale',
      26000000 + i * 1500000,
      i,
      2,
      'Penjualan toko',
      cost: 12500000 + i * 400000,
    );
    add(
      'business',
      'expense',
      1800000,
      i,
      2,
      'Komisi dan fulfillment',
      category: 'selling',
    );
    add('business', 'expense', 2400000, i, 3, 'Belanja iklan', category: 'ads');
    add(
      'business',
      'expense',
      4500000,
      i,
      3,
      'Sewa dan operasional',
      category: 'opex',
    );
  }
  add(
    'business',
    'invoice',
    3200000,
    5,
    1,
    'Invoice pelanggan INV-001',
    cost: 1400000,
  );
  add('business', 'supplier', 2800000, 5, 1, 'Tagihan supplier SUP-001');
  add(
    'personal',
    'card_purchase',
    750000,
    5,
    2,
    'Peralatan kerja',
    category: 'productive',
  );
  add(
    'personal',
    'owner_loan',
    2000000,
    5,
    3,
    'Pinjaman pemilik • pasangan jurnal',
  );
  for (final e in out) {
    e.validate();
  }
  return out;
}
