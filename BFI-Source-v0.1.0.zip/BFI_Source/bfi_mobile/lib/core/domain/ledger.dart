import 'dart:math' as math;

const entities = {
  'personal': 'Pribadi',
  'household': 'Keluarga',
  'business': 'Studio Niaga',
};
const accounts = <String, String>{
  'bank': 'Bank / kas tersedia',
  'reserve': 'Dana darurat',
  'held': 'Payout tertahan',
  'ar': 'Piutang usaha',
  'inventory': 'Persediaan',
  'fixed': 'Aset tetap',
  'owner_ar': 'Piutang pemilik',
  'investment': 'Investasi tercatat',
  'accum': 'Akumulasi penyusutan',
  'ap': 'Utang supplier',
  'card': 'Utang kartu kredit',
  'loan': 'Pokok pinjaman',
  'owner_ap': 'Utang kepada pemilik',
  'equity': 'Modal / saldo awal',
  'active': 'Pendapatan aktif',
  'passive': 'Pendapatan pasif bersih',
  'sales': 'Penjualan bersih',
  'productive': 'Produktif',
  'direct': 'Konsumtif langsung',
  'recurring': 'Komitmen rutin',
  'invisible': 'Biaya tak disadari',
  'giving': 'Donasi',
  'cogs': 'HPP',
  'selling': 'Biaya penjualan',
  'ads': 'Iklan',
  'opex': 'Operasional',
  'interest': 'Bunga',
  'depreciation': 'Penyusutan',
};
const assetAccounts = [
  'bank',
  'reserve',
  'held',
  'ar',
  'inventory',
  'fixed',
  'owner_ar',
  'investment',
  'accum',
];
const liabilityAccounts = ['ap', 'card', 'loan', 'owner_ap'];
const incomeAccounts = ['active', 'passive', 'sales'];
const expenseAccounts = [
  'productive',
  'direct',
  'recurring',
  'invisible',
  'giving',
  'cogs',
  'selling',
  'ads',
  'opex',
  'interest',
  'depreciation',
];
const categories = ['productive', 'direct', 'recurring', 'invisible', 'giving'];
const transactionKinds = <String, String>{
  'active': 'Pendapatan aktif',
  'passive': 'Pendapatan pasif bersih',
  'expense': 'Pengeluaran',
  'reserve': 'Pindah ke dana darurat',
  'card_purchase': 'Belanja kartu kredit',
  'card_payment': 'Bayar pokok kartu kredit',
  'loan_receive': 'Terima pinjaman',
  'loan_repay': 'Bayar pokok pinjaman',
  'interest': 'Bayar bunga',
  'stock': 'Beli persediaan tunai',
  'sale': 'Penjualan tunai + HPP',
  'invoice': 'Penjualan kredit + HPP',
  'collect': 'Terima pelunasan invoice',
  'supplier': 'Beli persediaan kredit',
  'pay_supplier': 'Bayar supplier',
  'owner_loan': 'Pinjaman pribadi ke bisnis',
};
String uid() =>
    '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}-${math.Random.secure().nextInt(1 << 32).toRadixString(36)}';
String dateOnly(DateTime d) => d.toIso8601String().substring(0, 10);

class JournalLine {
  final String account;
  final int debit, credit;
  const JournalLine(this.account, this.debit, this.credit);
  Map<String, dynamic> toJson() => {
        'account': account,
        'debit': debit,
        'credit': credit,
      };
  factory JournalLine.fromJson(Map<String, dynamic> j) => JournalLine(
        j['account'],
        (j['debit'] as num).toInt(),
        (j['credit'] as num).toInt(),
      );
}

class Entry {
  final String id,
      entityId,
      date,
      description,
      kind,
      category,
      pairId,
      reverses,
      sourceId;
  final List<JournalLine> lines;
  final String createdAt;
  const Entry({
    required this.id,
    required this.entityId,
    required this.date,
    required this.description,
    required this.kind,
    required this.lines,
    this.category = '',
    this.pairId = '',
    this.reverses = '',
    this.sourceId = '',
    required this.createdAt,
  });
  int get amount => lines.fold(0, (v, l) => v + l.debit);
  void validate() {
    if (!entities.containsKey(entityId) ||
        lines.length < 2 ||
        description.trim().isEmpty)
      throw const FormatException(
        'Entitas, uraian, dan minimal dua baris wajib.',
      );
    if (lines.any(
      (l) =>
          !accounts.containsKey(l.account) ||
          l.debit < 0 ||
          l.credit < 0 ||
          (l.debit > 0) == (l.credit > 0),
    )) throw const FormatException('Baris debit/kredit tidak valid.');
    if (lines.fold<int>(0, (s, l) => s + l.debit - l.credit) != 0)
      throw const FormatException('Jurnal tidak seimbang.');
    if (DateTime.tryParse(date) == null)
      throw const FormatException('Tanggal tidak valid.');
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'entityId': entityId,
        'date': date,
        'description': description,
        'kind': kind,
        'category': category,
        'pairId': pairId,
        'reverses': reverses,
        'sourceId': sourceId,
        'createdAt': createdAt,
        'lines': lines.map((l) => l.toJson()).toList(),
      };
  factory Entry.fromJson(Map<String, dynamic> j) => Entry(
        id: j['id'],
        entityId: j['entityId'],
        date: j['date'],
        description: j['description'],
        kind: j['kind'],
        category: j['category'] ?? '',
        pairId: j['pairId'] ?? '',
        reverses: j['reverses'] ?? '',
        sourceId: j['sourceId'] ?? '',
        createdAt: j['createdAt'],
        lines: (j['lines'] as List)
            .map((l) => JournalLine.fromJson(Map<String, dynamic>.from(l)))
            .toList(),
      );
}

class TransactionDraft {
  final String id, entityId, date, kind, category, note, sourceId;
  final int amount, cost;
  TransactionDraft({
    String? id,
    required this.entityId,
    required this.date,
    required this.kind,
    this.category = 'direct',
    required this.note,
    required this.amount,
    this.cost = 0,
    this.sourceId = '',
  }) : id = id ?? uid();
  Map<String, dynamic> toJson() => {
        'id': id,
        'entityId': entityId,
        'date': date,
        'kind': kind,
        'category': category,
        'note': note,
        'amount': amount,
        'cost': cost,
        'sourceId': sourceId,
      };
  factory TransactionDraft.fromJson(Map<String, dynamic> j) => TransactionDraft(
        id: j['id'],
        entityId: j['entityId'],
        date: j['date'],
        kind: j['kind'],
        category: j['category'],
        note: j['note'],
        amount: (j['amount'] as num).toInt(),
        cost: (j['cost'] as num).toInt(),
        sourceId: j['sourceId'] ?? '',
      );
}

List<Entry> mapTransaction(TransactionDraft d) {
  final parsed = DateTime.tryParse(d.date);
  if (parsed == null ||
      dateOnly(parsed) != d.date ||
      parsed.year < 2020 ||
      d.date.compareTo(dateOnly(DateTime.now())) > 0) {
    throw const FormatException('Tanggal transaksi tidak valid.');
  }
  if (d.amount <= 0 ||
      d.amount > 100000000000000 ||
      d.cost < 0 ||
      d.cost > 100000000000000)
    throw const FormatException('Nominal harus positif dan dalam batas IDR.');
  if (d.note.trim().isEmpty || d.note.length > 180)
    throw const FormatException('Uraian wajib, maksimal 180 karakter.');
  if (!transactionKinds.containsKey(d.kind) ||
      !entities.containsKey(d.entityId))
    throw const FormatException('Jenis / entitas tidak valid.');
  final businessOnly = [
    'stock',
    'sale',
    'invoice',
    'collect',
    'supplier',
    'pay_supplier',
  ];
  if (businessOnly.contains(d.kind) && d.entityId != 'business')
    throw const FormatException('Transaksi ini khusus entitas bisnis.');
  if (d.kind == 'owner_loan' && d.entityId != 'personal')
    throw const FormatException(
      'Pinjaman pemilik dimulai dari entitas Pribadi.',
    );
  final now = DateTime.now().toUtc().toIso8601String();
  Entry entry(String entity, List<JournalLine> lines, {String pair = ''}) =>
      Entry(
        id: entity == d.entityId ? d.id : '${d.id}-mirror',
        entityId: entity,
        date: d.date,
        description: d.note.trim(),
        kind: d.kind,
        category: d.category,
        sourceId: d.sourceId,
        pairId: pair,
        createdAt: now,
        lines: lines,
      );
  List<JournalLine> pair(String debit, String credit, int n) => [
        JournalLine(debit, n, 0),
        JournalLine(credit, 0, n),
      ];
  List<JournalLine> lines;
  switch (d.kind) {
    case 'active':
    case 'passive':
      lines = pair('bank', d.kind, d.amount);
    case 'expense':
    case 'card_purchase':
      if (![...categories, 'selling', 'ads', 'opex'].contains(d.category))
        throw const FormatException('Kategori tidak valid.');
      lines = pair(d.category, d.kind == 'expense' ? 'bank' : 'card', d.amount);
    case 'reserve':
      lines = pair('reserve', 'bank', d.amount);
    case 'card_payment':
      lines = pair('card', 'bank', d.amount);
    case 'loan_receive':
      lines = pair('bank', 'loan', d.amount);
    case 'loan_repay':
      lines = pair('loan', 'bank', d.amount);
    case 'interest':
      lines = pair('interest', 'bank', d.amount);
    case 'stock':
      lines = pair('inventory', 'bank', d.amount);
    case 'supplier':
      lines = pair('inventory', 'ap', d.amount);
    case 'pay_supplier':
      lines = pair('ap', 'bank', d.amount);
    case 'collect':
      lines = pair('bank', 'ar', d.amount);
    case 'sale':
    case 'invoice':
      if (d.cost <= 0)
        throw const FormatException(
          'HPP wajib lebih dari nol untuk penjualan barang.',
        );
      lines = [
        ...pair(d.kind == 'sale' ? 'bank' : 'ar', 'sales', d.amount),
        ...pair('cogs', 'inventory', d.cost),
      ];
    case 'owner_loan':
      return [
        entry('personal', pair('owner_ar', 'bank', d.amount), pair: d.id),
        entry('business', pair('bank', 'owner_ap', d.amount), pair: d.id),
      ];
    default:
      throw const FormatException('Jenis belum didukung.');
  }
  final result = entry(d.entityId, lines);
  result.validate();
  return [result];
}

class Ledger {
  final List<Entry> entries;
  Ledger(this.entries);
  List<Entry> forEntity(String id, {DateTime? month}) => entries
      .where(
        (e) =>
            e.entityId == id &&
            (month == null ||
                e.date.startsWith(dateOnly(month).substring(0, 7))),
      )
      .toList();
  int balance(String entity, String account, {DateTime? through}) =>
      forEntity(entity)
          .where(
            (e) => through == null || e.date.compareTo(dateOnly(through)) <= 0,
          )
          .expand((e) => e.lines)
          .where((l) => l.account == account)
          .fold(0, (v, l) => v + l.debit - l.credit);
  int movement(
    String entity,
    List<String> list,
    DateTime month, {
    bool credit = false,
  }) =>
      forEntity(entity, month: month)
          .expand((e) => e.lines)
          .where((l) => list.contains(l.account))
          .fold(
            0,
            (v, l) => v + (credit ? l.credit - l.debit : l.debit - l.credit),
          );
  int cash(String e) => balance(e, 'bank');
  int netWorth(String e) => [
        ...assetAccounts,
        ...liabilityAccounts,
      ].fold(0, (v, a) => v + balance(e, a));
  int income(String e, DateTime m) =>
      movement(e, incomeAccounts, m, credit: true);
  int spending(String e, DateTime m) => movement(e, expenseAccounts, m);
  int profit(String e, DateTime m) => income(e, m) - spending(e, m);
  bool reversed(String id) => entries.any((e) => e.reverses == id);
  int outstanding(Entry source) {
    final account = source.kind == 'invoice' ? 'ar' : 'ap';
    final sign = source.kind == 'invoice' ? 1 : -1;
    return entries
        .where(
          (e) =>
              e.id == source.id ||
              e.sourceId == source.id ||
              e.reverses == source.id,
        )
        .expand((e) => e.lines)
        .where((l) => l.account == account)
        .fold(0, (s, l) => s + sign * (l.debit - l.credit));
  }

  void validateBatch(List<Entry> batch) {
    for (final e in batch) {
      e.validate();
      if (entries.any((x) => x.id == e.id))
        throw const FormatException('ID transaksi sudah ada.');
    }
    final next = Ledger([...entries, ...batch]);
    for (final e in batch) {
      for (final a in ['bank', 'reserve', 'inventory']) {
        if (next.balance(e.entityId, a) < 0)
          throw FormatException('Saldo ${accounts[a]} tidak cukup.');
      }
    }
  }

  void validateDraft(TransactionDraft d) {
    if (d.kind == 'collect' || d.kind == 'pay_supplier') {
      final sources = entries.where(
        (e) =>
            e.id == d.sourceId &&
            e.entityId == d.entityId &&
            e.kind == (d.kind == 'collect' ? 'invoice' : 'supplier') &&
            !reversed(e.id),
      );
      if (sources.isEmpty || d.amount > outstanding(sources.first))
        throw const FormatException(
          'Pilih invoice/tagihan dan nominal maksimal sisa terutang.',
        );
    }
    final liability = {'card_payment': 'card', 'loan_repay': 'loan'}[d.kind];
    if (liability != null && d.amount > -balance(d.entityId, liability))
      throw const FormatException('Pembayaran melebihi kewajiban.');
    validateBatch(mapTransaction(d));
  }
}

class PriceResult {
  final int netSales,
      cost,
      fee,
      profit,
      buffer,
      breakEven,
      requiredPrice,
      maxSubsidy;
  const PriceResult(
    this.netSales,
    this.cost,
    this.fee,
    this.profit,
    this.buffer,
    this.breakEven,
    this.requiredPrice,
    this.maxSubsidy,
  );
}

PriceResult price({
  required int price,
  required int discount,
  required int hpp,
  required int packaging,
  required int ops,
  required int shipping,
  required int ads,
  required int feeBps,
  required int target,
}) {
  if ([
        price,
        discount,
        hpp,
        packaging,
        ops,
        shipping,
        ads,
        feeBps,
        target,
      ].any((n) => n < 0) ||
      discount > price ||
      feeBps >= 10000)
    throw const FormatException(
      'Biaya tidak boleh negatif; fee harus <100%; diskon tidak melebihi harga.',
    );
  final net = price - discount, fee = (net * feeBps + 5000) ~/ 10000;
  final fixed = hpp + packaging + ops + shipping + ads;
  final p = net - fixed - fee;
  int required(int n) =>
      ((n * 10000 + 9999 - feeBps) ~/ (10000 - feeBps)) + discount;
  return PriceResult(
    net,
    fixed + fee,
    fee,
    p,
    p - target,
    required(fixed),
    required(fixed + target),
    net - fee - hpp - packaging - ops - ads - target,
  );
}
