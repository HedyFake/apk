import 'package:flutter/material.dart';

import '../core/data/controller.dart';
import '../core/widgets/visuals.dart';
import '../features/dashboard/screens.dart';
import '../features/transactions/input.dart';
import '../features/reports/reports.dart';
import '../features/settings/settings.dart';
import '../features/pricing/pricing.dart';

class BfiApp extends StatelessWidget {
  final BfiController c;
  const BfiApp(this.c, {super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'BFI',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme:
              ColorScheme.fromSeed(seedColor: teal, surface: Colors.white),
          scaffoldBackgroundColor: ice,
          fontFamily: 'sans-serif',
          appBarTheme: const AppBarTheme(
            backgroundColor: ice,
            foregroundColor: navy,
            elevation: 0,
          ),
          textTheme: ThemeData.light().textTheme.apply(
                bodyColor: navy,
                displayColor: navy,
              ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xffd5e3e7)),
            ),
          ),
          filledButtonTheme: FilledButtonThemeData(
            style: FilledButton.styleFrom(
              backgroundColor: teal,
              minimumSize: const Size(44, 48),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
        ),
        home: BfiShell(c),
      );
}

class BfiShell extends StatefulWidget {
  final BfiController c;
  const BfiShell(this.c, {super.key});
  @override
  State<BfiShell> createState() => _ShellState();
}

class _ShellState extends State<BfiShell> {
  int tab = 0;
  final scroll = ScrollController();
  BfiController get c => widget.c;
  @override
  void initState() {
    super.initState();
    c.addListener(refresh);
  }

  @override
  void dispose() {
    c.removeListener(refresh);
    scroll.dispose();
    super.dispose();
  }

  void refresh() {
    if (mounted) setState(() {});
  }

  void push(Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  Future<void> pickPeriod() async {
    final selected = await showDialog<DateTime>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Pilih periode'),
        children: List.generate(12, (i) {
          final m = DateTime(DateTime.now().year, DateTime.now().month - i);
          return SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, m),
            child: Text(period(m)),
          );
        }),
      ),
    );
    if (selected != null) c.selectMonth(selected);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 72,
        titleSpacing: 20,
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(11),
              child: Image.asset(
                'assets/branding/bfi_icon.png',
                width: 42,
                height: 42,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'BFI',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  'FINANCIAL INTELLIGENCE',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 9,
                    letterSpacing: 1.1,
                    color: muted,
                  ),
                ),
              ],
            )),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Laporan keuangan',
            onPressed: () => push(ReportsPage(c)),
            icon: const Icon(Icons.insert_chart_outlined),
          ),
          PopupMenuButton<String>(
            tooltip: 'Menu BFI',
            onSelected: (v) {
              switch (v) {
                case 'reports':
                  push(ReportsPage(c));
                case 'assets':
                  push(AssetsPage(c));
                case 'settings':
                  push(SettingsPage(c));
                case 'journal':
                  push(JournalPage(c));
                case 'pricing':
                  push(PricingPage(c));
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'reports', child: Text('Laporan keuangan')),
              PopupMenuItem(
                value: 'journal',
                child: Text('Jurnal & audit trail'),
              ),
              PopupMenuItem(value: 'pricing', child: Text('Smart Pricing')),
              PopupMenuItem(
                value: 'assets',
                child: Text('Aset & simulasi pajak'),
              ),
              PopupMenuItem(
                value: 'settings',
                child: Text('Pengaturan & sinkronisasi'),
              ),
            ],
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        top: false,
        child: RefreshIndicator(
          onRefresh: () async {
            if (c.demo) {
              await c.reload();
            } else {
              await c.sync();
            }
          },
          child: SingleChildScrollView(
            controller: scroll,
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 20,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: c.demo
                                ? const Color(0xffffedce)
                                : const Color(0xffd9f1eb),
                            borderRadius: BorderRadius.circular(7),
                          ),
                          child: Text(
                            c.demo ? 'DEMO • DATA CONTOH' : 'AKUN TERHUBUNG',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: c.demo ? amber : teal,
                            ),
                          ),
                        ),
                        TextButton.icon(
                          onPressed: pickPeriod,
                          icon: const Icon(
                            Icons.calendar_today_outlined,
                            size: 15,
                          ),
                          label: Text(
                            period(c.month),
                            style: const TextStyle(fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                    if (!c.demo && c.queue.isNotEmpty)
                      TextButton.icon(
                        onPressed: () => push(SettingsPage(c)),
                        icon: const Icon(Icons.cloud_upload_outlined),
                        label: Text(
                          '${c.queue.length} draft menunggu konfirmasi kirim',
                        ),
                      ),
                    if (c.error.isNotEmpty)
                      Text(
                        'Offline / gagal sinkron. Cache terakhir ditampilkan: ${c.error}',
                        style: const TextStyle(color: red),
                      ),
                    const SizedBox(height: 18),
                    switch (tab) {
                      0 => OverviewScreen(
                          c,
                          onJournal: () => push(JournalPage(c)),
                        ),
                      1 => PersonalScreen(
                          c,
                          onInput: () => push(InputPage(c)),
                          onJournal: () => push(JournalPage(c)),
                        ),
                      3 => BusinessScreen(
                          c,
                          onPricing: () => push(PricingPage(c)),
                          onReports: () => push(ReportsPage(c)),
                          onInput: () => push(InputPage(c)),
                        ),
                      _ => IntelligenceScreen(c),
                    },
                    const SizedBox(height: 24),
                    Text(
                      c.demo
                          ? 'DEMO • Ledger lokal untuk mencoba BFI. Tidak tersambung bank.'
                          : 'Saldo dari jurnal server. Draft offline belum memengaruhi saldo.',
                      style: const TextStyle(fontSize: 12, color: muted),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          height: 78,
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(top: BorderSide(color: Color(0xffe5edf0))),
          ),
          child: Row(
            children: List.generate(5, (i) {
              const icons = [
                Icons.space_dashboard_outlined,
                Icons.account_balance_wallet_outlined,
                Icons.add,
                Icons.storefront_outlined,
                Icons.auto_awesome_outlined,
              ];
              const labels = [
                'Ringkasan',
                'Pribadi',
                'Input',
                'Bisnis',
                'Insight',
              ];
              return Expanded(
                child: InkWell(
                  onTap: () {
                    if (i == 2) {
                      push(InputPage(c));
                    } else {
                      setState(() {
                        tab = i;
                        if (i == 1) c.entity = 'personal';
                        if (i == 3) c.entity = 'business';
                      });
                      if (scroll.hasClients) scroll.jumpTo(0);
                    }
                  },
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.all(i == 2 ? 11 : 6),
                        decoration: BoxDecoration(
                          color: i == 2
                              ? teal
                              : (tab == i
                                  ? const Color(0xffe2f3ee)
                                  : Colors.transparent),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(
                          icons[i],
                          size: i == 2 ? 26 : 22,
                          color:
                              i == 2 ? Colors.white : (tab == i ? teal : muted),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        labels[i],
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight:
                              tab == i ? FontWeight.w700 : FontWeight.w500,
                          color: tab == i ? teal : muted,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
