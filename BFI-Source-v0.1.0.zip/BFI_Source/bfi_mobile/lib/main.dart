import 'package:flutter/material.dart';

import 'core/data/controller.dart';
import 'core/data/store.dart';
import 'app/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    final db = await BfiDatabase.open();
    final controller = BfiController(db);
    await controller.init();
    runApp(BfiApp(controller));
  } catch (e) {
    runApp(
      MaterialApp(
        home: Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 48),
                  const Text('BFI belum dapat membuka penyimpanan.'),
                  SelectableText('$e'),
                  const Text(
                    'Tutup lalu buka kembali aplikasi. Data tidak dihapus otomatis.',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
