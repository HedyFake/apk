import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/data/controller.dart';
import '../../core/domain/ledger.dart';
import '../../core/widgets/visuals.dart';

class PricingPage extends StatefulWidget {
  final BfiController c;
  const PricingPage(this.c, {super.key});
  @override
  State<PricingPage> createState() => _PricingState();
}

class _PricingState extends State<PricingPage> {
  final defaults = {
    'price': 180000,
    'discount': 0,
    'hpp': 97000,
    'packaging': 4000,
    'ops': 3000,
    'shipping': 18000,
    'ads': 9000,
    'feeBps': 800,
    'target': 20000,
  };
  final labels = {
    'price': 'Harga jual (Rp)',
    'discount': 'Diskon penjual (Rp)',
    'hpp': 'HPP (Rp)',
    'packaging': 'Kemasan (Rp)',
    'ops': 'Biaya variabel lain (Rp)',
    'shipping': 'Subsidi ongkir (Rp)',
    'ads': 'Iklan dialokasikan / order (Rp)',
    'feeBps': 'Fee basis points (800 = 8%)',
    'target': 'Target contribution setelah iklan (Rp)',
  };
  late Map<String, TextEditingController> fields;
  bool complete = false;
  String saved = '';
  @override
  void initState() {
    super.initState();
    fields = {
      for (final e in defaults.entries)
        e.key: TextEditingController(text: widget.c.demo ? '${e.value}' : '0'),
    };
    for (final f in fields.values) {
      f.addListener(refresh);
    }
    load();
  }

  void refresh() {
    if (mounted) setState(() => saved = '');
  }

  Future<void> load() async {
    final raw = await widget.c.db.getSetting('${widget.c.mode}.pricing');
    if (raw != null) {
      final values = jsonDecode(raw);
      for (final k in fields.keys) {
        fields[k]!.text = '${values[k] ?? 0}';
      }
      if (mounted) setState(() => saved = 'Skenario tersimpan dimuat.');
    }
  }

  @override
  void dispose() {
    for (final f in fields.values) {
      f.dispose();
    }
    super.dispose();
  }

  int n(String key) => int.tryParse(fields[key]!.text) ?? 0;
  @override
  Widget build(BuildContext context) {
    PriceResult? r;
    String error = '';
    try {
      r = price(
        price: n('price'),
        discount: n('discount'),
        hpp: n('hpp'),
        packaging: n('packaging'),
        ops: n('ops'),
        shipping: n('shipping'),
        ads: n('ads'),
        feeBps: n('feeBps'),
        target: n('target'),
      );
    } catch (e) {
      error = e.toString();
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Smart Pricing')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 650),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Label(
                    widget.c.demo
                        ? 'DEMO • SIMULASI PER ORDER'
                        : 'SIMULASI • BUKAN JURNAL',
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Kenali ruang\nuntuk untung.',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -1,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Fee dihitung atas harga setelah diskon. Biaya dipotong sekali. Belum termasuk overhead tetap dan pajak.',
                    style: TextStyle(color: muted, height: 1.5),
                  ),
                  const SizedBox(height: 22),
                  Wrap(
                    spacing: 8,
                    children: [
                      ActionChip(
                        label: const Text('Ongkir normal'),
                        onPressed: () => fields['shipping']!.text = '18000',
                      ),
                      ActionChip(
                        label: const Text('Ongkir naik'),
                        onPressed: () => fields['shipping']!.text = '30000',
                      ),
                      ActionChip(
                        label: const Text('Promo penjual'),
                        onPressed: () {
                          fields['discount']!.text = '12000';
                          fields['shipping']!.text = '18000';
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  ...fields.entries.map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: TextField(
                        controller: e.value,
                        decoration: InputDecoration(labelText: labels[e.key]),
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(12),
                        ],
                      ),
                    ),
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    value: complete,
                    onChanged: (v) => setState(() => complete = v!),
                    title: const Text(
                      'Komponen biaya simulasi sudah lengkap',
                      style: TextStyle(fontSize: 14),
                    ),
                    subtitle: const Text(
                      'Konfirmasi asumsi, termasuk biaya bernilai nol.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                  const SizedBox(height: 14),
                  if (r != null)
                    Panel(
                      dark: true,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Label(
                            !complete
                                ? 'ASUMSI BELUM LENGKAP'
                                : r.profit < 0
                                    ? 'RUGI'
                                    : r.buffer < 0
                                        ? 'DI BAWAH TARGET'
                                        : 'TARGET TERCAPAI',
                            color: const Color(0xffb4e7da),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            money(r.profit),
                            style: numbers(32, color: Colors.white),
                          ),
                          const Text(
                            'Contribution setelah iklan / order',
                            style: TextStyle(
                              color: Color(0xffb2cbd0),
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Buffer ${money(r.buffer)} · ${r.netSales > 0 ? percent(r.profit / r.netSales * 100) : 'N/A'} dari ${money(r.netSales)} penjualan bersih',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              height: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (error.isNotEmpty)
                    Text(error, style: const TextStyle(color: red)),
                  const SizedBox(height: 16),
                  if (r != null)
                    Panel(
                      child: Column(
                        children: [
                          MoneyRow('Penjualan setelah diskon', r.netSales),
                          MoneyRow('Fee atas penjualan bersih', r.fee),
                          MoneyRow('Total biaya termasuk fee & iklan', r.cost),
                          MoneyRow('Harga impas', r.breakEven),
                          MoneyRow(
                            'Harga untuk target contribution',
                            r.requiredPrice,
                            bold: true,
                          ),
                          MoneyRow('Batas subsidi untuk target', r.maxSubsidy),
                          const Text(
                            'Batas subsidi negatif berarti target tidak memungkinkan dengan harga dan biaya saat ini. Fee bertingkat/cap belum didukung.',
                            style: TextStyle(fontSize: 12, color: muted),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: r == null
                        ? null
                        : () async {
                            await widget.c.db.setSetting(
                              '${widget.c.mode}.pricing',
                              jsonEncode({
                                for (final k in fields.keys) k: n(k),
                              }),
                            );
                            if (mounted)
                              setState(
                                () => saved =
                                    'Skenario disimpan lokal. Katalog harga tidak diubah.',
                              );
                          },
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Simpan skenario'),
                  ),
                  if (saved.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(saved, style: const TextStyle(color: teal)),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
