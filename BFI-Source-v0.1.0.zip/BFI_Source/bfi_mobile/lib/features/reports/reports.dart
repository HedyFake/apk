import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/data/controller.dart';
import '../../core/domain/ledger.dart';
import '../../core/widgets/visuals.dart';

class ReportsPage extends StatefulWidget {
  final BfiController c;
  const ReportsPage(this.c, {super.key});
  @override
  State<ReportsPage> createState() => _ReportsState();
}

class _ReportsState extends State<ReportsPage> {
  String section = 'P&L';
  late String entity;
  @override
  void initState() {
    super.initState();
    entity = widget.c.entity;
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: widget.c,
        builder: (context, _) {
          final c = widget.c, l = c.ledger, m = c.month;
          final periodEntries = l.forEntity(entity, month: m);
          final debit = periodEntries
                  .expand((e) => e.lines)
                  .fold<int>(0, (s, l) => s + l.debit),
              credit = periodEntries
                  .expand((e) => e.lines)
                  .fold<int>(0, (s, l) => s + l.credit);
          final rows = <String, int>{};
          final end = DateTime(m.year, m.month + 1, 0);
          final retained = -[...incomeAccounts, ...expenseAccounts]
              .fold<int>(0, (s, a) => s + l.balance(entity, a, through: end));
          if (section == 'P&L') {
            rows.addAll({
              for (final a in incomeAccounts)
                accounts[a]!: l.movement(entity, [a], m, credit: true),
              for (final a in expenseAccounts)
                accounts[a]!: -l.movement(entity, [a], m),
              'Laba / surplus sebelum pajak': l.profit(entity, m),
            });
          }
          if (section == 'Neraca') {
            rows.addAll({
              for (final a in [
                ...assetAccounts,
                ...liabilityAccounts,
                'equity'
              ])
                accounts[a]!: l.balance(
                  entity,
                  a,
                  through: DateTime(m.year, m.month + 1, 0),
                ),
              'Laba kumulatif (saldo kredit)': -retained,
              'Selisih A − L − E (harus nol)': accounts.keys.fold<int>(
                  0, (s, a) => s + l.balance(entity, a, through: end)),
            });
          }
          if (section == 'Trial balance') {
            rows.addAll({
              for (final a in accounts.keys)
                accounts[a]!: l.balance(
                  entity,
                  a,
                  through: DateTime(m.year, m.month + 1, 0),
                ),
            });
          }
          if (section == 'Arus kas') {
            final begin = DateTime(m.year, m.month, 0),
                end = DateTime(m.year, m.month + 1, 0);
            int cash(DateTime d) =>
                l.balance(entity, 'bank', through: d) +
                l.balance(entity, 'reserve', through: d);
            int group(List<String> kinds) => periodEntries
                .where((e) => kinds.contains(e.kind))
                .expand((e) => e.lines)
                .where((x) => ['bank', 'reserve'].contains(x.account))
                .fold(0, (s, x) => s + x.debit - x.credit);
            final cff = group(['loan_receive', 'loan_repay', 'owner_loan']);
            final change = cash(end) - cash(begin);
            final uncategorized = group(['opening', 'reversal']);
            rows.addAll({
              'Kas awal': cash(begin),
              'CFO • transaksi operasional': change - cff - uncategorized,
              'CFI • belum ada transaksi investasi tunai': 0,
              'CFF • pinjaman / pemilik': cff,
              'Saldo awal / pembalikan belum diklasifikasi': uncategorized,
              'Perubahan bersih': change,
              'Kas akhir': cash(end),
            });
          }
          return Scaffold(
            appBar: AppBar(
              title: const Text('Laporan keuangan'),
              actions: [
                IconButton(
                  tooltip: 'Ekspor CSV',
                  onPressed: () async {
                    String q(String s) => '"${s.replaceAll('"', '""')}"';
                    final csv =
                        'BFI,${c.demo ? 'DEMO' : 'AKUN'},${entities[entity]},${period(m)},$section\nAkun,IDR\n' +
                            rows.entries
                                .map((e) => '${q(e.key)},${e.value}')
                                .join('\n');
                    try {
                      final result = await const MethodChannel('id.bfi/files')
                          .invokeMethod<bool>('saveCsv', {
                        'name': 'BFI_${entity}_${dateOnly(m)}.csv',
                        'content': csv,
                      });
                      if (context.mounted)
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              result == true
                                  ? 'Laporan CSV tersimpan.'
                                  : 'Ekspor dibatalkan.',
                            ),
                          ),
                        );
                    } catch (e) {
                      if (context.mounted)
                        explain(context, 'Ekspor belum berhasil', '$e');
                    }
                  },
                  icon: const Icon(Icons.file_download_outlined),
                ),
              ],
            ),
            body: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 720),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Label('${c.demo ? 'DEMO • ' : ''}${period(m)} • IDR'),
                      const SizedBox(height: 16),
                      DropdownButton<String>(
                        value: entity,
                        isExpanded: true,
                        items: entities.entries
                            .map(
                              (e) => DropdownMenuItem(
                                value: e.key,
                                child: Text(e.value),
                              ),
                            )
                            .toList(),
                        onChanged: (v) => setState(() => entity = v!),
                      ),
                      const SizedBox(height: 12),
                      Panel(
                        child: Column(
                          children: [
                            const SectionTitle('Integritas jurnal'),
                            MoneyRow('Total debit periode', debit),
                            MoneyRow('Total kredit periode', credit),
                            MoneyRow(
                              'Selisih',
                              debit - credit,
                              color: debit == credit ? teal : red,
                              bold: true,
                            ),
                            const Text(
                              'Seimbang tidak sama dengan diaudit. Sumber: jurnal tercatat pada periode terpilih.',
                              style: TextStyle(fontSize: 12, color: muted),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children:
                              ['P&L', 'Neraca', 'Arus kas', 'Trial balance']
                                  .map(
                                    (s) => Padding(
                                      padding: const EdgeInsets.only(right: 8),
                                      child: ChoiceChip(
                                        label: Text(s),
                                        selected: section == s,
                                        onSelected: (_) =>
                                            setState(() => section = s),
                                      ),
                                    ),
                                  )
                                  .toList(),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Panel(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SectionTitle(section),
                            const SizedBox(height: 8),
                            Text(
                              section == 'Neraca'
                                  ? 'Saldo debit positif, kredit negatif. Equity mencakup modal; laba kumulatif ditampilkan terpisah.'
                                  : section == 'Arus kas'
                                      ? 'Metode langsung. Pembalikan/saldo awal yang belum diklasifikasi ditampilkan terpisah, bukan dianggap CFO.'
                                      : 'Nominal rupiah penuh • basis jurnal',
                              style:
                                  const TextStyle(fontSize: 12, color: muted),
                            ),
                            ...rows.entries
                                .map((e) => MoneyRow(e.key, e.value)),
                            if (section == 'Trial balance')
                              MoneyRow(
                                'Jumlah saldo (harus nol)',
                                rows.values.fold<int>(0, (a, b) => a + b),
                                bold: true,
                              ),
                            if (section == 'Neraca') ...[
                              MoneyRow(
                                'Laba kumulatif',
                                -incomeAccounts.fold<int>(
                                      0,
                                      (s, a) =>
                                          s +
                                          l.balance(
                                            entity,
                                            a,
                                            through: DateTime(
                                              m.year,
                                              m.month + 1,
                                              0,
                                            ),
                                          ),
                                    ) -
                                    expenseAccounts.fold<int>(
                                      0,
                                      (s, a) =>
                                          s +
                                          l.balance(
                                            entity,
                                            a,
                                            through: DateTime(
                                              m.year,
                                              m.month + 1,
                                              0,
                                            ),
                                          ),
                                    ),
                              ),
                              const Text(
                                'Aset = liabilitas + modal + laba kumulatif. Kas personal/household/bisnis tidak digabung.',
                                style: TextStyle(fontSize: 12, color: muted),
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      OutlinedButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => JournalPage(c)),
                        ),
                        icon: const Icon(Icons.receipt_long_outlined),
                        label: const Text('Telusuri jurnal sumber'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
}

class JournalPage extends StatefulWidget {
  final BfiController c;
  const JournalPage(this.c, {super.key});
  @override
  State<JournalPage> createState() => _JournalState();
}

class _JournalState extends State<JournalPage> {
  String entity = 'all';
  Future<void> open(Entry e) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                e.description,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              SelectableText(
                '${entities[e.entityId]} • ${e.date}\nID: ${e.id}\n${e.pairId.isEmpty ? '' : 'Pasangan: ${e.pairId}'}\n${e.reverses.isEmpty ? '' : 'Pembalikan dari: ${e.reverses}'}',
                style: const TextStyle(fontSize: 12, color: muted),
              ),
              const SizedBox(height: 12),
              ...e.lines.map(
                (l) => MoneyRow(
                  '${l.debit > 0 ? 'D' : 'K'} • ${accounts[l.account]}',
                  l.debit + l.credit,
                ),
              ),
              const Divider(),
              Text(
                'Dicatat ${e.createdAt}',
                style: const TextStyle(fontSize: 12, color: muted),
              ),
              const SizedBox(height: 16),
              if (e.reverses.isEmpty &&
                  e.kind != 'opening' &&
                  !widget.c.ledger.reversed(e.id))
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    reverse(e);
                  },
                  icon: const Icon(Icons.undo),
                  label: const Text('Koreksi dengan pembalikan'),
                ),
              if (widget.c.ledger.reversed(e.id))
                const Text(
                  'Jurnal sudah dibalik; catatan asli tetap disimpan.',
                  style: TextStyle(color: amber),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> reverse(Entry e) async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Konfirmasi pembalikan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Jurnal kebalikan dibuat pada tanggal hari ini. Pasangan antar-entitas dibalik bersama.',
            ),
            const SizedBox(height: 16),
            TextField(
              controller: reason,
              decoration: const InputDecoration(labelText: 'Alasan koreksi'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Balik jurnal'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await widget.c.reverse(e, reason.text);
        if (mounted) setState(() {});
      } catch (error) {
        if (mounted) explain(context, 'Pembalikan ditolak', '$error');
      }
    }
    reason.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final list = widget.c.entries
        .where((e) => entity == 'all' || e.entityId == entity)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    return Scaffold(
      appBar: AppBar(title: const Text('Jurnal & audit trail')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Label(widget.c.demo ? 'DEMO • JURNAL LOKAL' : 'CACHE JURNAL SERVER'),
          DropdownButton<String>(
            value: entity,
            isExpanded: true,
            items: [
              const DropdownMenuItem(
                value: 'all',
                child: Text('Semua entitas • terpisah'),
              ),
              ...entities.entries.map(
                (e) => DropdownMenuItem(value: e.key, child: Text(e.value)),
              ),
            ],
            onChanged: (v) => setState(() => entity = v!),
          ),
          const SizedBox(height: 12),
          if (list.isEmpty)
            const Panel(
              child: Text('Belum ada jurnal. Mulai dari Input transaksi.'),
            ),
          ...list.map(
            (e) => Card(
              elevation: 0,
              color: Colors.white,
              child: ListTile(
                onTap: () => open(e),
                leading: CircleAvatar(
                  backgroundColor: ice,
                  child: Icon(
                    e.reverses.isNotEmpty
                        ? Icons.undo
                        : Icons.receipt_long_outlined,
                    color: teal,
                    size: 20,
                  ),
                ),
                title: Text(
                  e.description,
                  style: const TextStyle(fontSize: 14),
                ),
                subtitle: Text(
                  '${entities[e.entityId]} • ${e.date}${e.pairId.isNotEmpty ? ' • linked' : ''}',
                  style: const TextStyle(fontSize: 12),
                ),
                trailing: const Icon(Icons.chevron_right, size: 18),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const SectionTitle('Log aktivitas lokal'),
          ...widget.c.audit.take(20).map(
                (a) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    '${a['action']}',
                    style: const TextStyle(fontSize: 13),
                  ),
                  subtitle: Text(
                    '${a['at']}\n${a['reason'] ?? ''}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

class AssetsPage extends StatefulWidget {
  final BfiController c;
  const AssetsPage(this.c, {super.key});
  @override
  State<AssetsPage> createState() => _AssetsState();
}

class _AssetsState extends State<AssetsPage> {
  final cost = TextEditingController(text: '24000000'),
      residual = TextEditingController(text: '0'),
      life = TextEditingController(text: '48');
  @override
  void dispose() {
    cost.dispose();
    residual.dispose();
    life.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = int.tryParse(cost.text) ?? 0,
        r = int.tryParse(residual.text) ?? 0,
        n = int.tryParse(life.text) ?? 0;
    final valid = a >= r && r >= 0 && n > 0;
    final dep = valid ? (a - r) / n : 0.0;
    return Scaffold(
      appBar: AppBar(title: const Text('Aset & simulasi pajak')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Label('${widget.c.demo ? 'DEMO • ' : ''}SIMULASI • TIDAK DIPOSTING'),
          const SizedBox(height: 14),
          const Text(
            'Rencanakan\npenyusutan aset.',
            style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          Panel(
            child: Column(
              children: [
                MoneyRow(
                  'Aset tetap bisnis tercatat',
                  widget.c.ledger.balance('business', 'fixed'),
                ),
                MoneyRow(
                  'Akumulasi penyusutan',
                  -widget.c.ledger.balance('business', 'accum'),
                ),
                const Text(
                  'Register aset per unit dan jadwal posting belum tersedia.',
                  style: TextStyle(fontSize: 12, color: muted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ...[
            (cost, 'Harga perolehan (Rp)'),
            (residual, 'Nilai residu (Rp)'),
            (life, 'Masa manfaat (bulan)'),
          ].map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: TextField(
                controller: item.$1,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(12),
                ],
                decoration: InputDecoration(labelText: item.$2),
                onChanged: (_) => setState(() {}),
              ),
            ),
          ),
          if (valid) ...[
            Panel(
              child: Column(
                children: [
                  const SectionTitle('Preview garis lurus'),
                  MoneyRow('Beban per bulan (dibulatkan)', dep),
                  MoneyRow(
                    'Nilai buku setelah 12 bulan',
                    (a - dep * 12).clamp(r.toDouble(), a.toDouble()),
                  ),
                  const Text(
                    '(Harga perolehan − residu) ÷ masa manfaat. Simulasi akuntansi; bukan klasifikasi fiskal.',
                    style: TextStyle(fontSize: 12, color: muted),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Trend(
              title: 'Nilai buku',
              meta: 'Simulasi IDR • garis lurus; tanpa jurnal otomatis',
              values: List.generate(6, (i) => (a - (a - r) * i / 5).round()),
              labels: List.generate(6, (i) => 'B${(n * i / 5).round()}'),
            ),
          ] else
            const Text(
              'Residu harus ≤ perolehan dan masa manfaat >0.',
              style: TextStyle(color: red),
            ),
          const SizedBox(height: 20),
          const Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Label('PAJAK • BELUM DIKONFIGURASI', color: amber),
                SizedBox(height: 10),
                Text(
                  'Tidak ada tarif default.',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 10),
                Text(
                  'Perlu profil wajib pajak, yurisdiksi, periode efektif, sumber aturan dan review penasihat yang kompeten. Modul ini belum menghasilkan estimasi pajak atau melakukan posting.',
                  style: TextStyle(color: muted, height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
