import 'package:flutter/material.dart';

import '../../core/data/controller.dart';
import '../../core/domain/ledger.dart';
import '../../core/widgets/visuals.dart';

Widget gap() => const SizedBox(height: 20);
Widget subtitle(String t) => Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 22),
      child: Text(t, style: const TextStyle(color: muted, height: 1.5)),
    );
Widget heading(String t) => Text(
      t,
      style: const TextStyle(
        fontSize: 29,
        fontWeight: FontWeight.w800,
        letterSpacing: -1,
      ),
    );
List<DateTime> months(BfiController c) =>
    List.generate(6, (i) => DateTime(c.month.year, c.month.month - 5 + i));
Widget entitySelector(BfiController c, {bool personalOnly = false}) =>
    DropdownButton<String>(
      value: c.entity,
      isExpanded: true,
      items: entities.entries
          .where((e) => !personalOnly || e.key != 'business')
          .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
          .toList(),
      onChanged: (v) {
        if (v != null) c.selectEntity(v);
      },
    );
Widget metric(String label, int value, {Color? color}) => Expanded(
      child: Panel(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Label(label),
            const SizedBox(height: 10),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child:
                  Text(money(value), style: numbers(20, color: color ?? navy)),
            ),
          ],
        ),
      ),
    );

class OverviewScreen extends StatelessWidget {
  final BfiController c;
  final VoidCallback onJournal;
  const OverviewScreen(this.c, {super.key, required this.onJournal});
  @override
  Widget build(BuildContext context) {
    final l = c.ledger;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        heading('Dua ranah.\nSatu pandangan.'),
        subtitle('Keputusan lebih tenang dimulai dari angka yang jelas.'),
        Panel(
          dark: true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(
                    Icons.shield_outlined,
                    color: Color(0xff8fe0ce),
                    size: 18,
                  ),
                  SizedBox(width: 8),
                  Expanded(
                      child: Label('KEUANGAN TETAP TERPISAH',
                          color: Color(0xff8fe0ce))),
                ],
              ),
              const SizedBox(height: 14),
              const Text(
                'Kas pribadi bukan\nkas perusahaan.',
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  height: 1.2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Per ${dateOnly(DateTime.now())} · IDR\nPayout tertahan dan dana darurat tidak masuk kas tersedia.',
                style: const TextStyle(
                  color: Color(0xffb2cbd0),
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('Kesehatan finansial'),
              const SizedBox(height: 6),
              const Text(
                'Belum dinilai • data profil belum lengkap',
                style: TextStyle(fontSize: 12, color: amber),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: Ring(
                      value: null,
                      center: '—',
                      label: 'Pribadi',
                      detail:
                          'Skala indeks 0–100. Belum dinilai karena data aset, kewajiban dan target belum diverifikasi. BFI tidak menetapkan skor sehat dari saldo saja.\nPeriode ${period(c.month)}.',
                    ),
                  ),
                  Expanded(
                    child: Ring(
                      value: null,
                      center: '—',
                      label: 'Bisnis',
                      color: navy,
                      detail:
                          'Skala indeks 0–100. Menunggu kebijakan skor, data lengkap dan rekonsiliasi. Lihat laporan untuk angka yang telah tercatat.\nPeriode ${period(c.month)}.',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        gap(),
        const SectionTitle('Likuiditas tersedia'),
        const SizedBox(height: 12),
        Row(
          children: [
            metric('PRIBADI', l.cash('personal')),
            const SizedBox(width: 10),
            metric('STUDIO NIAGA', l.cash('business'), color: teal),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Terpisah • Dana darurat ${money(l.balance('personal', 'reserve'))} • Payout tertahan ${money(l.balance('business', 'held'))}',
          style: const TextStyle(fontSize: 12, color: muted),
        ),
        gap(),
        Trend(
          title: 'Perjalanan kekayaan pribadi',
          meta: 'Aset tercatat − kewajiban · IDR · nilai buku',
          values: months(c)
              .map(
                (m) => [...assetAccounts, ...liabilityAccounts].fold<int>(
                  0,
                  (s, a) =>
                      s +
                      l.balance(
                        'personal',
                        a,
                        through: DateTime(m.year, m.month + 1, 0),
                      ),
                ),
              )
              .toList(),
          labels: months(c).map((m) => monthNames[m.month - 1]).toList(),
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionTitle(
                'Pemilik ↔ perusahaan',
                action: IconButton(
                  tooltip: 'Lihat kedua jurnal',
                  onPressed: onJournal,
                  icon: const Icon(Icons.arrow_forward, size: 19),
                ),
              ),
              MoneyRow(
                'Piutang pribadi ke perusahaan',
                l.balance('personal', 'owner_ar'),
              ),
              MoneyRow(
                'Utang perusahaan ke pemilik',
                -l.balance('business', 'owner_ap'),
              ),
              const Text(
                'Dua sisi pencatatan dengan ID pasangan. Bukan pendapatan pribadi atau bisnis.',
                style: TextStyle(fontSize: 12, color: muted),
              ),
            ],
          ),
        ),
        gap(),
        Obligations(c),
      ],
    );
  }
}

class PersonalScreen extends StatelessWidget {
  final BfiController c;
  final VoidCallback onInput, onJournal;
  const PersonalScreen(
    this.c, {
    super.key,
    required this.onInput,
    required this.onJournal,
  });
  @override
  Widget build(BuildContext context) {
    final e = c.entity == 'business' ? 'personal' : c.entity,
        l = c.ledger,
        m = c.month;
    final income = l.income(e, m), spend = l.spending(e, m);
    final essential = l.movement(e, ['direct', 'recurring'], m);
    final reserve = l.balance(e, 'reserve');
    final coverage = essential > 0 ? reserve / essential : null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        heading('Ruang keuanganmu'),
        subtitle('Pahami arus masuk. Kendalikan pengeluaran.'),
        DropdownButton<String>(
          value: e,
          isExpanded: true,
          items: ['personal', 'household']
              .map(
                (id) => DropdownMenuItem(value: id, child: Text(entities[id]!)),
              )
              .toList(),
          onChanged: (v) => c.selectEntity(v!),
        ),
        Panel(
          dark: true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Label(
                'KEKAYAAN BERSIH • NILAI TERCATAT',
                color: Color(0xffb2cbd0),
              ),
              const SizedBox(height: 13),
              Text(
                money(l.netWorth(e)),
                style: numbers(31, color: Colors.white),
              ),
              const SizedBox(height: 13),
              Text(
                'Aset dikurangi kewajiban • ${dateOnly(DateTime.now())}',
                style: const TextStyle(fontSize: 12, color: Color(0xffb2cbd0)),
              ),
              const SizedBox(height: 8),
              const Text(
                'Tidak memasukkan nilai pasar atau unrealized gain.',
                style: TextStyle(fontSize: 12, color: Color(0xffb2cbd0)),
              ),
            ],
          ),
        ),
        gap(),
        Row(
          children: [
            metric('PENDAPATAN', income, color: teal),
            const SizedBox(width: 10),
            metric('PENGELUARAN', spend),
          ],
        ),
        const SizedBox(height: 10),
        Panel(
          child: MoneyRow(
            'Surplus periode ${period(m)}',
            income - spend,
            bold: true,
          ),
        ),
        gap(),
        Breakdown(
          title: 'Dari mana uang masuk?',
          meta: '${period(m)} · porsi dari total pendapatan tercatat',
          data: {
            'Aktif': l.movement(e, ['active'], m, credit: true),
            'Pasif bersih': l.movement(e, ['passive'], m, credit: true),
          },
        ),
        gap(),
        Panel(
          child: Column(
            children: [
              SectionTitle(
                'Dana darurat',
                action: IconButton(
                  tooltip: 'Penjelasan target',
                  onPressed: () => explain(
                    context,
                    'Target dana darurat',
                    'Target ilustratif 6 bulan. Basis sementara: pengeluaran Direct + Komitmen Rutin periode terpilih. Belum merupakan essential spending yang diverifikasi pengguna.',
                  ),
                  icon: const Icon(Icons.info_outline, size: 19),
                ),
              ),
              const SizedBox(height: 14),
              Ring(
                value: coverage == null ? null : coverage / 6 * 100,
                center: coverage == null
                    ? 'N/A'
                    : '${coverage.toStringAsFixed(1)} bln',
                label: 'Target 6 bulan',
                detail:
                    '${money(reserve)} ÷ ${money(essential)} biaya esensial sementara per bulan. Progress = bulan tercakup ÷ target 6 × 100%.\nPeriode ${period(m)}. Ring dicap 100%, bulan aktual tetap ditampilkan.',
              ),
              MoneyRow('Dana likuid khusus', reserve),
              MoneyRow('Basis biaya esensial sementara', essential),
            ],
          ),
        ),
        gap(),
        Breakdown(
          title: 'Disiplin pengeluaran',
          meta:
              '${period(m)} · % dari lima kategori utama; tags tidak dijumlahkan',
          data: {
            for (final a in categories) accounts[a]!: l.movement(e, [a], m),
          },
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('Rekening & kewajiban'),
              MoneyRow('Kas tersedia', l.cash(e)),
              MoneyRow('Dana darurat', reserve),
              MoneyRow('Outstanding kartu kredit', -l.balance(e, 'card')),
              MoneyRow('Pokok pinjaman', -l.balance(e, 'loan')),
              const Text(
                'Limit kartu belum dikonfigurasi: utilization N/A.',
                style: TextStyle(fontSize: 12, color: muted),
              ),
            ],
          ),
        ),
        gap(),
        FilledButton.icon(
          onPressed: onInput,
          icon: const Icon(Icons.add),
          label: const Text('Catat transaksi'),
        ),
        gap(),
        RecentEntries(c, entity: e, onOpen: onJournal),
      ],
    );
  }
}

class IntelligenceScreen extends StatelessWidget {
  final BfiController c;
  const IntelligenceScreen(this.c, {super.key});
  @override
  Widget build(BuildContext context) {
    final l = c.ledger, m = c.month;
    final active = l.movement('personal', ['active'], m, credit: true),
        passive = l.movement('personal', ['passive'], m, credit: true),
        essential = l.movement('personal', ['direct', 'recurring'], m),
        leak = l.movement('personal', ['invisible'], m);
    final all = active + passive;
    final spending = l.spending('personal', m);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        heading('Uang bekerja.\nHidup lebih terarah.'),
        subtitle('Pak Tung Intelligence Center'),
        Panel(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.info_outline, color: teal, size: 20),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Kerangka edukasi inspiratif. Bukan pengganti standar akuntansi, penasihat pajak atau investasi berizin.',
                  style: TextStyle(fontSize: 13, height: 1.5),
                ),
              ),
            ],
          ),
        ),
        gap(),
        Panel(
          child: Column(
            children: [
              const SectionTitle('Cakupan pendapatan pasif'),
              const SizedBox(height: 20),
              Ring(
                value: essential > 0 ? passive / essential * 100 : null,
                center: percent(
                  essential > 0 ? passive / essential * 100 : null,
                ),
                label: 'Menuju 100% biaya esensial',
                detail:
                    'Passive coverage = pendapatan pasif bersih berulang / biaya esensial sementara (Direct + Rutin) × 100%.\n${money(passive)} / ${money(essential)} · ${period(m)}.\nTidak termasuk unrealized gain. Bukan janji bebas finansial.',
              ),
              MoneyRow('Pasif berulang bersih', passive),
              MoneyRow('Biaya esensial sementara', essential),
              MoneyRow(
                'Gap menuju cakupan penuh',
                (essential - passive).clamp(0, 1 << 60),
              ),
            ],
          ),
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('Gajah & Kerbau'),
              const SizedBox(height: 12),
              ProgressStat('Gajah • arus pasif bersih', passive, essential),
              const SizedBox(height: 16),
              ProgressStat('Kerbau • kebutuhan esensial', essential, essential),
              const SizedBox(height: 12),
              const Text(
                'Metafora untuk refleksi, bukan penilaian gaya hidup.',
                style: TextStyle(fontSize: 12, color: muted),
              ),
            ],
          ),
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('Tiga pilar pendapatan'),
              MoneyRow('Active income', active),
              MoneyRow('Passive income bersih', passive),
              const MoneyRow('Portfolio gain', 0),
              const Text(
                'Pencatatan portfolio gain belum tersedia. Nilai nol bukan hasil valuasi pasar.',
                style: TextStyle(fontSize: 12, color: muted),
              ),
              const Divider(),
              Text(
                'Ketergantungan aktif: ${percent(all > 0 ? active / all * 100 : null)}',
                style: numbers(17),
              ),
              Text(
                'Aktif ÷ (aktif + pasif recurring) · ${period(m)}',
                style: const TextStyle(fontSize: 12, color: muted),
              ),
              const SizedBox(height: 12),
              Text(
                'Surplus / income: ${percent(all > 0 ? (all - spending) / all * 100 : null)}',
                style: numbers(17),
              ),
              const Text(
                'Basis tercatat; transaksi pinjaman/transfer dan non-cash dikecualikan dari income.',
                style: TextStyle(fontSize: 12, color: muted),
              ),
            ],
          ),
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Label('PRIORITAS REVIEW', color: amber),
              const SizedBox(height: 10),
              const SectionTitle('Periksa biaya yang luput'),
              MoneyRow('Kategori Invisible periode ini', leak),
              Text(
                '${period(m)} · sumber jurnal kategori Invisible. Belum diverifikasi sebagai biaya yang bisa dihentikan. Tidak diannualisasi dan bukan penghematan yang telah terjadi.',
                style: const TextStyle(color: muted, fontSize: 13, height: 1.5),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => explain(
                  context,
                  'Review biaya Invisible',
                  l
                          .forEntity('personal', month: m)
                          .where(
                            (e) => e.lines.any((l) => l.account == 'invisible'),
                          )
                          .map(
                            (e) =>
                                '${e.date} · ${e.description}\n${money(e.amount)}',
                          )
                          .join('\n\n')
                          .isEmpty
                      ? 'Belum ada transaksi.'
                      : l
                          .forEntity('personal', month: m)
                          .where(
                            (e) => e.lines.any((l) => l.account == 'invisible'),
                          )
                          .map(
                            (e) =>
                                '${e.date} · ${e.description}\n${money(e.amount)}',
                          )
                          .join('\n\n'),
                ),
                icon: const Icon(Icons.manage_search),
                label: const Text('Tinjau sumber transaksi'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class BusinessScreen extends StatelessWidget {
  final BfiController c;
  final VoidCallback onPricing, onReports, onInput;
  const BusinessScreen(
    this.c, {
    super.key,
    required this.onPricing,
    required this.onReports,
    required this.onInput,
  });
  @override
  Widget build(BuildContext context) {
    final l = c.ledger, m = c.month;
    final sales = l.income('business', m),
        cogs = l.movement('business', ['cogs'], m),
        selling = l.movement('business', ['selling', 'ads'], m),
        other = l.movement('business', ['opex', 'interest', 'depreciation'], m);
    final profit = sales - cogs - selling - other;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Label('WORKSPACE • STUDIO NIAGA', color: teal),
        const SizedBox(height: 10),
        heading('Bisnis yang\nlebih terukur.'),
        subtitle('Laba, biaya, dan kas. Masing-masing punya cerita.'),
        Row(
          children: [
            metric('PENJUALAN BERSIH', sales),
            const SizedBox(width: 10),
            metric('LABA SEBELUM PAJAK', profit, color: teal),
          ],
        ),
        gap(),
        Waterfall(
          labels: const ['Sales', 'HPP', 'Selling', 'OPEX', 'Laba'],
          values: [sales, -cogs, -selling, -other, profit],
          meta:
              '${period(m)} · IDR · termasuk iklan; pajak belum dikonfigurasi',
        ),
        gap(),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Label('SMART PRICING', color: teal),
              const SizedBox(height: 8),
              const Text(
                'Harga yang masuk akal.\nMargin yang terlihat.',
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Uji HPP, fee, iklan dan subsidi ongkir sebelum menentukan harga.',
                style: TextStyle(color: muted, height: 1.5),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: onPricing,
                icon: const Icon(Icons.tune),
                label: const Text('Buka simulasi harga'),
              ),
            ],
          ),
        ),
        gap(),
        Obligations(c),
        gap(),
        Panel(
          child: Column(
            children: [
              const SectionTitle('Kas & modal kerja'),
              MoneyRow('Kas bisnis tersedia', l.cash('business')),
              MoneyRow(
                'Persediaan tercatat',
                l.balance('business', 'inventory'),
              ),
              MoneyRow('Payout tertahan', l.balance('business', 'held')),
              const Text(
                'Runway belum dinilai: historical net cash burn dan pembatasan dana belum diverifikasi.',
                style: TextStyle(fontSize: 12, color: muted),
              ),
            ],
          ),
        ),
        gap(),
        Trend(
          title: 'Tren kas bisnis',
          meta: 'Saldo bank ledger · IDR · bukan kas pribadi',
          values: months(c)
              .map(
                (m) => l.balance(
                  'business',
                  'bank',
                  through: DateTime(m.year, m.month + 1, 0),
                ),
              )
              .toList(),
          labels: months(c).map((m) => monthNames[m.month - 1]).toList(),
        ),
        gap(),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            FilledButton.icon(
              onPressed: onInput,
              icon: const Icon(Icons.add),
              label: const Text('Catat transaksi'),
            ),
            OutlinedButton.icon(
              onPressed: onReports,
              icon: const Icon(Icons.insert_chart_outlined),
              label: const Text('Lihat laporan'),
            ),
          ],
        ),
      ],
    );
  }
}

class Obligations extends StatelessWidget {
  final BfiController c;
  const Obligations(this.c, {super.key});
  @override
  Widget build(BuildContext context) {
    final open = c.entries
        .where(
          (e) =>
              ['invoice', 'supplier'].contains(e.kind) &&
              !c.ledger.reversed(e.id) &&
              c.ledger.outstanding(e) > 0,
        )
        .toList();
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('Piutang & tagihan terbuka'),
          const SizedBox(height: 6),
          const Text(
            'Studio Niaga • saldo outstanding per dokumen',
            style: TextStyle(fontSize: 12, color: muted),
          ),
          const SizedBox(height: 12),
          if (open.isEmpty)
            const Text('Belum ada invoice atau tagihan terbuka.'),
          ...open.map(
            (e) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                backgroundColor: ice,
                child: Icon(
                  e.kind == 'invoice' ? Icons.call_received : Icons.call_made,
                  color: teal,
                  size: 20,
                ),
              ),
              title: Text(e.description, style: const TextStyle(fontSize: 13)),
              subtitle: Text(
                'Tanggal ${e.date} • ${e.kind == 'invoice' ? 'Piutang' : 'Utang'}',
                style: const TextStyle(fontSize: 12),
              ),
              trailing: Text(
                shortMoney(c.ledger.outstanding(e)),
                style: numbers(14),
              ),
              onTap: () => explain(
                context,
                'Dokumen terbuka',
                '${e.description}\nEntitas: ${entities[e.entityId]}\nSisa: ${money(c.ledger.outstanding(e))}\nTanggal: ${e.date}\nJatuh tempo belum dikonfigurasi; aging belum tersedia.\nGunakan Input → Pelunasan untuk mencatat pembayaran.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RecentEntries extends StatelessWidget {
  final BfiController c;
  final String entity;
  final VoidCallback onOpen;
  const RecentEntries(
    this.c, {
    super.key,
    required this.entity,
    required this.onOpen,
  });
  @override
  Widget build(BuildContext context) {
    final list = c.ledger.forEntity(entity, month: c.month).reversed.take(5);
    return Panel(
      child: Column(
        children: [
          SectionTitle(
            'Transaksi terakhir',
            action: TextButton(onPressed: onOpen, child: const Text('Semua')),
          ),
          ...list.map(
            (e) => ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(e.description, style: const TextStyle(fontSize: 13)),
              subtitle: Text(e.date, style: const TextStyle(fontSize: 12)),
              trailing: Text(shortMoney(e.amount), style: numbers(14)),
              onTap: onOpen,
            ),
          ),
          if (list.isEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('Belum ada transaksi pada periode ini.'),
            ),
        ],
      ),
    );
  }
}
