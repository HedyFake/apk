import 'package:flutter/material.dart';

import '../../core/data/controller.dart';
import '../../core/widgets/visuals.dart';

class SettingsPage extends StatefulWidget {
  final BfiController c;
  const SettingsPage(this.c, {super.key});
  @override
  State<SettingsPage> createState() => _SettingsState();
}

class _SettingsState extends State<SettingsPage> {
  final url = TextEditingController(),
      email = TextEditingController(),
      password = TextEditingController();
  String message = '';
  bool busy = false;
  @override
  void dispose() {
    url.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> connect(bool register) async {
    setState(() => busy = true);
    try {
      await widget.c.connect(
        url.text,
        email.text,
        password.text,
        register: register,
      );
      setState(() => message = 'Akun terhubung. Data DEMO tidak ikut disalin.');
    } catch (e) {
      setState(() => message = '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: widget.c,
        builder: (context, _) => Scaffold(
          appBar: AppBar(title: const Text('Pengaturan')),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Image.asset(
                    'assets/branding/bfi_logo.jpg',
                    width: 150,
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Center(
                child: Text(
                  'BFI',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const Center(
                child: Text(
                  'Personal & Business Financial Intelligence',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: muted),
                ),
              ),
              const SizedBox(height: 24),
              Panel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SectionTitle(
                      widget.c.demo ? 'Mode DEMO aktif' : 'Akun server aktif',
                    ),
                    const SizedBox(height: 12),
                    Text(
                      widget.c.demo
                          ? 'Anda dapat mencoba transaksi dan laporan menggunakan data contoh yang tersimpan di perangkat. Data ini terpisah dari akun server.'
                          : 'Draft offline tidak mengubah saldo server. Kirim hanya setelah meninjau transaksi.',
                      style: const TextStyle(color: muted, height: 1.5),
                    ),
                    if (!widget.c.demo)
                      TextButton(
                        onPressed: () async {
                          await widget.c.useDemo();
                        },
                        child: const Text('Keluar & kembali ke DEMO'),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (widget.c.demo)
                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SectionTitle('Hubungkan server BFI'),
                      const SizedBox(height: 8),
                      const Text(
                        'Mode akun nyata memerlukan backend BFI yang sudah dijalankan melalui HTTPS. Server publik belum disediakan pada APK ini.',
                        style:
                            TextStyle(color: muted, fontSize: 13, height: 1.5),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: url,
                        decoration: const InputDecoration(
                          labelText: 'URL server HTTPS',
                          hintText: 'https://bfi.domain-anda.id',
                        ),
                        keyboardType: TextInputType.url,
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: email,
                        decoration: const InputDecoration(labelText: 'Email'),
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: password,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'Password (minimal 12 karakter)',
                        ),
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 10,
                        children: [
                          FilledButton(
                            onPressed: busy ? null : () => connect(false),
                            child: Text(busy ? 'Menghubungkan…' : 'Masuk'),
                          ),
                          OutlinedButton(
                            onPressed: busy ? null : () => connect(true),
                            child: const Text('Daftar akun'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              if (!widget.c.demo) ...[
                const SizedBox(height: 20),
                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SectionTitle('Antrean draft (${widget.c.queue.length})'),
                      ...widget.c.queue.map(
                        (r) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(
                            '${r['id']}',
                            style: const TextStyle(fontSize: 12),
                          ),
                          subtitle: Text(
                            (r['error'] as String).isEmpty
                                ? 'Menunggu konfirmasi kirim'
                                : 'Gagal / perlu review: ${r['error']}',
                          ),
                        ),
                      ),
                      FilledButton(
                        onPressed: widget.c.busy
                            ? null
                            : () async {
                                final yes = await showDialog<bool>(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text('Kirim draft ke server?'),
                                    content: Text(
                                      '${widget.c.queue.length} draft akan divalidasi dan diposting oleh server. Konflik tetap di antrean untuk ditinjau.',
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(ctx, false),
                                        child: const Text('Batal'),
                                      ),
                                      FilledButton(
                                        onPressed: () =>
                                            Navigator.pop(ctx, true),
                                        child: const Text('Kirim'),
                                      ),
                                    ],
                                  ),
                                );
                                if (yes == true)
                                  await widget.c.sync(sendDrafts: true);
                              },
                        child: const Text('Konfirmasi kirim draft'),
                      ),
                      TextButton(
                        onPressed: widget.c.busy ? null : () => widget.c.sync(),
                        child: const Text('Muat ulang data server'),
                      ),
                    ],
                  ),
                ),
              ],
              if (message.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Text(message),
                ),
              const SizedBox(height: 20),
              const Text(
                'Versi 0.1 • Preview MVP\nBelum termasuk koneksi bank/marketplace, tax filing, OCR, multi-gudang, restore cloud, approval multi-user dan skor kesehatan tervalidasi.',
                style: TextStyle(color: muted, fontSize: 12, height: 1.6),
              ),
            ],
          ),
        ),
      );
}
