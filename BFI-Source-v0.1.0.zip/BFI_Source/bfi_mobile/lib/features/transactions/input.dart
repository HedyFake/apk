import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/data/controller.dart';
import '../../core/domain/ledger.dart';
import '../../core/widgets/visuals.dart';

class InputPage extends StatefulWidget {
  final BfiController c;
  const InputPage(this.c, {super.key});
  @override
  State<InputPage> createState() => _InputState();
}

class _InputState extends State<InputPage> {
  final form = GlobalKey<FormState>(),
      amount = TextEditingController(),
      note = TextEditingController(),
      cost = TextEditingController(text: '0');
  late String entity;
  String kind = 'expense', category = 'direct', source = '';
  DateTime date = DateTime.now();
  bool saving = false;
  String error = '';
  @override
  void initState() {
    super.initState();
    entity = widget.c.entity;
  }

  @override
  void dispose() {
    amount.dispose();
    note.dispose();
    cost.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (!form.currentState!.validate()) return;
    setState(() => error = '');
    try {
      final d = TransactionDraft(
        entityId: entity,
        date: dateOnly(date),
        kind: kind,
        category: category,
        note: note.text,
        amount: int.parse(amount.text),
        cost: int.tryParse(cost.text) ?? 0,
        sourceId: source,
      );
      widget.c.ledger.validateDraft(d);
      final preview = mapTransaction(d);
      final yes = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(
            widget.c.demo
                ? 'Konfirmasi transaksi DEMO'
                : 'Simpan draft transaksi',
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${entities[entity]} • ${d.date}\n${d.note}\n${money(d.amount)}',
                ),
                const SizedBox(height: 16),
                ...preview.expand(
                  (e) => [
                    Text(
                      entities[e.entityId]!,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    ...e.lines.map(
                      (l) => Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          '${l.debit > 0 ? 'D' : 'K'} · ${accounts[l.account]}\n${money(l.debit + l.credit)}',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
                Text(
                  widget.c.demo
                      ? 'D = K • disimpan ke ledger DEMO lokal.'
                      : 'Draft belum mengubah ledger. Pengiriman ke server memerlukan konfirmasi terpisah.',
                  style: const TextStyle(fontSize: 12, color: muted),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Kembali'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Konfirmasi'),
            ),
          ],
        ),
      );
      if (yes != true || !mounted) return;
      setState(() => saving = true);
      final message = await widget.c.save(d);
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(message)));
      Navigator.pop(context);
    } catch (e) {
      if (mounted)
        setState(
          () => error = e.toString().replaceFirst('FormatException: ', ''),
        );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final businessOnly = [
      'stock',
      'sale',
      'invoice',
      'collect',
      'supplier',
      'pay_supplier',
    ];
    final kinds = transactionKinds.entries.where(
      (e) =>
          (!businessOnly.contains(e.key) || entity == 'business') &&
          (e.key != 'owner_loan' || entity == 'personal'),
    );
    final sources = widget.c.entries.where(
      (e) =>
          e.entityId == entity &&
          e.kind == (kind == 'collect' ? 'invoice' : 'supplier') &&
          !widget.c.ledger.reversed(e.id) &&
          widget.c.ledger.outstanding(e) > 0,
    );
    return Scaffold(
      appBar: AppBar(title: const Text('Catat transaksi')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: Form(
                key: form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Label(
                      widget.c.demo
                          ? 'MODE DEMO • TERSIMPAN DI PERANGKAT'
                          : 'DRAFT • BELUM DIPOSTING',
                    ),
                    const SizedBox(height: 20),
                    DropdownButtonFormField<String>(
                      initialValue: entity,
                      decoration: const InputDecoration(
                        labelText: 'Entitas pemilik transaksi',
                      ),
                      items: entities.entries
                          .map(
                            (e) => DropdownMenuItem(
                              value: e.key,
                              child: Text(e.value),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setState(() {
                        entity = v!;
                        category = 'direct';
                        kind = 'expense';
                        source = '';
                      }),
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      key: ValueKey('kind-$entity'),
                      initialValue: kind,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Jenis transaksi',
                      ),
                      items: kinds
                          .map(
                            (e) => DropdownMenuItem(
                              value: e.key,
                              child: Text(
                                e.value,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setState(() {
                        kind = v!;
                        source = '';
                      }),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: amount,
                      decoration: const InputDecoration(
                        labelText: 'Nominal rupiah',
                        prefixText: 'Rp ',
                        helperText:
                            'Rupiah penuh, tanpa titik/koma. Maksimal 100 triliun.',
                      ),
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(15),
                      ],
                      validator: (v) => int.tryParse(v ?? '') == null ||
                              (int.tryParse(v ?? '') ?? 0) <= 0
                          ? 'Isi nominal lebih dari nol.'
                          : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: note,
                      decoration: const InputDecoration(
                        labelText: 'Uraian transaksi',
                        hintText: 'Contoh: belanja kebutuhan keluarga',
                      ),
                      maxLength: 180,
                      validator: (v) => (v ?? '').trim().isEmpty
                          ? 'Isi uraian transaksi.'
                          : null,
                    ),
                    if (['sale', 'invoice'].contains(kind)) ...[
                      TextFormField(
                        controller: cost,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: const InputDecoration(
                          labelText: 'HPP barang keluar (Rp)',
                          helperText:
                              'HPP manual dari persediaan; bukan biaya iklan atau fee.',
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                    if (['expense', 'card_purchase'].contains(kind)) ...[
                      DropdownButtonFormField<String>(
                        key: ValueKey('category-$entity'),
                        initialValue: category,
                        decoration: const InputDecoration(
                          labelText: 'Kategori utama',
                        ),
                        items: [
                          ...categories,
                          if (entity == 'business') ...[
                            'selling',
                            'ads',
                            'opex',
                          ],
                        ]
                            .map(
                              (a) => DropdownMenuItem(
                                value: a,
                                child: Text(accounts[a]!),
                              ),
                            )
                            .toList(),
                        onChanged: (v) => setState(() => category = v!),
                      ),
                      const SizedBox(height: 16),
                    ],
                    if (['collect', 'pay_supplier'].contains(kind)) ...[
                      DropdownButtonFormField<String>(
                        key: ValueKey('source-$entity-$kind'),
                        initialValue: source.isEmpty ? null : source,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Invoice / tagihan yang dilunasi',
                        ),
                        items: sources
                            .map(
                              (e) => DropdownMenuItem(
                                value: e.id,
                                child: Text(
                                  '${e.description} · ${shortMoney(widget.c.ledger.outstanding(e))}',
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (v) => setState(() => source = v!),
                        validator: (v) => v == null
                            ? 'Pilih dokumen yang akan dilunasi.'
                            : null,
                      ),
                      const SizedBox(height: 16),
                    ],
                    OutlinedButton.icon(
                      onPressed: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: date,
                          firstDate: DateTime(2020),
                          lastDate: DateTime.now(),
                        );
                        if (d != null) setState(() => date = d);
                      },
                      icon: const Icon(Icons.calendar_today_outlined, size: 17),
                      label: Text('Tanggal ${dateOnly(date)}'),
                    ),
                    const SizedBox(height: 20),
                    if (kind == 'owner_loan')
                      const Panel(
                        child: Text(
                          'Kas pribadi berkurang dan menjadi piutang. Kas bisnis bertambah dan menjadi utang kepada pemilik. Dua jurnal akan ditautkan; bukan pendapatan.',
                          style: TextStyle(height: 1.5),
                        ),
                      ),
                    if (error.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Text(error, style: const TextStyle(color: red)),
                      ),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: saving ? null : save,
                        icon: saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.check),
                        label: Text(saving ? 'Menyimpan…' : 'Tinjau & simpan'),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Saldo dihitung dari jurnal. Transaksi yang sudah tersimpan dikoreksi melalui pembalikan, bukan dihapus.',
                      style: TextStyle(fontSize: 12, color: muted),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
