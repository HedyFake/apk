import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:drift/native.dart';
import 'package:bfi_mobile/app/app.dart';
import 'package:bfi_mobile/core/data/controller.dart';
import 'package:bfi_mobile/core/data/store.dart';
import 'package:bfi_mobile/features/reports/reports.dart';
import 'package:bfi_mobile/features/pricing/pricing.dart';
import 'package:bfi_mobile/features/transactions/input.dart';
import 'package:bfi_mobile/features/settings/settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    await (FontLoader('MaterialIcons')
          ..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf')))
        .load();
    final font = File('C:/Windows/Fonts/arial.ttf');
    if (await font.exists()) {
      final bytes = await font.readAsBytes();
      for (final name in ['Roboto', 'sans-serif']) {
        await (FontLoader(name)
              ..addFont(Future.value(ByteData.sublistView(bytes))))
            .load();
      }
    }
  });
  for (final width in [360.0, 390.0, 430.0]) {
    testWidgets('all routes render and scroll at ${width.toInt()}px',
        (tester) async {
      tester.view.physicalSize = Size(width, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final db = BfiDatabase(NativeDatabase.memory());
      final c = BfiController(db);
      c.entries = demoSeed(DateTime(2026, 11, 5));
      c.month = DateTime(2026, 11);
      await tester.pumpWidget(
          RepaintBoundary(key: const ValueKey('screen'), child: BfiApp(c)));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      for (final label in ['Ringkasan', 'Pribadi', 'Bisnis', 'Insight']) {
        await tester.tap(find.text(label).last);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull, reason: label);
        if (width == 390)
          await expectLater(find.byKey(const ValueKey('screen')),
              matchesGoldenFile('screenshots/$label.png'));
        for (var i = 0; i < 6; i++) {
          await tester.drag(
              find.byType(SingleChildScrollView).first, const Offset(0, -550));
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull, reason: '$label scroll $i');
        }
      }
      for (final entry in <String, Widget>{
        'Laporan': ReportsPage(c),
        'Jurnal': JournalPage(c),
        'Aset': AssetsPage(c),
        'Harga': PricingPage(c),
        'Transaksi': InputPage(c),
        'Pengaturan': SettingsPage(c)
      }.entries) {
        Navigator.of(tester.element(find.byType(BfiShell)))
            .push(MaterialPageRoute<void>(builder: (_) => entry.value));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull, reason: entry.key);
        if (width == 390)
          await expectLater(find.byKey(const ValueKey('screen')),
              matchesGoldenFile('screenshots/${entry.key}.png'));
        for (var i = 0; i < 5; i++) {
          final scrolls = find.byType(Scrollable);
          if (scrolls.evaluate().isNotEmpty) {
            await tester.drag(scrolls.first, const Offset(0, -500));
            await tester.pumpAndSettle();
          }
          expect(tester.takeException(), isNull,
              reason: '${entry.key} scroll $i');
        }
        Navigator.of(tester.element(find.byWidget(entry.value))).pop();
        await tester.pumpAndSettle();
      }
      await tester.pumpWidget(const SizedBox());
      c.dispose();
      await db.close();
    });
  }
}
