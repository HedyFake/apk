import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:drift/native.dart';
import 'package:bfi_mobile/core/domain/ledger.dart';
import 'package:bfi_mobile/core/data/store.dart';
import 'package:bfi_mobile/core/data/controller.dart';

TransactionDraft draft(String kind, int amount,
        {String entity = 'personal', int cost = 0, String source = ''}) =>
    TransactionDraft(
        entityId: entity,
        date: '2026-11-05',
        kind: kind,
        amount: amount,
        cost: cost,
        sourceId: source,
        note: 'Pengujian $kind');
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('every demo journal balances; all entities remain isolated', () {
    final entries = demoSeed(DateTime(2026, 11, 5));
    for (final e in entries) {
      expect(e.validate, returnsNormally);
    }
    final l = Ledger(entries);
    for (final entity in entities.keys) {
      expect(accounts.keys.fold<int>(0, (n, a) => n + l.balance(entity, a)), 0);
    }
    expect(l.cash('household'), 8000000);
    expect(l.cash('personal'), isNot(l.cash('business')));
  });
  test('loan principal is never income or expense', () {
    final received = mapTransaction(draft('loan_receive', 1000000));
    final l = Ledger(received);
    expect(l.income('personal', DateTime(2026, 11)), 0);
    expect(l.balance('personal', 'loan'), -1000000);
    final repayment = draft('loan_repay', 250000);
    l.validateDraft(repayment);
    final result = Ledger([...received, ...mapTransaction(repayment)]);
    expect(result.balance('personal', 'loan'), -750000);
    expect(result.spending('personal', DateTime(2026, 11)), 0);
    expect(() => result.validateDraft(draft('loan_repay', 800000)),
        throwsFormatException);
  });
  test('credit card settlement does not expense twice', () {
    final entries = [
      ...mapTransaction(draft('active', 2000000)),
      ...mapTransaction(draft('card_purchase', 500000))
    ];
    final payment = draft('card_payment', 500000);
    Ledger(entries).validateDraft(payment);
    final l = Ledger([...entries, ...mapTransaction(payment)]);
    expect(l.spending('personal', DateTime(2026, 11)), 500000);
    expect(l.cash('personal'), 1500000);
    expect(l.balance('personal', 'card'), 0);
  });
  test('invoice settlement credits receivable, not revenue', () {
    final entries = [
      ...mapTransaction(draft('loan_receive', 2000000, entity: 'business')),
      ...mapTransaction(draft('stock', 1000000, entity: 'business'))
    ];
    final invoice = mapTransaction(
            draft('invoice', 900000, entity: 'business', cost: 400000))
        .single;
    entries.add(invoice);
    final collect =
        draft('collect', 600000, entity: 'business', source: invoice.id);
    Ledger(entries).validateDraft(collect);
    entries.addAll(mapTransaction(collect));
    final l = Ledger(entries);
    expect(l.income('business', DateTime(2026, 11)), 900000);
    expect(l.outstanding(invoice), 300000);
    expect(l.balance('business', 'inventory'), 600000);
    expect(
        () => l.validateDraft(
            draft('collect', 300001, entity: 'business', source: invoice.id)),
        throwsFormatException);
    expect(
        () => l.validateDraft(
            draft('collect', 100000, entity: 'personal', source: invoice.id)),
        throwsFormatException);
  });
  test('owner loan has two balanced reciprocal journals', () {
    final pair = mapTransaction(draft('owner_loan', 2000000));
    expect(pair.length, 2);
    expect(pair[0].pairId, pair[1].pairId);
    for (final e in pair) {
      e.validate();
    }
    final l = Ledger(pair);
    expect(l.balance('personal', 'owner_ar'), 2000000);
    expect(l.balance('business', 'owner_ap'), -2000000);
    expect(l.income('business', DateTime(2026, 11)), 0);
  });
  test('invalid journal and insufficient cash are rejected', () {
    expect(() => Ledger([]).validateDraft(draft('expense', 100)),
        throwsFormatException);
    expect(() => mapTransaction(draft('active', 0)), throwsFormatException);
    final e = Entry(
        id: 'bad',
        entityId: 'personal',
        date: '2026-11-05',
        description: 'bad',
        kind: 'test',
        createdAt: 'now',
        lines: [JournalLine('bank', 100, 0), JournalLine('equity', 0, 99)]);
    expect(e.validate, throwsFormatException);
  });
  test('pricing includes ads and subtracts seller discount once', () {
    final r = price(
        price: 200000,
        discount: 20000,
        hpp: 80000,
        packaging: 5000,
        ops: 5000,
        shipping: 10000,
        ads: 20000,
        feeBps: 1000,
        target: 30000);
    expect(r.netSales, 180000);
    expect(r.fee, 18000);
    expect(r.profit, 42000);
    expect(r.buffer, 12000);
    expect(r.requiredPrice, 186667);
    expect(r.maxSubsidy, 22000);
    expect(
        () => price(
            price: 1,
            discount: 0,
            hpp: 0,
            packaging: 0,
            ops: 0,
            shipping: 0,
            ads: 0,
            feeBps: 10000,
            target: 0),
        throwsFormatException);
  });
  test('SQLite survives reopen, mode isolation and reversal audit', () async {
    final dir = await Directory.systemTemp.createTemp('bfi-test-');
    final file = File('${dir.path}/ledger.sqlite');
    var db = BfiDatabase(NativeDatabase(file));
    var c = BfiController(db);
    await c.init();
    final before = c.ledger.cash('personal');
    final d = draft('active', 123456);
    await c.save(d);
    expect(c.ledger.cash('personal'), before + 123456);
    final original = c.entries.firstWhere((e) => e.id == d.id);
    await c.reverse(original, 'Salah nominal pengujian');
    expect(c.ledger.cash('personal'), before);
    expect(c.audit.first['action'], 'REVERSE_DEMO');
    expect(
        () => c.reverse(original, 'Ulang pembalikan'), throwsFormatException);
    await db.enqueue('live:test:user', draft('active', 100));
    expect(await db.pending('demo'), isEmpty);
    expect(await db.load('live:test:user'), isEmpty);
    c.dispose();
    await db.close();
    db = BfiDatabase(NativeDatabase(file));
    expect((await db.load('demo')).any((e) => e.reverses == d.id), isTrue);
    expect((await db.pending('live:test:user')).length, 1);
    await db.close();
    await dir.delete(recursive: true);
  });
  test('atomic batch rolls back when second journal conflicts', () async {
    final db = BfiDatabase(NativeDatabase.memory());
    final entry = mapTransaction(draft('active', 100)).single;
    await expectLater(db.append('demo', [entry, entry]), throwsA(anything));
    expect(await db.load('demo'), isEmpty);
    expect(await db.events('demo'), isEmpty);
    await db.close();
  });
}
