import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:drift/native.dart';
import 'package:bfi_mobile/app/app.dart';
import 'package:bfi_mobile/core/data/controller.dart';
import 'package:bfi_mobile/core/data/store.dart';

void main() {
  testWidgets('input validates, confirms, persists, updates ledger and audit',
      (tester) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final db = BfiDatabase(NativeDatabase.memory());
    final c = BfiController(db);
    await tester.runAsync(() => c.init());
    final before = c.ledger.cash('personal');
    await tester.pumpWidget(BfiApp(c));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Input'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('Tinjau & simpan'));
    await tester.tap(find.text('Tinjau & simpan'));
    await tester.pumpAndSettle();
    expect(find.text('Isi nominal lebih dari nol.'), findsOneWidget);
    Finder field(String label) => find.widgetWithText(TextFormField, label);
    await tester.enterText(field('Nominal rupiah'), '125000');
    await tester.enterText(field('Uraian transaksi'), 'QA kebutuhan rumah');
    await tester.ensureVisible(find.text('Tinjau & simpan'));
    await tester.tap(find.text('Tinjau & simpan'));
    await tester.pumpAndSettle();
    expect(find.text('Konfirmasi transaksi DEMO'), findsOneWidget);
    await tester.runAsync(() async {
      await tester.tap(find.text('Konfirmasi'));
    });
    await tester.pumpAndSettle();
    await tester.runAsync(() => c.reload());
    await tester.pumpAndSettle();
    expect(c.ledger.cash('personal'), before - 125000);
    expect(c.entries.where((e) => e.description == 'QA kebutuhan rumah').length,
        1);
    expect(c.audit.first['action'], 'POST_DEMO');
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    c.dispose();
    await db.close();
  });
}
