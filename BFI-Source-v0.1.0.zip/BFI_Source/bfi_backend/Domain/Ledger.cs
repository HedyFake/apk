namespace Bfi.Domain;

public record Line(string Account,long Debit,long Credit);
public record Journal(string Id,string EntityId,string Date,string Description,string Kind,List<Line> Lines,string Category="",string PairId="",string Reverses="",string SourceId="",string CreatedAt="");
public record TransactionDto(string Id,string EntityId,string Date,string Kind,string Category,string Note,long Amount,long Cost=0,string SourceId="");
public static class FinancialEngine {
 public static readonly string[] Entities=["personal","household","business"];
 public static readonly string[] Assets=["bank","reserve","held","ar","inventory","fixed","owner_ar","investment","accum"];
 public static readonly string[] Liabilities=["ap","card","loan","owner_ap"];
 public static readonly string[] Income=["active","passive","sales"];
 public static readonly string[] Expenses=["productive","direct","recurring","invisible","giving","cogs","selling","ads","opex","interest","depreciation"];
 public static readonly string[] Accounts=[..Assets,..Liabilities,"equity",..Income,..Expenses];
 public static void Validate(Journal j) {
  if(!Entities.Contains(j.EntityId)||j.Lines.Count<2||string.IsNullOrWhiteSpace(j.Description))throw new ArgumentException("Jurnal tidak valid.");
  if(j.Lines.Any(l=>!Accounts.Contains(l.Account)||l.Debit<0||l.Credit<0||(l.Debit>0)==(l.Credit>0)))throw new ArgumentException("Baris jurnal tidak valid.");
  if(j.Lines.Sum(l=>(decimal)l.Debit-l.Credit)!=0)throw new ArgumentException("Debit dan kredit tidak seimbang.");
 }
 public static long Balance(IEnumerable<Journal> ledger,string entity,string account)=>ledger.Where(j=>j.EntityId==entity).SelectMany(j=>j.Lines).Where(l=>l.Account==account).Sum(l=>l.Debit-l.Credit);
 public static List<Journal> Map(TransactionDto d) {
  if(!Entities.Contains(d.EntityId)||string.IsNullOrWhiteSpace(d.Id)||d.Id.Length>100||string.IsNullOrWhiteSpace(d.Note)||d.Note.Length>180||d.Amount<=0||d.Amount>100_000_000_000_000L||d.Cost<0||d.Cost>100_000_000_000_000L)throw new ArgumentException("Data transaksi tidak valid.");
  if(!DateOnly.TryParseExact(d.Date,"yyyy-MM-dd",out var date)||date>DateOnly.FromDateTime(DateTime.UtcNow.AddHours(7))||date.Year<2020)throw new ArgumentException("Tanggal transaksi tidak valid.");
  if(new[]{"stock","sale","invoice","collect","supplier","pay_supplier"}.Contains(d.Kind)&&d.EntityId!="business")throw new ArgumentException("Khusus entitas bisnis.");
  List<Line> Pair(string debit,string credit,long amount)=>[new(debit,amount,0),new(credit,0,amount)];
  Journal Entry(string entity,List<Line> lines,string pair="")=>new(entity==d.EntityId?d.Id:d.Id+"-mirror",entity,d.Date,d.Note.Trim(),d.Kind,lines,d.Category,pair,"",d.SourceId,DateTime.UtcNow.ToString("O"));
  List<Line> lines;
  switch(d.Kind){
   case "active":case "passive":lines=Pair("bank",d.Kind,d.Amount);break;
   case "expense":case "card_purchase":
    if(!new[]{"productive","direct","recurring","invisible","giving","selling","ads","opex"}.Contains(d.Category))throw new ArgumentException("Kategori tidak valid.");
    lines=Pair(d.Category,d.Kind=="expense"?"bank":"card",d.Amount);break;
   case "reserve":lines=Pair("reserve","bank",d.Amount);break;
   case "card_payment":lines=Pair("card","bank",d.Amount);break;
   case "loan_receive":lines=Pair("bank","loan",d.Amount);break;
   case "loan_repay":lines=Pair("loan","bank",d.Amount);break;
   case "interest":lines=Pair("interest","bank",d.Amount);break;
   case "stock":lines=Pair("inventory","bank",d.Amount);break;
   case "supplier":lines=Pair("inventory","ap",d.Amount);break;
   case "pay_supplier":lines=Pair("ap","bank",d.Amount);break;
   case "collect":lines=Pair("bank","ar",d.Amount);break;
   case "sale":case "invoice":
    if(d.Cost<=0)throw new ArgumentException("HPP wajib diisi.");
    lines=[..Pair(d.Kind=="sale"?"bank":"ar","sales",d.Amount),..Pair("cogs","inventory",d.Cost)];break;
   case "owner_loan":
    if(d.EntityId!="personal")throw new ArgumentException("Pinjaman pemilik dimulai dari Pribadi.");
    return [Entry("personal",Pair("owner_ar","bank",d.Amount),d.Id),Entry("business",Pair("bank","owner_ap",d.Amount),d.Id)];
   default:throw new ArgumentException("Jenis transaksi belum didukung.");
  }
  var result=Entry(d.EntityId,lines);Validate(result);return [result];
 }
 public static long Outstanding(IEnumerable<Journal> ledger,Journal source){var ar=source.Kind=="invoice";return ledger.Where(j=>j.Id==source.Id||j.SourceId==source.Id||j.Reverses==source.Id).SelectMany(j=>j.Lines).Where(l=>l.Account==(ar?"ar":"ap")).Sum(l=>(ar?1:-1)*(l.Debit-l.Credit));}
 public static void ValidateDraft(List<Journal> existing,TransactionDto d){
  if(d.Kind is "collect" or "pay_supplier"){
   var s=existing.FirstOrDefault(j=>j.Id==d.SourceId&&j.EntityId==d.EntityId&&j.Kind==(d.Kind=="collect"?"invoice":"supplier")&&!existing.Any(x=>x.Reverses==j.Id));
   if(s is null||d.Amount>Outstanding(existing,s))throw new ArgumentException("Invoice tidak ditemukan atau pembayaran melebihi saldo.");
  }
  var account=d.Kind=="card_payment"?"card":d.Kind=="loan_repay"?"loan":null;
  if(account!=null&&d.Amount > -Balance(existing,d.EntityId,account))throw new ArgumentException("Pembayaran melebihi kewajiban.");
  ValidateBatch(existing,Map(d));
 }
 public static void ValidateBatch(List<Journal> existing,List<Journal> batch){
  foreach(var j in batch){Validate(j);if(existing.Any(e=>e.Id==j.Id))throw new ArgumentException("Jurnal sudah ada.");}
  var next=existing.Concat(batch).ToList();
  foreach(var e in batch)foreach(var a in new[]{"bank","reserve","inventory"})if(Balance(next,e.EntityId,a)<0)throw new ArgumentException("Saldo "+a+" tidak cukup.");
 }
 public static (decimal Profit,decimal Buffer,decimal RequiredPrice) Price(decimal selling,decimal discount,decimal fixedCosts,decimal feeRate,decimal target){
  if(selling<0||discount<0||discount>selling||fixedCosts<0||feeRate<0||feeRate>=1||target<0)throw new ArgumentException("Asumsi harga tidak valid.");
  var net=selling-discount;var fee=decimal.Round(net*feeRate,0,MidpointRounding.AwayFromZero);var profit=net-fixedCosts-fee;
  return (profit,profit-target,decimal.Ceiling((fixedCosts+target)/(1-feeRate))+discount);
 }
}
