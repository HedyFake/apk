using System.Text.Json;
using Bfi.Domain;
using Npgsql;
namespace Bfi.Infrastructure;
public sealed class Repository(NpgsqlDataSource source){
 public static readonly JsonSerializerOptions Json=new(JsonSerializerDefaults.Web);
 public async Task<List<Journal>> Journals(Guid user,NpgsqlConnection? connection=null,NpgsqlTransaction? tx=null){
  var owned=connection is null;var c=connection??await source.OpenConnectionAsync();
  try{await using var cmd=new NpgsqlCommand("SELECT payload::text FROM journals WHERE user_id=@u ORDER BY payload->>'date',id",c,tx);cmd.Parameters.AddWithValue("u",user);await using var reader=await cmd.ExecuteReaderAsync();var rows=new List<Journal>();while(await reader.ReadAsync())rows.Add(JsonSerializer.Deserialize<Journal>(reader.GetString(0),Json)!);return rows;}finally{if(owned)await c.DisposeAsync();}
 }
 public async Task<bool> Commit(Guid user,string key,string hash,Func<List<Journal>,List<Journal>> build,string action,string reason){
  await using var c=await source.OpenConnectionAsync();await using var tx=await c.BeginTransactionAsync();
  await using(var mutex=new NpgsqlCommand("SELECT pg_advisory_xact_lock(hashtextextended(@u,0))",c,tx)){mutex.Parameters.AddWithValue("u",user.ToString());await mutex.ExecuteNonQueryAsync();}
  await using(var prior=new NpgsqlCommand("SELECT request_hash FROM idempotency WHERE user_id=@u AND key=@k",c,tx)){prior.Parameters.AddWithValue("u",user);prior.Parameters.AddWithValue("k",key);var stored=await prior.ExecuteScalarAsync();if(stored is string s){if(s!=hash)throw new ArgumentException("Idempotency key digunakan untuk isi berbeda.");return false;}}
  var existing=await Journals(user,c,tx);var entries=build(existing);FinancialEngine.ValidateBatch(existing,entries);
  foreach(var j in entries){
   await using(var period=new NpgsqlCommand("SELECT closed FROM accounting_periods WHERE user_id=@u AND entity_id=@e AND month=@m",c,tx)){period.Parameters.AddWithValue("u",user);period.Parameters.AddWithValue("e",j.EntityId);period.Parameters.AddWithValue("m",j.Date[..7]);if(await period.ExecuteScalarAsync() is true)throw new ArgumentException("Periode sudah ditutup.");}
   await using(var insert=new NpgsqlCommand("INSERT INTO journals(user_id,entity_id,id,payload) VALUES(@u,@e,@id,@p::jsonb)",c,tx)){insert.Parameters.AddWithValue("u",user);insert.Parameters.AddWithValue("e",j.EntityId);insert.Parameters.AddWithValue("id",j.Id);insert.Parameters.AddWithValue("p",JsonSerializer.Serialize(j,Json));await insert.ExecuteNonQueryAsync();}
   for(int i=0;i<j.Lines.Count;i++){var l=j.Lines[i];await using var line=new NpgsqlCommand("INSERT INTO journal_lines VALUES(@u,@e,@id,@n,@a,@d,@c)",c,tx);line.Parameters.AddWithValue("u",user);line.Parameters.AddWithValue("e",j.EntityId);line.Parameters.AddWithValue("id",j.Id);line.Parameters.AddWithValue("n",i);line.Parameters.AddWithValue("a",l.Account);line.Parameters.AddWithValue("d",(decimal)l.Debit);line.Parameters.AddWithValue("c",(decimal)l.Credit);await line.ExecuteNonQueryAsync();}
  }
  await using(var audit=new NpgsqlCommand("INSERT INTO audit_events(id,user_id,action,reason,source_ids) VALUES(@id,@u,@a,@r,@s::jsonb)",c,tx)){audit.Parameters.AddWithValue("id",Guid.NewGuid());audit.Parameters.AddWithValue("u",user);audit.Parameters.AddWithValue("a",action);audit.Parameters.AddWithValue("r",reason);audit.Parameters.AddWithValue("s",JsonSerializer.Serialize(entries.Select(e=>e.Id)));await audit.ExecuteNonQueryAsync();}
  await using(var remember=new NpgsqlCommand("INSERT INTO idempotency VALUES(@u,@k,@h)",c,tx)){remember.Parameters.AddWithValue("u",user);remember.Parameters.AddWithValue("k",key);remember.Parameters.AddWithValue("h",hash);await remember.ExecuteNonQueryAsync();}
  await tx.CommitAsync();return true;
 }
}
