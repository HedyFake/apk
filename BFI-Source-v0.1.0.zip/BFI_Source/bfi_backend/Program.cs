using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.RateLimiting;
using Bfi.Domain;
using Bfi.Infrastructure;
using Npgsql;

var builder=WebApplication.CreateBuilder(args);
var connection=builder.Configuration.GetConnectionString("Bfi")??throw new InvalidOperationException("Set ConnectionStrings__Bfi; lihat .env.example.");
builder.Services.AddSingleton(NpgsqlDataSource.Create(connection));
builder.Services.AddScoped<Repository>();
builder.Services.AddProblemDetails();
builder.Services.AddRateLimiter(o=>{o.RejectionStatusCode=429;o.AddPolicy("auth",ctx=>RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString()??"unknown",_=>new FixedWindowRateLimiterOptions{PermitLimit=12,Window=TimeSpan.FromMinutes(1),QueueLimit=0}));});
var app=builder.Build();
if(builder.Configuration["BFI_APPLY_MIGRATIONS"]=="true"){
 await using var c=await app.Services.GetRequiredService<NpgsqlDataSource>().OpenConnectionAsync();
 await using var cmd=new NpgsqlCommand(await File.ReadAllTextAsync(Path.Combine(app.Environment.ContentRootPath,"migrations","001_initial.sql")),c);await cmd.ExecuteNonQueryAsync();
}
app.UseRateLimiter();
app.Use(async(ctx,next)=>{
 try{
  if(!app.Environment.IsDevelopment()&&!ctx.Request.IsHttps){ctx.Response.StatusCode=400;await ctx.Response.WriteAsJsonAsync(new{detail="HTTPS diperlukan."});return;}
  if(ctx.Request.Path.StartsWithSegments("/api/v1")&&!ctx.Request.Path.StartsWithSegments("/api/v1/auth")){
   var header=ctx.Request.Headers.Authorization.ToString();if(!header.StartsWith("Bearer ")){ctx.Response.StatusCode=401;return;}
   var token=header[7..];if(token.Length>256){ctx.Response.StatusCode=401;return;}
   await using var c=await ctx.RequestServices.GetRequiredService<NpgsqlDataSource>().OpenConnectionAsync();
   await using var cmd=new NpgsqlCommand("SELECT user_id FROM sessions WHERE token_hash=@h AND expires_at>now()",c);cmd.Parameters.AddWithValue("h",Hash(token));var user=await cmd.ExecuteScalarAsync();
   if(user is not Guid id){ctx.Response.StatusCode=401;return;}ctx.Items["user"]=id;
  }
  await next();
 }catch(ArgumentException e){ctx.Response.StatusCode=422;await ctx.Response.WriteAsJsonAsync(new{title="Validasi gagal",detail=e.Message});}
 catch(PostgresException e) when(e.SqlState=="23505"){ctx.Response.StatusCode=409;await ctx.Response.WriteAsJsonAsync(new{detail="Data sudah ada atau permintaan duplikat."});}
 catch(Exception e){app.Logger.LogError("Request failed with {ErrorType}; trace {TraceId}",e.GetType().Name,ctx.TraceIdentifier);ctx.Response.StatusCode=500;await ctx.Response.WriteAsJsonAsync(new{detail="Operasi gagal. Tidak ada konfirmasi posting. Gunakan ID permintaan yang sama untuk retry.",traceId=ctx.TraceIdentifier});}
});
app.MapGet("/health",()=>Results.Ok(new{service="BFI API",version="v1"}));
app.MapPost("/api/v1/auth/{operation}",async(string operation,Credentials credentials,NpgsqlDataSource source)=>{
 if(operation is not ("register" or "login"))return Results.NotFound();
 var email=credentials.Email.Trim().ToLowerInvariant();if(!email.Contains('@')||email.Length>254||credentials.Password.Length<12||credentials.Password.Length>128)throw new ArgumentException("Email valid dan password 12–128 karakter diperlukan.");
 await using var c=await source.OpenConnectionAsync();Guid user;
 if(operation=="register"){
  user=Guid.NewGuid();await using var tx=await c.BeginTransactionAsync();
  await using(var cmd=new NpgsqlCommand("INSERT INTO users(id,email,password_hash) VALUES(@u,@e,@p)",c,tx)){cmd.Parameters.AddWithValue("u",user);cmd.Parameters.AddWithValue("e",email);cmd.Parameters.AddWithValue("p",PasswordHash(credentials.Password));await cmd.ExecuteNonQueryAsync();}
  foreach(var entity in FinancialEngine.Entities){await using(var cmd=new NpgsqlCommand("INSERT INTO entities VALUES(@u,@e,@e)",c,tx)){cmd.Parameters.AddWithValue("u",user);cmd.Parameters.AddWithValue("e",entity);await cmd.ExecuteNonQueryAsync();}
   foreach(var code in FinancialEngine.Accounts){await using var cmd=new NpgsqlCommand("INSERT INTO chart_of_accounts VALUES(@u,@e,@a)",c,tx);cmd.Parameters.AddWithValue("u",user);cmd.Parameters.AddWithValue("e",entity);cmd.Parameters.AddWithValue("a",code);await cmd.ExecuteNonQueryAsync();}}
  await tx.CommitAsync();
 }else{
  await using var cmd=new NpgsqlCommand("SELECT id,password_hash FROM users WHERE email=@e",c);cmd.Parameters.AddWithValue("e",email);await using var reader=await cmd.ExecuteReaderAsync();if(!await reader.ReadAsync())return Results.Unauthorized();user=reader.GetGuid(0);if(!PasswordVerify(credentials.Password,reader.GetString(1)))return Results.Unauthorized();
 }
 var token=Convert.ToHexString(RandomNumberGenerator.GetBytes(32));var expires=DateTime.UtcNow.AddMinutes(30);
 await using(var cmd=new NpgsqlCommand("INSERT INTO sessions VALUES(@t,@u,@e)",c)){cmd.Parameters.AddWithValue("t",Hash(token));cmd.Parameters.AddWithValue("u",user);cmd.Parameters.AddWithValue("e",expires);await cmd.ExecuteNonQueryAsync();}
 return Results.Ok(new{token,userId=user,expiresAt=expires});
}).RequireRateLimiting("auth");
app.MapGet("/api/v1/entities",()=>FinancialEngine.Entities);
app.MapGet("/api/v1/journals",async(HttpContext ctx,Repository repo)=>await repo.Journals(User(ctx)));
app.MapPost("/api/v1/transactions",async(HttpContext ctx,TransactionDto d,Repository repo)=>{
 var key=ctx.Request.Headers["Idempotency-Key"].ToString();if(key!=d.Id)throw new ArgumentException("Idempotency-Key harus sama dengan ID transaksi.");
 var created=await repo.Commit(User(ctx),key,Hash(JsonSerializer.Serialize(d,Repository.Json)),existing=>{FinancialEngine.ValidateDraft(existing,d);return FinancialEngine.Map(d);},"POST_TRANSACTION",d.Note);
 return Results.Ok(new{id=d.Id,status="posted",duplicate=!created});
});
app.MapPost("/api/v1/journals/{id}/reverse",async(HttpContext ctx,string id,Reason request,Repository repo)=>{
 if(request.Value.Length<5||request.Value.Length>500)throw new ArgumentException("Alasan koreksi harus 5–500 karakter.");
 await repo.Commit(User(ctx),"reverse-"+id,Hash(id+request.Value),existing=>{
  var original=existing.FirstOrDefault(j=>j.Id==id)??throw new ArgumentException("Jurnal tidak ditemukan.");
  if(original.Reverses!=""||existing.Any(j=>j.Reverses==id)||existing.Any(j=>j.SourceId==id))throw new ArgumentException("Jurnal sudah dibalik atau memiliki pelunasan; review diperlukan.");
  var sources=original.PairId==""?[original]:existing.Where(j=>j.PairId==original.PairId&&j.Reverses=="").ToList();var pair=sources.Count>1?Guid.NewGuid().ToString():"";
  return sources.Select(j=>new Journal(Guid.NewGuid().ToString(),j.EntityId,DateTime.UtcNow.AddHours(7).ToString("yyyy-MM-dd"),"Pembalikan: "+j.Description+" — "+request.Value,"reversal",j.Lines.Select(l=>new Line(l.Account,l.Credit,l.Debit)).ToList(),j.Category,pair,j.Id,j.SourceId,DateTime.UtcNow.ToString("O"))).ToList();
 },"REVERSE_JOURNAL",request.Value);return Results.Ok(new{status="reversed"});
});
app.MapGet("/api/v1/reports/{entityId}",async(HttpContext ctx,string entityId,string month,Repository repo)=>{
 if(!FinancialEngine.Entities.Contains(entityId)||!DateOnly.TryParseExact(month+"-01","yyyy-MM-dd",out var start))throw new ArgumentException("Entitas/periode tidak valid.");
 var journals=await repo.Journals(User(ctx));var end=start.AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
 var balances=FinancialEngine.Accounts.ToDictionary(a=>a,a=>FinancialEngine.Balance(journals.Where(j=>string.CompareOrdinal(j.Date,end)<=0),entityId,a));
 var scoped=journals.Where(j=>j.EntityId==entityId&&j.Date.StartsWith(month)).ToList();
 return Results.Ok(new{entityId,period=month,asOf=DateTime.UtcNow,formulaVersion="ledger-v1",currency="IDR",balances,debit=scoped.SelectMany(j=>j.Lines).Sum(l=>l.Debit),credit=scoped.SelectMany(j=>j.Lines).Sum(l=>l.Credit),profit= -FinancialEngine.Income.Concat(FinancialEngine.Expenses).Sum(a=>FinancialEngine.Balance(scoped,entityId,a))});
});
app.MapGet("/api/v1/audit",async(HttpContext ctx,NpgsqlDataSource source)=>{await using var c=await source.OpenConnectionAsync();await using var cmd=new NpgsqlCommand("SELECT action,reason,source_ids::text,created_at FROM audit_events WHERE user_id=@u ORDER BY created_at DESC LIMIT 500",c);cmd.Parameters.AddWithValue("u",User(ctx));await using var reader=await cmd.ExecuteReaderAsync();var events=new List<object>();while(await reader.ReadAsync())events.Add(new{action=reader.GetString(0),reason=reader.GetString(1),sourceIds=JsonSerializer.Deserialize<string[]>(reader.GetString(2)),at=reader.GetDateTime(3)});return Results.Ok(events);});
app.Run();
static Guid User(HttpContext ctx)=>(Guid)ctx.Items["user"]!;
static string Hash(string s)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(s)));
static string PasswordHash(string password){var salt=RandomNumberGenerator.GetBytes(16);var hash=Rfc2898DeriveBytes.Pbkdf2(password,salt,210000,HashAlgorithmName.SHA512,32);return Convert.ToBase64String(salt)+":"+Convert.ToBase64String(hash);}
static bool PasswordVerify(string password,string saved){var parts=saved.Split(':');var hash=Rfc2898DeriveBytes.Pbkdf2(password,Convert.FromBase64String(parts[0]),210000,HashAlgorithmName.SHA512,32);return CryptographicOperations.FixedTimeEquals(hash,Convert.FromBase64String(parts[1]));}
record Credentials(string Email,string Password);
record Reason([property:System.Text.Json.Serialization.JsonPropertyName("reason")] string Value);
