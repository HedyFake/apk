# BFI — Android preview 0.1.0

Aplikasi Flutter untuk mencoba pembukuan personal, household, dan bisnis yang terpisah. **Ini preview MVP, bukan seluruh produk pada brief dan belum siap operasional produksi.** APK debug membuka mode DEMO. Data contoh sintetis tidak diambil dari angka screenshot Stitch. Logo berasal dari gambar yang disediakan pemilik proyek; aset lokal dan ikon Android sudah disertakan.

## Yang dapat dicoba

- Ringkasan, Personal, Bisnis, Insight, Smart Pricing, Laporan, Jurnal, simulasi penyusutan, pengaturan koneksi, dan input transaksi.
- Transaksi DEMO disimpan di SQLite/Drift secara atomik, mengubah ledger dan laporan, serta mencatat audit trail. Keluar lalu membuka aplikasi tetap mempertahankan ledger DEMO.
- Pendapatan aktif/pasif, pengeluaran, pemindahan dana darurat, kartu kredit, pinjaman pokok/bunga, pembelian persediaan, penjualan dengan HPP manual, invoice/pelunasan, utang supplier/pembayaran, dan pinjaman pemilik dengan dua jurnal tertaut.
- Validasi debit = kredit, batas nilai IDR integer, saldo kas/persediaan, pembayaran berlebih, dan koreksi melalui jurnal pembalikan. Tidak ada penghapusan jurnal melalui UI/API.
- Pricing interaktif: diskon sekali, biaya rupiah, fee terhadap penjualan bersih, iklan, subsidi ongkir, target laba, dan skenario tersimpan lokal.
- Laporan P&L, neraca, trial balance, arus kas sederhana; ekspor CSV melalui pemilih berkas Android. Angka dashboard dihitung dari jurnal.
- Backend ASP.NET Core + PostgreSQL, autentikasi token opaque berumur 30 menit, PBKDF2 password, idempotency, transaksi database, audit, dan isolasi pengguna. Server harus di-host dan disambungkan secara terpisah.
- Akun server menggunakan namespace cache berbeda dari DEMO. Draft offline tidak memengaruhi saldo; pengiriman memerlukan konfirmasi. Konflik ditahan di antrean, bukan ditimpa diam-diam.

## Mulai

1. Pasang APK debug dari folder rilis pada ponsel uji. Buka **BFI**.
2. Label **DEMO • DATA CONTOH** selalu membedakan sandbox contoh. Jangan masukkan data nyata ke DEMO.
3. Tap **Input**, pilih entitas dan jenis, isi nominal rupiah penuh serta uraian. Tinjau pasangan debit/kredit sebelum konfirmasi.
4. Lihat perubahan saldo, menu **Laporan**, dan **Jurnal & audit trail**. Tap jurnal untuk melihat detail atau membuat pembalikan beralasan.
5. Untuk menguji server, ikuti [SETUP.md](docs/SETUP.md). Pengaturan → URL HTTPS → daftar/masuk. Tidak ada server publik, kredensial default, bank connection, atau pembayaran otomatis.

## Struktur dan tanggung jawab

| Lokasi | Tanggung jawab |
|---|---|
| `bfi_mobile/lib/main.dart` | Bootstrap database/controller dan kegagalan startup |
| `lib/app/app.dart` | Tema, shell, navigasi, periode, badge mode |
| `lib/core/domain/ledger.dart` | DTO mobile, akun, pemetaan double-entry, saldo, validasi, pricing integer |
| `lib/core/data/store.dart` | Skema/migrasi SQLite v1, transaksi atomik, seed DEMO, antrean/cache/audit |
| `lib/core/data/controller.dart` | State, service API, isolasi mode, sinkronisasi, reversal |
| `lib/core/widgets/visuals.dart` | Komponen, rupiah, ring/donut/trend/waterfall dan alternatif teks |
| `lib/features/dashboard/screens.dart` | Overview, Personal, Business, Intelligence |
| `lib/features/transactions/input.dart` | Form dan preview transaksi |
| `lib/features/pricing/pricing.dart` | Unit economics dan penyimpanan skenario |
| `lib/features/reports/reports.dart` | Laporan, CSV, jurnal/audit, simulasi aset |
| `lib/features/settings/settings.dart` | Koneksi HTTPS, login/daftar, antrean |
| `assets/branding` | Logo asli pengguna dan ikon persegi lokal |
| `android/app/src/main` | Manifest, launcher icons, Kotlin penyimpanan CSV |
| `bfi_mobile/test` | Pengujian ledger/SQLite serta rendering layar |
| `bfi_backend/Program.cs` | REST v1, autentikasi, validation/error middleware, DI, rate limit |
| `bfi_backend/Domain/Ledger.cs` | Aturan finansial server (otoritatif) |
| `bfi_backend/Infrastructure/Repository.cs` | Boundary PostgreSQL, lock, idempotency, audit atomik |
| `bfi_backend/migrations` | Skema dan constraint akuntansi PostgreSQL |
| `bfi_backend/tests` | Pengujian domain .NET yang dapat dijalankan tanpa framework tambahan |
| `docs` | Setup, API, release, test report, keterbatasan |

## Verifikasi

```text
cd bfi_mobile
flutter pub get
flutter analyze
flutter test test/financial_test.dart
flutter test test/screens_test.dart --update-goldens
flutter build apk --debug

cd ../bfi_backend
dotnet build
dotnet run --project tests/Bfi.FinancialTests.csproj
```

Screenshot berasal dari rendering widget Flutter pada viewport ponsel, bukan foto perangkat fisik. Golden menggunakan Arial sistem Windows jika tersedia; hasil piksel lintas OS dapat berbeda. Lihat [TEST_REPORT.md](docs/TEST_REPORT.md) untuk hasil yang benar-benar dijalankan dan [LIMITATIONS.md](docs/LIMITATIONS.md) untuk cakupan yang belum selesai.
