# Batas versi 0.1.0

Status: preview MVP. Tidak memenuhi seluruh Definition of Done pada brief produksi. Implementasi referensi HTML tidak diperlakukan sebagai fitur backend yang sudah tersedia.

| Area | Yang belum selesai / batas nyata |
|---|---|
| Entitas | Tiga entitas tetap per akun: personal, household, satu bisnis. Belum CRUD multi-bisnis, badan hukum, anggota keluarga, RBAC reviewer/approver. |
| Hubungan pemilik | Pinjaman pribadi → bisnis tertaut. Belum gaji, dividen/prive, setoran modal dua sisi, reimbursement, pelunasan pinjaman pemilik. |
| Akun & budgets | Satu akun kas per entitas; belum multi-bank/e-wallet, limit kartu, due dates, budget, recurring bills, label perilaku dan target pengguna. |
| Portfolio | Belum valuasi, transaksi investasi, realized/unrealized gain. Tampilan menyebut unavailable; tidak dianggap passive cash income. |
| Skor | Health score sengaja N/A. Belum model berbobot tervalidasi, completion status dan review rekonsiliasi. |
| Rasio | Essential spending memakai proxy Direct + Rutin periode terpilih, target dana darurat ilustratif 6 bulan; belum terverifikasi pengguna. Passive income dimasukkan manual sebagai bersih. |
| Kas vs accrual | KPI pendapatan/pengeluaran memakai akun pendapatan/beban, termasuk belanja kredit. Bukan klaim seluruhnya cash flow; kas tersedia ditampilkan terpisah. |
| Persediaan | Pembelian/penjualan dan HPP manual ke ledger. Belum SKU, kuantitas, FIFO/weighted average, produksi, gudang, retur, rusak, inventory aging/ABC. |
| Channel/ads | Pricing simulasi fee gabungan terhadap net sales; belum integrasi marketplace, SKU katalog, COD, payout matching, campaign attribution, ROAS/CAC/CPC/CTR/CVR. |
| AR/AP | Sisa dokumen dan pelunasan ditautkan. Belum due dates, aging buckets, reminder, bank reconciliation. |
| Laporan | Neraca saldo debit/kredit bertanda, P&L pra-pajak, direct cash flow sederhana. CFO/CFI/CFF pembalikan belum diklasifikasikan otomatis. Belum standar laporan final, PDF/XLSX, adjustment UI, closing workflow. Database sudah menolak periode yang ditandai closed oleh administrator. |
| Aset/pajak | Simulasi penyusutan garis lurus tidak diposting. Belum register per aset, aturan fiskal efektif, approval dan tax estimate. Tidak ada tarif pajak hardcode. |
| Offline | SQLite cache dan antrean persisten. Konflik server terlihat sebagai error untuk review/retry; belum merge editor, background sync, refresh token, multi-device conflict-resolution UI. |
| Keamanan | Token tersimpan secure storage, API wajib HTTPS di luar development. Database cache perangkat belum dienkripsi terpisah; belum PIN/biometrik, reset password, session revoke UI, MFA, pentest, audit tamper-evidence. |
| Operasi | Tidak ada backend publik yang dideploy. Belum backup/restore teruji, monitoring produksi, load test, migrasi upgrade v2. |
| Android | Debug APK untuk evaluasi; bukan release Play Store. Uji perangkat fisik, ekspor lewat document picker, TalkBack, OEM, performa dan signing produksi perlu QA perangkat. |
| UX | Light mode; belum dark mode, persistent filter antar-start, semua chart lanjutan, scope tabs, skeleton kompleks, dan form konfigurasi completeness. |

Jangan memakai skor, simulasi harga atau penyusutan sebagai rekomendasi investasi/pajak. Tindakan keuangan eksternal tidak dijalankan oleh aplikasi. Ledger DEMO dan namespace akun server tidak pernah digabung.
