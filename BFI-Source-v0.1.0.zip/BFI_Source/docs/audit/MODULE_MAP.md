# BFI — Peta Modul dan Rencana Tahap

Status: rancangan Tahap 1, 4 November 2026. Semua komponen berikut adalah **target implementasi**, bukan fitur tersedia. Bukti referensi dan temuan berada di `AUDIT_REPORT.md`; acceptance per gap di `DESIGN_GAP_LIST.md`.

## 1. Struktur produk dan navigasi

Bottom bar: Overview, Pribadi, Input (action sheet), Bisnis, Pak Tung. Laporan, Stok, Iklan, Pajak dan Pengaturan berada di konteks/submenu. Input mempertahankan entitas aktif tetapi menampilkannya secara jelas sebelum simpan; tidak menebak pemilik akun dari halaman terakhir.

| Modul / feature Flutter | Route konseptual | Tanggung jawab | Data dan sumber laporan | Tahap utama |
|---|---|---|---|---|
| Identity & Governance / `core/auth`, `settings` | `/sign-in`, `/entities`, `/settings` | Login, memberships, roles, sesi, konfigurasi | User, tenant, entity, membership, permission, audit | 3, hardening 6 |
| Overview / `overview`, `financial_health` | `/overview`, `/health/:entityId` | Dua health gauges, liquidity terpisah, obligations, relasi | KPI snapshot versioned, saldo ledger, bills, pasangan transaksi | UI 2; data 4; scoring 5 |
| Personal / `personal_finance` | `/personal/:entityId` | Income/spending, net worth, budget, bills, dana darurat | Accounts, transaction/journal, valuations, liabilities, budget | 4 |
| Household / `household` | `/households/:entityId` | Anggota, shared budgets, alokasi kontribusi | Ledger household sendiri; akses anggota terpisah | 3–4; alokasi lanjutan 5 |
| Quick Input / `transactions` | `/transactions/new`, `/transactions/:id` | Income/expense/transfer/debt/card, receipt, preview | Transaction source → balanced journal → ledger | 3–4 |
| Owner–Company / `transactions` + `overview` | `/relationships`, `/relationships/:pairId` | Salary, capital, distribution, loan, reimbursement | Dua journal tiap entitas, correlation/pair ID, approval | 3 foundation; 4 workflow |
| Intelligence / `pak_tung_intelligence` | `/intelligence`, `/recommendations/:id` | Education, recurring coverage, leakage, explainable actions | KPI definitions, source ranges, verification, goals | 5; komposisi dasar 4 |
| Business / `business_workspace` | `/business/:entityId` | Ringkasan laba dan operasi tiap badan usaha | Ledger + sales + costing + AR/AP | 4 |
| Pricing / `smart_pricing` | `/business/:entityId/pricing/:skuId` | Input biaya, A/B/C, buffer, price draft | Cost version, fee rules, pricing scenario snapshot | 4 |
| Sales / `sales_orders` | `/business/:entityId/orders`, `/invoices/:id` | Order, invoice, diskon, retur/refund, settlement | Sales lines, AR, COGS movement, payment allocation | 4 basic; 5 channel lanjutan |
| Inventory / `products_inventory` | `/business/:entityId/inventory` | Produk, supplier, purchase, stock dan cost layers | Inventory movement, costing policy, purchase/AP | 4 basic; 5 multiwarehouse/production/ABC |
| Ads / `advertising_analytics` | `/business/:entityId/campaigns` | Spend, attributed sales, ROAS/BEP, funnel | Campaign metrics, attribution windows, ads expense link | 4 input dasar; 5 analytics |
| Credit/Cash / `receivables_payables` | `/business/:entityId/ar-ap`, `/cash` | Aging, partial payment, due dates, cards/loans, liquidity | Open invoices/bills, allocations, account restrictions | 4; 5 CCC/forecast |
| Accounting / `reports` | `/entities/:entityId/reports/:type`, `/journals/:id` | COA, journals, TB/GL/P&L/BS/CF, close, audit/export | Posted journal sebagai sumber; draft/simulation terpisah | 3 foundation; 4 laporan; 5 close lanjutan |
| Fixed Assets & Tax / `fixed_assets_tax` | `/business/:entityId/assets-tax` | Register, schedule, rule version, preview/review/approve/post | Asset books, approved config, adjustment batch | 5 |
| Forecast / domain fitur terkait | `/business/:entityId/forecast` | Weekly/13-week cash scenarios, runway, assumptions | Opening available cash, obligations, collection estimates | 5; runway dasar 4 |
| Notifications / `notifications` | `/inbox`, `/reconciliation` | Due/overdue, mismatch, receipt pending, sync conflict | Events + reconciliation sessions; tidak auto-pay | 4–5 |

Route di atas adalah rancangan dan dapat disesuaikan saat desain router. Context membawa `tenantId`, `entityId`, `period`, `scope`, `asOf`; validasi server tetap wajib. Kembali dari detail mengembalikan filter dan posisi daftar. Ganti entitas harus mengosongkan data lama sebelum hasil entitas baru tampil. Cache dan pending draft di-key per user/tenant/entity, bukan global.

## 2. Model pemisahan dan aliran transaksi

```mermaid
flowchart TD
    U[Input atau import] --> V[Validasi entitas, izin, periode, idempotency]
    V --> D[Draft dengan source dan preview]
    D --> C[Konfirmasi dan approval sesuai kebijakan]
    C --> P[Posting server atomik]
    P --> J[Jurnal immutable dan audit event]
    J --> L[Ledger per entitas]
    L --> R[Trial balance dan laporan]
    L --> K[KPI dengan formula dan sumber]
    K --> O[Dashboard dan rekomendasi review]
    J --> X[Reversal atau adjustment dengan alasan]
    X --> L
```

Jurnal personal, household dan setiap bisnis berdiri sendiri. Dashboard Semua Ranah menyusun ringkasan berdampingan; bukan ledger konsolidasi dan bukan total kas bebas. Shared household view tidak menjumlah aset yang sama dua kali. Kepemilikan perusahaan pada aset personal perlu policy valuasi dan tidak mengubah kas perusahaan menjadi kas personal.

| Peristiwa | Sisi sumber | Sisi tujuan / efek | Invariant |
|---|---|---|---|
| Transfer satu entitas | Cr rekening sumber | Dr rekening tujuan | Bukan income/expense; biaya transfer terpisah |
| Owner loan ke bisnis | Personal Dr piutang owner loan / Cr cash | Bisnis Dr cash / Cr owner payable | Pair ID dan nominal/currency cocok; bukan pendapatan |
| Setoran modal | Personal Dr investasi / Cr cash | Bisnis Dr cash / Cr equity | Bentuk legal/account policy eksplisit |
| Gaji pemilik | Bisnis Dr payroll expense / Cr cash bila belum accrued | Personal Dr cash / Cr salary income | Bila sudah accrued: bisnis Dr payroll payable, tidak expense ulang |
| Distribusi | Bisnis mengurangi akun distribusi/payable sesuai policy | Personal penerimaan sesuai jenis | Dividen/prive bukan satu perlakuan universal; izin dan dokumen sesuai bentuk entitas |
| Reimbursement | Pengakuan biaya/aset pihak yang menanggung dengan due-to/due-from | Pelunasan menghapus payable/receivable dan menggerakkan cash | Tidak mengakui expense/income baru saat settle; receipt dan alasan |
| Belanja kartu kredit | Dr expense/asset/inventory | Cr card payable | Bayar tagihan Dr card payable / Cr cash |
| Pelunasan invoice | Dr cash | Cr AR | Tidak mengakui revenue yang sama lagi |
| Payout marketplace | Dr bank, fee sesuai reconciliation | Cr settlement receivable | Payout belum cair bukan available cash; fee tidak dua kali |

Inter-entity pair: satu workflow koordinasi, dua jurnal balance di entitas masing-masing. Bila pengguna hanya berizin satu sisi, catat pending counterpart dan minta review pihak berwenang; jangan membuat catatan entitas lain secara diam-diam. Dalam database pusat yang sama, pasangan final harus atomik saat seluruh approval tersedia. Draft offline tidak boleh dianggap kedua sisi posted. Pair unmatched tidak dieliminasi otomatis dalam analytics.

Status dibedakan pada dimensi masing-masing: lifecycle DRAFT/VALIDATED/PENDING_APPROVAL/POSTED/REVERSED; reconciliation unmatched/partial/matched; review pending/reviewed; sync local/pending/synced/conflict/rejected. `Balanced` adalah hasil pemeriksaan, bukan bukti audited. Posted journal tidak diedit; reversal mempertahankan source, actor, reason, original ID dan periode yang diizinkan.

## 3. Kontrak KPI dan chart

Setiap KPI membawa numerator/denominator (atau komponen indeks), nominal, unit, currency, entity, period start/end, as-of/timezone, formula version, source range/IDs, completeness dan calculation status. Nol valid, data kosong, tidak berlaku dan denominator invalid harus berbeda. Indeks belum lengkap tidak boleh menjadi skor sehat default.

| Layar | Visual target | Basis dan interaksi |
|---|---|---|
| Overview | Dua radial 0–100; composition liquidity bar; dua trend series berlabel terpisah | Score drill-down bobot/faktor; available/reserved/held mutually exclusive pada base yang sama; net worth personal dan business cash tidak dijumlahkan |
| Personal | Income/spending donut; emergency/passive rings; savings dan net-worth lines; budget stacked bar | Cash denominator default; tag tidak jadi segmen; raw target overflow tetap ditulis; budget actual/remaining dan overrun tidak disamarkan |
| Intelligence | Coverage radial; pillars/donut; dependence/fixed ratio bullet; Gajah/Kerbau bars; leakage bar | Recurring active/(active+passive); passive net/essential; cash leakage dan non-cash dipisah; rekomendasi dapat dibuka ke sumber |
| Business | Profit waterfall; margin gauges/bullets; ROAS vs BEP; cost stack/donut; AR/AP aging; inventory aging/ABC; runway dan cash trends | Net sales hingga finance/tax/net profit rekonsiliasi; ROAS multiple bukan persen; margin negative pakai signed bar; aging mengalokasi setiap outstanding sekali |
| Reports | Waterfall + P&L table; A vs L+E stack + BS; CFO/CFI/CFF signed bars; TB variance | Subtotal waterfall tidak dikurangi/dijumlah ulang; ending cash sama cash ledger; drill-down ke account/journal/source |
| Assets/Tax | Book-value line + schedule; tax summary; journal balance | Residual floor dan effective rules; estimasi bukan score; nominal debit/credit dan variance ditampilkan |

Prioritaskan 1–2 chart dominan dalam viewport pertama. Semua chart punya legend, nominal exact, periode, denominator, tooltip/detail dan alternatif tabel/semantic text. Data negatif atau total nol tidak dipaksa menjadi donut. Chart utama harus mempunyai empty/error/stale/offline states yang dapat dibedakan.

## 4. Struktur teknis yang direncanakan

```text
bfi_mobile/
  assets/{branding,icons,illustrations,fonts}/
  lib/
    app/{app.dart,router.dart,theme/,localization/}
    core/{api,auth,database,errors,formatting,permissions,sync,validation,widgets}/
    features/<nama_fitur>/{data,domain,presentation}/
    main.dart
  test/
  integration_test/
bfi_backend/
  src/{Bfi.Api,Bfi.Application,Bfi.Domain,Bfi.Infrastructure,Bfi.FinancialEngine,Bfi.Worker}/
  tests/{Bfi.UnitTests,Bfi.IntegrationTests,Bfi.FinancialRuleTests}/
  migrations/
  docs/
demo/                    # seed/fixture terisolasi, bukan data pengguna
docs/                    # setup, API, keputusan, QA, release
```

`app.dart` merakit dependency injection/theme; `router.dart` menjaga navigation/context. `data` memetakan DTO/API/Drift; `domain` menyimpan model/use-case; `presentation` UI/view model tanpa journal mapping. Shared widgets mencakup app bar, selector, MoneyAmount, KPI/status, chart wrappers, transaction tile dan state panels. Money menggunakan representasi decimal/fixed-point eksplisit, bukan SQLite REAL atau Dart double untuk pembukuan.

`Bfi.Api`: auth, endpoint `/api/v1`, DTO/Problem Details. `Application`: workflow/transaction boundary/permissions. `Domain`: entity, account, journal invariants. `FinancialEngine`: formula versioned deterministik. `Infrastructure`: EF Core/PostgreSQL NUMERIC, repository, storage privat. `Worker`: outbox, reminders dan recalculation idempotent. Database constraints harus mengikat account/journal/entity dan mencegah foreign resource lintas tenant; UI menyembunyikan menu bukan kontrol keamanan.

Offline menyimpan draft dan cache as-of; mutation memiliki UUID/device/idempotency key/server version. Posting, approval, transfer terkonfirmasi dan tax final memerlukan server online. Retry tidak double-post; konflik journal tidak memakai last-write-wins. Logout/account switch tidak mengekspos cache pengguna sebelumnya. Transaksi posted, audit event dan outbox harus konsisten dalam commit.

Demo terpisah lewat environment/database/tenant khusus dan label di UI/export. Seed bersumber transaksi sehingga laporan, KPI dan akun dapat direkonsiliasi. Production onboarding mulai kosong; tidak ada auto-seed screenshot. API tetap menghitung ulang total dan memverifikasi mode data. Admin web ditunda; pilih Blazor atau React/TypeScript hanya bila fase tersebut dikerjakan.

## 5. Tahapan dan gate hasil

| Tahap pengguna | Hasil | Gate menuju klaim berikutnya |
|---|---|---|
| 1 Audit & mapping | Dokumen audit, map, gap, traceability, evidence | 34/34 file diperiksa; 6/6 PNG dilihat; konflik terdaftar. Selesai pada keluaran ini. |
| 2 Design system & prototype | Local BFI logo, reusable components, routes, coherent DEMO, chart interactions dan states | Enam route pada 360×800, 390×844, 430×932, tablet; font scaling/back/filter; CTA demo jujur; screenshot tiap layar. Bukan klaim fitur produksi. |
| 3 Backend & foundation | Auth/entity/COA/period/journal/transactions/audit/migrations | Balanced dan imbalanced tests, tenant isolation, immutable/reversal, idempotency, locked period, paired posting; ledger dahulu. |
| 4 MVP end-to-end | Input personal/business, cash/cards/loans/budget, pricing, AR/AP, basic stock/sales/HPP, laporan | Input → API → database → journal → reports/KPI → audit; restore/reload membuktikan persist. Basic inventory prerequisite untuk mengklaim HPP aktual, bukan hanya estimasi manual. |
| 5 Advanced | Explainable score/intelligence, production/multiwarehouse, ads/ABC, depreciation/rule config, forecast | Rumus terversi; attribution/policy/source; preview approval; model forecast menunjukkan asumsi. |
| 6 QA/release | Security/offline/recovery/performance, APK debug, signing guide, AAB sesuai target | Pass/fail dengan evidence, install smoke test, backup restore, report export; secret/keystore di luar repository. |

Definisi selesai per fitur: UI, input validation, persist/sync, server authorization/calculation, ledger entitas tepat, laporan berubah, audit log, tes lulus, dokumentasi. Tahap 2 bisa selesai sebagai **prototype**, tetapi tidak memenuhi definisi fitur produksi.

## 6. Keputusan konfigurasi yang masih terbuka

Tidak diperlukan jawaban untuk menyelesaikan audit. Sebelum produksi, putuskan dan version-kan: bentuk legal tiap entitas dan policy distribusi, fiscal/calendar periods, household asset ownership, basis cash savings (principal/tax/investment transfers), essential-spend averaging window, asset valuation, score thresholds/confidence, fee base/caps/tiers/discount funding, attribution window, costing policy dan perubahan periodenya, rounding/currency precision, closing/reopen permissions, maker-checker thresholds, depreciation books/proration/residual, tax rule source/effective/eligibility, privacy retention, RPO/RTO dan deployment target.

ASSUMPTION untuk prototype: bahasa Indonesia, IDR, light default, synthetic DEMO environment, daftar primary spending lima kategori + Unclassified, tags dual-perception terpisah. Ini pilihan desain sementara; tidak menetapkan tarif pajak, skor kesehatan, atau kebijakan akuntansi nyata pengguna.
