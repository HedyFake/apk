# BFI — Laporan Pemeriksaan Tahap 1

Tanggal: 4 November 2026. Lingkup: paket referensi dan konsistensi contoh **DEMO**, bukan pengujian aplikasi BFI. Tidak ada source Flutter/.NET atau APK di paket yang dapat diuji sebagai produk.

## Hasil pemeriksaan otomatis audit

Script pemeriksaan internal `work/verify_audit.ps1` dieksekusi dengan PowerShell, exit code **0**. Hasil: **26 PASS, 0 FAIL** terhadap expectation inventaris, pola statis dan aritmetika audit. Bukti setiap expected/actual ada di `AUDIT_CHECK_RESULTS.json`. PASS ini berarti pemeriksaan audit cocok, **bukan referensi sudah memenuhi acceptance produk**.

| ID | Pemeriksaan | Hasil |
|---|---|---|
| A01–A05 | 34 file, 22 Markdown, 6 HTML, 6 PNG; seluruh path inventory ada | PASS |
| A06 | 30 `href="#"` pada enam HTML | PASS sebagai konfirmasi temuan navigasi placeholder |
| A07 | Pola `fetch`, XHR, localStorage, IndexedDB, object URL dan atribut download yang dicari: 0 | PASS sebagai bukti statis terbatas; bukan audit seluruh kemungkinan I/O dependensi pihak ketiga |
| A08–A13 | Biaya/laba/buffer A/B; maksimum subsidi Rp39.000 pada asumsi nominal referensi | PASS |
| A14–A15 | Dana darurat 91,7%; cash savings 36,9% pada rounding satu desimal | PASS untuk expected hasil hitung, berbeda dengan literal HTML |
| A16–A17 | Spending Rp14,2 juta; cash leakage tersisa Rp322.500 setelah non-cash dikeluarkan | PASS aritmetika, tidak memvalidasi recurring/eligibility |
| A18–A21 | P&L EBT Rp24,8 juta; assets Rp148,5 juta; A−L−E=0; closing cash Rp22,5 juta | PASS aritmetika fixture, tidak membuktikan sumber ledger |
| A22–A24 | Depresiasi Rp1.562.500; gabungan adjustment Rp2.275.000; EAT Rp22.525.000 | PASS aritmetika ilustrasi; validitas pajak/perlakuan akuntansi nyata tidak diuji |
| A25 | Regression expected: gross 100k − discount 10k − COGS 60k = 30k | PASS expected kalkulasi, bukan test financial engine yang sudah diimplementasi |
| A26 | Hash source tidak berubah sejak manifest | PASS |

## Inspeksi manual dan acceptance referensi

Penilaian berikut berdasarkan pembacaan kode dan screenshot. Tidak dilakukan browser click-test. “FAIL” berarti referensi belum memenuhi kebutuhan target, bukan test runtime yang dijalankan.

| ID | Expected | Actual / bukti | Status |
|---|---|---|---|
| M01 | Semua dokumen dibaca | 22/22 teks penuh; register AUDIT_REPORT bagian 3 | PASS — cakupan audit |
| M02 | Semua HTML dibaca | 6/6 hingga script/nav penutup; bagian terpotong output S5 dibaca ulang | PASS — cakupan audit |
| M03 | Semua screenshot dilihat sendiri | S1 305×1600; S2 318×1600; S3 292×1600; S4 415×1600; S5 210×1600; S6 160×1600; catatan per layar di audit | PASS — cakupan audit |
| M04 | Navigasi antar halaman nyata | 30 href=#; active header Overview di halaman lain | FAIL — G15 |
| M05 | Save mencatat transaksi dan sync | S2:413–421 hanya toast/timeout | FAIL — G01,G06 |
| M06 | Scope mengubah data | S1:339–351 hanya class tab | FAIL — G15 |
| M07 | Pricing dihitung dari input lengkap | S4:260–307 fixed strings A/B, no editable cost inputs | FAIL — G13 |
| M08 | Ekspor menghasilkan dokumen | S5:496–505 dan S6:612–621 hanya label/timer | FAIL — G06 |
| M09 | Posting adjustment permissioned dan persisted | S6:550 hanya HTML/class replacement | FAIL — G07,G11 |
| M10 | Semua tabs mapping konsisten | S6 tab adj tidak tercantum dalam arrays/section map | FAIL — G21 |
| M11 | Pelunasan AR tidak revenue ulang | S5/S6 Cr Revenue pada contoh pelunasan invoice existing | FAIL — G05; bersyarat invoice telah diakui |
| M12 | Cash savings tidak memasukkan depresiasi | S3 Rp9,6 juta/tahun memasukkan non-cash Rp477.500/bulan | FAIL — G08 |
| M13 | Mandatory charts dan metadata lengkap | Hanya dua SVG health rings S1 dan sejumlah progress/comparison bars; chart target lain belum ada | FAIL — G14,G18 |
| M14 | Logo lokal dan ukuran teks sesuai target | Remote logo broken pada 6 PNG; font config 11px dan gauge 10px | FAIL — G16,G17 |
| M15 | Tidak ada klaim sukses/ready/audited tanpa proses | Klaim statis S1/S2/S3/S5/S6 | FAIL — G06,G20 |
| M16 | Selisih adjustment dapat dijelaskan | Rp1.562.500 + Rp712.500 = Rp2.275.000 | PASS aritmetika; label dan integration tetap G22 OPEN |

## Belum diuji / belum tersedia

Flutter build, Android install, route runtime, backend integration, schema migration, journal engine, role/tenant enforcement, auth/token, encrypted storage, sync conflict, backup restore, actual exports, performance, automated UI, font scaling, screen reader, measured contrast, release signing dan APK/AAB: **NOT RUN — implementasi belum ada dalam paket**.

Angka di screenshot adalah fixture ilustrasi dan tidak boleh dipromosikan menjadi test oracle yang dianggap benar seluruhnya. Sebelum implementasi, pertahankan expected yang direkonsiliasi dan tambahkan test untuk diskon sekali, credit utilization total limit, DSR parentheses, loan/card principal, zero/negative denominator, refunds, rounding, duplicate posting, reversed periods dan paired transactions. Rencana lengkap gate berada di MODULE_MAP dan gap register.
