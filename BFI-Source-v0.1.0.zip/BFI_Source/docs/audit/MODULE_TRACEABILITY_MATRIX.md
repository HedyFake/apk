# BFI — Matriks Keterlacakan

Semua requirement di bawah masih **belum terimplementasi end-to-end**. “Referensi” berarti markup/screenshot atau kebutuhan dokumen, bukan bukti kemampuan produksi. Nomor fitur merujuk `docs/06_FEATURE_CATALOG.md`.

| Cakupan requirement | Fitur katalog | Referensi | Modul target / dependensi | Gap terkait | Acceptance utama |
|---|---|---|---|---|---|
| Profil, net worth, accounts, cards, debt | 1–8 | S2; docs/02,07,08 | Identity, Personal, Household, Accounting | G01–03,G12,G26 | Owner ledger benar; aset-liabilitas terlacak; card/loan tak menggandakan beban |
| Income, spending, budgets, bills, fund, savings | 9–16 | S2; docs/05,07 | Transactions → Ledger → Personal | G04,G09,G14,G19 | Save/reload/ledger/report; kategori saling eksklusif; transfer excluded sesuai policy |
| DSR, assets, portfolio, goals, household allocation, leakage | 17–22 | S2–S3; docs/02,07 | Personal/Household, Intelligence | G03,G08,G14,G26 | Cash/non-cash/ownership jelas; denominator/window dan target |
| Import dan receipt | 23–24 | S1 receipt CTA; docs/06,10 | Transactions, Reconciliation, private storage | G02,G06,G29 | Preview mapping/dedupe, attachment authorized, reviewed OCR bila tersedia |
| Income pillars dan spending taxonomy | 25–37 | S2–S3; docs/02,05 | Intelligence + Personal classification | G08,G19,G26 | Main category sekali; tags tidak dijumlah; total cash terpisah unrealized |
| Coverage, lifestyle, explainable recommendations | 38–41 | S3; docs/05,07 | KPI engine, Goals, Recommendations | G14,G27 | Formula/data/as-of/completeness; review-only actions, no automatic financial mutation |
| Multi-entity, SKU, supplier/customer, purchasing/production | 42–48 | S4 sebagian; docs/06,08 | Business, Inventory, Sales, AR/AP | G01–03,G25 | Dokumen source → stock/AP → journal; produksi materials/labor/overhead tertelusur |
| HPP, costing, stock, warehouse/count/reorder/aging | 49–55 | S4 angka FIFO; docs/06–08 | Inventory → FinancialEngine → Ledger | G25,G31 | Layers dan movement reconcile; policy tetap; damaged/return tidak double COGS |
| Sales, discount, refund, fees, shipping, COD/settlement | 56–64 | S4–S5 sebagian; docs/06–08 | Sales, Pricing, Reconciliation, AR/AP | G04–05,G24–25 | Gross-to-net/fees/held payout benar; partial/refund/duplicate teruji |
| Pricing, shipping scenario, contribution, profitability | 65–68 | S4 | Pricing, Inventory, Fees, Ads | G13,G23 | Editable scenario recomputed server, incomplete/negative/threshold/fee-base tests |
| Ads, ROAS/BEP, CAC/funnel, budget control | 69–74 | S4 angka dan S5 diagnostic | Ads, FinancialEngine, Expenses | G14,G23,G31 | Attribution window/source; BEP berdasarkan pre-ad contribution, spend sekali |
| Aging, credit, cash/card, loan, forecast/runway/CCC | 75–83 | S1,S4; docs/05–08 | AR/AP, Accounts, Forecast | G12,G14,G24,G31 | Due buckets dan payment allocations; burn<=0 state; CCC denominators valid |
| Bank dan marketplace reconciliation | 84–85 | S1 CTA; docs/06,08 | Reconciliation, Cash, Settlements | G06,G10,G24 | Match/partial/unmatched/ignored beralasan; saldo belum cair bukan available cash |
| COA, journals, GL/TB/P&L/BS/CF, close, audit | 86–94 | S5–S6 | Accounting, Reporting, Approval | G01,G05,G11,G20,G22 | D=K, A=L+E, opening+change=closing; immutable/reversal; source trace |
| Assets/depreciation/tax, financial score | 95–98 | S1 gauges, S6 | Fixed Assets/Tax, Health Engine | G07,G14,G21–22 | Versioned approved assumptions; no auto-post; score insufficient-data state |
| Roles, backup/export/restore | 99–100 | Docs/10; S5–S6 export dummy | Governance, Infrastructure, Reporting | G02,G06,G29–30 | Denied entity access; file nyata; encrypted backup restore verified |
| Design/accessibility/navigation/Android delivery | Lintas 1–100; tambahan user | Semua layar; docs/04,05,09,11,13 | Flutter app/core, QA/release | G15–18,G28,G30,G32 | Enam routes, state matrix, 360–430 dp/tablet/font scale; debug APK install; tests with evidence |

Seluruh ID katalog 1–100 tercakup tanpa menyatakan semua memiliki layar referensi. Fitur seperti produksi, multi-gudang, import, restore dan tax profile sebagian besar hanya didokumentasikan. Keenam screenshot tidak cukup menjadi spesifikasi lengkap form/detail/workflow; layar turunan harus dirancang pada tahap berikutnya.

Rujukan permintaan user A–F: A → Overview/Relationships; B → Personal/Household; C → Intelligence; D → Business/Pricing/Inventory/Ads/ARAP; E → Accounting/AssetsTax; F → kontrak chart lintas modul dalam MODULE_MAP. Keluaran source, migration, env, API docs, APK dan screenshot aplikasi merupakan gate tahap implementasi/release, bukan hasil audit saat ini.
