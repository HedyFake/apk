# BFI — Gap Register

4 November 2026. Status semua gap: **OPEN**, kecuali koreksi dokumentasi audit yang dinyatakan terselesaikan. P0 = menghambat klaim fitur finansial benar/aman; P1 = wajib untuk cakupan produk/UX; P2 = polish/operasi lanjutan. Prioritas gap ini berbeda dari nomor prioritas katalog fitur. S1–S6 mengacu `AUDIT_REPORT.md`.

| ID | Prioritas | Gap dan bukti | Tindakan / kriteria penerimaan | Tahap & penanggung jawab peran |
|---|---|---|---|---|
| G01 | P0 | Tidak ada ledger, API, database, migrations, auth di paket | Implementasikan fondasi; transaksi reload tetap ada, D=K, journal immutable, laporan sourced dari ledger | 3; Backend + Financial + QA |
| G02 | P0 | Tenant/entity isolation baru spesifikasi | Membership setiap endpoint/resource/attachment/export; cross-tenant/account ID ditolak dan tidak bocor lewat cache | 3/6; Backend + QA |
| G03 | P0 | Inter-entity hanya teks relasi S1 | Dua jurnal terpisah linked, izin tiap sisi, atomic final posting; unmatched terlihat; loan bukan income; retry tidak duplikat | 3–4; Financial + Backend |
| G04 | P0 | Double seller discount docs/07:79; proceeds ambigu :99 | Normalisasi F01 audit; contoh gross 100k, diskon 10k, COGS 60k → contribution 30k sebelum biaya lain, bukan 20k | 3; Financial + QA |
| G05 | P0 | Pelunasan invoice Cr Revenue S5:424–432, S6:426–434 | Untuk invoice existing: Dr Cash/Cr AR; pendapatan tetap dan AR turun; source trace lengkap | 3–4; Financial + QA |
| G06 | P0 | Toast simpan/sync/post/export mengklaim operasi tidak terjadi | Prototype jelas berlabel DEMO/simulasi; produksi sukses hanya setelah commit/file nyata; failure/retry dapat dibuktikan | 2–4; Flutter + Backend |
| G07 | P0 | Tax/asset rules hardcoded, readiness claims S5/S6 | Effective rule/config + profile + source, preview/review/approve/post; tanpa config tampil belum tersedia; tidak auto-post atau auto-pay | 5; Financial + Backend + QA |
| G08 | P0 | Non-cash depreciation masuk savings S3:264,333 | Cash leakage terpisah; potential/actual terpisah, recurrence dan entity diverifikasi; tidak annualize one-off tanpa asumsi | 2/5; Financial + UX |
| G09 | P0 | Demo literal tanpa label global; angka antar layar tidak koheren | Seed isolated database/tenant, banner/export DEMO, zero demo pada produksi; satu transaksi mengubah seluruh read model terkait | 2–4; Backend + QA |
| G10 | P0 | Belum ada sync/conflict/idempotency | Offline hanya draft/cache; duplicate sync sekali posted; conflict review, stale/cache as-of; reject tidak dinyatakan synced | 3–4/6; Flutter + Backend |
| G11 | P0 | Close/reversal/audit hanya requirements | Posted tak bisa edit/delete; reversal linked beralasan; posting backdate closed ditolak; reopen permissioned; audit atomik | 3–5; Backend + QA |
| G12 | P0 | Kartu/pinjaman belum ledger-mapped | Card purchase membentuk payable, payment bukan expense ulang; loan receipt bukan income, principal terpisah bunga | 3–4; Financial + QA |
| G13 | P0 | Pricing strings A/B, missing fees, status AMAN | Engine decimal server + unit tests, fee bases/tier/cap, incomplete status; max subsidy 39k pada fixture nominal; case B below target bukan loss | 3–4; Financial + Backend |
| G14 | P0 | Score/rasio tanpa definisi, metadata atau completeness | Versioned factors/threshold/weights, numerator/denominator, period/as-of/source; missing data tidak skor sehat; DSR dan credit limit fix | 2–5; Financial + UX |
| G15 | P1 | Semua bottom href=#, header active salah | Real routes, Input sheet, contextual reports/tax/settings, filter persistence, back stack dan guarded entity switch | 2; Flutter + UX |
| G16 | P1 | Logo broken, network fonts/icons, invalid color token | Logo/font lokal/fallback, semantic tokens sesuai docs/04; offline shell tidak broken; tidak ada ligature text | 2; UX + Flutter |
| G17 | P1 | Label 10–11px, zoom off, truncation/overlap risk | Body ≥14sp, label ≥12sp, target sentuh memadai, semantic names, font scaling, contrast dan screen reader diuji; no monetary clipping | 2/6; UX + QA |
| G18 | P1 | Mayoritas mandatory chart belum ada | Seluruh chart di MODULE_MAP, interactive detail + accessible table; nominal/denominator/period, negative/zero/overflow states benar | 2/4–5; UX + Flutter |
| G19 | P1 | Emergency 91,6 vs 91,7; kategori “6” berisi 5 | Display rounding konsisten; 5 main categories + tags; sum 100% tanpa double count; cash/assets reserve direkonsiliasi | 2–4; Financial + Flutter |
| G20 | P1 | Audited/Validated/Tax Ready statis dan status bercampur | Balanced vs reconciled vs reviewed vs posted terpisah; audit formal tidak diklaim; lifecycle/sync/review dimodelkan terpisah | 2–5; Product + Backend |
| G21 | P1 | Tab adj tidak dihandler S6:578–595 | Route aset/pajak tersendiri atau tab mapping lengkap; active state benar; section tidak muncul di tab salah | 2; Flutter + QA |
| G22 | P1 | P&L tax impact dan EBT/EAT label ambigu | Bridge EBT sebelum adjustments → depreciation → EBT adjusted → tax → EAT; no duplicate depreciation; ledger/BS/equity ikut berubah | 4–5; Financial + Backend |
| G23 | P1 | Business contribution 38,2 vs report 42,4; ads 18,5 vs selling+ads 21,8 | Definisi scope/campaign/channel jelas; cost bridge ke ledger; no mixing gross margin vs pre-ad contribution untuk BEP | 4–5; Financial |
| G24 | P1 | AR/AP tanpa aging nyata/partial payment; payout held tak modeled | Bucket per due date/as-of, unpaid residual; allocation/refund/credit note; settlement receivable terpisah cash available | 4–5; Backend + Financial |
| G25 | P1 | Basic inventory/HPP belum ada, advanced scope luas | SKU movements/cost layers, returns/damage, policy FIFO/weighted average; COGS tidak mengandung biaya selling dua kali | 4 basic/5 advanced; Financial + Backend |
| G26 | P1 | Income-all memasukkan unrealized; attribution/valuation dates hilang | Cash default, unrealized non-cash, portfolio disposal proceeds/cost/gain dipisah, negative gain bukan donut; valuation metadata | 4–5; Financial |
| G27 | P1 | Recommendation thresholds/quotes/claims tanpa sumber | Explainability + date/data gaps, edukasi netral; review action saja; hapus atribusi verbatim tak terverifikasi dan auto financial execution | 2/5; Product + UX |
| G28 | P1 | Loading/empty/offline/error/pending/confirmation tidak lengkap | Reusable states dan matrix tiap route; retry/input validation; no success on failure; no stale real-time claim | 2–4; Flutter + QA |
| G29 | P1 | Security/storage/backup/export belum ada | Token rotation/secure storage/TLS, private receipt access, secret redaction, encrypted backup & restore test, permissions/logging export | 3/6; Backend + QA |
| G30 | P1 | Source/build/API/setup/test report/APK tidak disediakan kit | Di tahap implementasi sediakan project lengkap, env example, migrations/API docs, setup, signed-release guide, debug APK dan evidence test | 3–6; Engineering + QA |
| G31 | P2 | Forecast/CCC/ABC/production belum tersedia | Asumsi forecast, horizon, source, historical comparison; DIO/DSO/DPO valid denominators; costing/cash impacts traceable | 5; Financial + Backend |
| G32 | P2 | Dark mode hanya config; banyak kartu sama bobot | Light premium lebih dahulu, max 1–2 chart dominan per viewport; dark hanya setelah contrast QA dan reduced motion | 2/6; UX |
| G33 | P2 | Inventory docs self-size salah; phase numbering berbeda | Manifest aktual disertakan, Tahap pengguna jadi urutan kerja; koreksi audit pajak terdahulu tercatat dalam audit baru | 1; Product — koreksi audit selesai, sumber asli tidak diubah |

## Gate praktis

Sebelum prototype dianggap selesai: G06, G09, G15–G21, G27–G28 harus terpenuhi untuk **interaksi DEMO**. Sebelum transaksi MVP dianggap selesai: seluruh P0 terkait use case tersebut dan G12/G24/G25 yang menjadi dependensinya harus lulus end-to-end. Tidak menunggu semua fitur lanjutan untuk mendesain UI, tetapi tidak boleh menyatakan fitur lengkap dengan stub backend.

Gap konfigurasi (belum keputusan user): fiscal period, accounting policy, household ownership, essential spending basis, score rules, fee/attribution, inventory policy, tax/depreciation profile, approval thresholds, retention/RPO/RTO. Lihat MODULE_MAP bagian 6. Tarif pajak dan kelayakan tidak diasumsikan dari HTML.
