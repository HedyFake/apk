# BFI — Audit Paket dan Enam Referensi

Tanggal: 4 November 2026, Asia/Jakarta. Status: **Tahap 1 selesai; implementasi aplikasi belum dimulai.**

## 1. Kesimpulan

Paket cukup sebagai fondasi arah produk dan visual, tetapi bukan aplikasi berjalan. Seluruh 34 file telah diperiksa: 4 Markdown root, 13 dokumen `docs/`, 5 prompt, 6 HTML, dan 6 screenshot. Seluruh HTML dibaca sampai akhir dan seluruh PNG dibuka secara individual. Tidak ditemukan proyek Flutter/.NET, database, migration, API, autentikasi, test suite, APK, atau aset logo lokal dalam paket.

Identitas navy/teal/ice-blue, pemisahan kas pribadi–bisnis, angka tabular, pasangan health gauge, dan struktur laporan layak dipertahankan. Model interaksi, definisi angka, aksesibilitas, data demo, dan seluruh fondasi transaksi harus dibangun ulang secara bertahap. **Tidak satu pun fitur finansial dapat dinyatakan selesai menurut definisi selesai pengguna.**

Temuan penghambat utama:

1. Rumus contribution di dokumen finansial mengurangi diskon penjual dua kali bila `Net Sales` dipakai sesuai definisinya.
2. Contoh jurnal pelunasan invoice pada dua HTML mengkredit pendapatan, padahal untuk invoice yang sudah diakui sebagai piutang harus mengkredit piutang.
3. Penyusutan non-cash tercampur ke potensi penghematan cash tahunan dalam Intelligence Center; denda kartu corporate juga tidak diberi batas entitas yang jelas.
4. Label `Audited`, `SAK EMKM Valid`, `DJP Tax Ready`, `Real-time`, dan sukses simpan/post/ekspor tidak didukung proses yang tersedia.
5. Navigasi tidak memiliki route nyata; filter dan tombol hanya mengubah DOM atau tidak memiliki handler.

Koreksi terhadap audit bawaan: penurunan laba Rp2.275.000 **dapat direkonsiliasi** sebagai penyusutan Rp1.562.500 + pajak ilustratif Rp712.500. Ini bukan kesalahan penjumlahan. Masalahnya adalah label gabungan penyesuaian, asumsi bahwa penyusutan belum masuk EBT, serta tidak adanya pembaruan ledger/laporan.

## 2. Otoritas, metode, dan batas audit

Permintaan pengguna menentukan pekerjaan saat ini: audit dan product mapping terlebih dahulu. `MASTER_PROMPT_CHATGPT.md` serta `prompts/` dibaca sebagai bahan spesifikasi, bukan perintah untuk langsung mengeksekusi tahap berikutnya. Klaim dalam `docs/01_REFERENCE_AUDIT.md` diverifikasi terhadap file asli; tidak diperlakukan sebagai hasil audit baru.

Urutan penyelesaian konflik: pemisahan entitas, integritas akuntansi, keamanan, definisi finansial; kemudian visual mengikuti `docs/04` dan `docs/05`. Konflik di dalam rumus sendiri dicatat dan diselesaikan dengan invariant anti-double-count, bukan disalin secara literal.

Metode: inventaris ZIP rekursif, ekstraksi lokal tanpa mengubah sumber, pembacaan penuh 22 Markdown dan 6 HTML dengan nomor baris, inspeksi visual individual 6 PNG, pemeriksaan statis handler/dependensi, serta rekonsiliasi aritmetika data contoh. Nomor baris HTML di laporan mengacu file asli, bukan hasil formatter. `S1` sampai `S6` adalah alias dalam tabel berikut.

Interaksi di bawah disimpulkan dari kode handler; **belum diuji klik dalam browser**. Tidak dilakukan pengujian Android, backend, aksesibilitas dengan screen reader, pengukuran kontras, performa, atau kepatuhan pajak. Screenshot sumber bukan capture APK dan ukurannya bukan ukuran dp perangkat. Tidak ada penetapan tarif atau kelayakan skema pajak nyata; seluruh angka finansial yang dibahas adalah **DEMO referensi**.

Sumber ZIP: `BFI_Design_Development_Kit.zip`, 1.329.209 byte. SHA-256: `728C2FDE5C04DBEF9C60ACF90BFCE0F18A84AB2D19F124BC033712D50E4EDB37`.

Lihat `FILE_AUDIT_MANIFEST.json` untuk path, ukuran, hash SHA-256 setiap file, metode inspeksi, dan dimensi PNG. Sumber diekstrak di `work/package/BFI_Design_Development_Kit/`.

## 3. Register seluruh dokumen yang diperiksa

Semua path relatif terhadap root paket. Status setiap baris: **dibaca penuh**.

| File | Peran dan hasil pemeriksaan |
|---|---|
| `README.md` | Pintu masuk; tegas menyatakan referensi bukan aplikasi produksi. Daftar urutan baca belum mencantumkan docs/13 walaupun tree memuatnya. |
| `MASTER_PROMPT_CHATGPT.md` | Misi, invariant, stack, tahapan, definisi selesai; menjadi konteks spesifikasi, tidak memicu coding pada audit ini. |
| `DESIGN_BRIEF_CHARTS_AND_UI.md` | Identitas dan visual wajib; mayoritas chart masih berupa kebutuhan masa depan. |
| `PACKAGE_INVENTORY.md` | Seluruh 34 path cocok dengan arsip; ukuran dirinya tertulis 2.575 byte, aktual 2.668 byte. Ketidaksesuaian metadata minor. |
| `docs/01_REFERENCE_AUDIT.md` | Audit terdahulu; temuan logo/demo terkonfirmasi, dugaan selisih pajak perlu dikoreksi seperti bagian 1. |
| `docs/02_PRODUCT_VISION_AND_MODULES.md` | Sembilan modul; kategori utama dan secondary tags harus dipisah; personal/household tetap ledger berbeda. |
| `docs/03_INFORMATION_ARCHITECTURE.md` | Lima item bottom bar, jalur transaksi dan role; pembayaran gaji perlu membedakan pengakuan beban vs pelunasan utang gaji. |
| `docs/04_VISUAL_DESIGN_SYSTEM.md` | Sumber token, 360–430 dp, body penting ≥14sp, label ≥12sp, radius 14–18 dp; HTML belum mematuhi seluruhnya. |
| `docs/05_DASHBOARD_CHARTS_AND_PERCENTAGES.md` | Kamus chart/KPI; istilah `available credit limit` ambigu dan berkonflik dengan total credit limit di docs/07. |
| `docs/06_FEATURE_CATALOG.md` | 100 fitur dengan P0/P1/P2; prioritas tidak identik dengan tahap pelaksanaan. Tidak ada bukti 100 fitur tersebut terimplementasi. |
| `docs/07_FINANCIAL_RULES_AND_FORMULAS.md` | Rumus/invariant; double diskon, tanda kurung DSR, basis proceeds, batas fee, dan definisi cash spending perlu dinormalisasi. |
| `docs/08_LEDGER_DATA_MODEL_AND_WORKFLOWS.md` | Tenant/entity, immutable journal, mirror, sync; masih model konseptual, belum schema/migration atau protokol konflik konkret. |
| `docs/09_TECHNICAL_ARCHITECTURE.md` | Feature-first Flutter dan enam proyek backend; DTO, idempotency, online posting; belum ada source yang mewujudkan struktur ini. |
| `docs/10_SECURITY_PRIVACY_AND_AUDIT.md` | Membership setiap request, token, enkripsi, audit, restore; semua masih persyaratan. |
| `docs/11_ROADMAP_TESTS_AND_ACCEPTANCE.md` | Acceptance dan contoh uji; penomoran fase berbeda dari permintaan. Contoh maksimum subsidi Rp39.000 benar untuk asumsi nominal terbatas. |
| `docs/12_FILE_AND_FOLDER_MANIFEST.md` | Tujuan setiap folder; menegaskan tidak ada logo lokal dan HTML bukan Flutter. |
| `docs/13_SCREEN_BY_SCREEN_REDESIGN.md` | Struktur target enam layar dan tindakan; belum merupakan layar hasil implementasi. |
| `prompts/01_PROMPT_AUDIT_REFERENSI.md` | Output audit, traceability dan gap. Output tersebut disertakan bersama MODULE_MAP yang diminta pengguna. |
| `prompts/02_PROMPT_DESAIN_ULANG_UI_UX.md` | Kebutuhan Tahap 2: token, reusable widgets, route, chart dan states; belum dieksekusi. |
| `prompts/03_PROMPT_BANGUN_MVP_ANDROID.md` | Cakupan MVP termasuk stock ledger sederhana; perlu dibedakan dari inventory lanjutan Tahap 5. |
| `prompts/04_PROMPT_FINANCIAL_ENGINE.md` | Rencana engine deterministik dan edge-case tests; tidak ada implementasi dalam paket. |
| `prompts/05_PROMPT_QA_DAN_VALIDASI.md` | Rencana QA/release; bukan bukti tes atau build pernah dijalankan. |

## 4. Register 12 file referensi

Prefix seluruh path: `reference/stitch_bfi_financial_intelligence_platform/`. Kedua file setiap baris diperiksa terpisah: HTML dibaca penuh, PNG dibuka dan dilihat langsung.

| ID | Folder | File HTML | File visual | Dimensi PNG |
|---|---|---|---|---|
| S1 | `bfi_command_center_overall` | `code.html`, 352 baris | `screen.png` | 305 × 1600 px |
| S2 | `keuangan_pribadi_household` | `code.html`, 425 baris | `screen.png` | 318 × 1600 px |
| S3 | `pak_tung_intelligence_center` | `code.html`, 359 baris | `screen.png` | 292 × 1600 px |
| S4 | `keuangan_bisnis_smart_pricing` | `code.html`, 318 baris | `screen.png` | 415 × 1600 px |
| S5 | `laporan_keuangan_akuntansi_bisnis` | `code.html`, 506 baris | `screen.png` | 210 × 1600 px |
| S6 | `simulasi_penyusutan_pajak_umkm` | `code.html`, 622 baris | `screen.png` | 160 × 1600 px |

## 5. Audit per layar

### S1 — Overview / Command Center

**Tujuan dan modul:** ringkasan lintas ranah tanpa mencampur saldo; Overview, Financial Health, Accounts, Relationships, Obligations, Reconciliation.

**Hasil inspeksi visual:** header logo rusak memakan ruang kiri, selector bulan/notifikasi/avatar di kanan; dua kelompok tab bertumpuk; banner navy pemisahan rekening; dua kartu kas vertikal, lalu banner anti-double-count; twin gauges baru muncul setelah beberapa blok. Health gauges berdampingan, kartu relasi dan empat tagihan memanjang, action verifikasi di bawah. Latar ice dan white cards konsisten, tetapi judul panjang membungkus dan banyak teks mikro. Nominal utama kuat, prioritas kesehatan kurang cepat terlihat.

**Pertahankan:** dua saldo independen, ring skor 0–100, pemisahan tagihan, owner loan sebagai piutang pribadi/liabilitas bisnis, inbox reimbursement, lima item bottom bar.

**Tingkatkan:** pindahkan twin gauges ke hero; ring detail berisi bobot/threshold/formula version/completeness. Liquidity: tampilkan available/reserved/held, entitas dan as-of; dua kolom hanya jika nominal terbaca, stack pada font scaling. Tambahkan tren enam bulan, status paired/unmatched, filter kewajiban 7/14/30 hari. Scope tabs tunggal; jangan duplikasi navigasi atas dan bawah.

**Interaksi terbukti di kode:** `switchScope` (339–351) hanya mengganti class tab. Konten tidak difilter. Verifikasi Nota/Tolak (327–332), periode, notifikasi dan header tidak punya handler bisnis. Bottom nav (352) semuanya `href="#"`.

**Bug/gap:** `Real-time` (51), `Anti-Double-Count Active` (122), skor 78/84 dan status sehat tidak dibuktikan logic. Klaim target aman Pak Tung 60–70% (190) tidak memiliki sumber/konfigurasi. Kas perusahaan Rp20 juta adalah PT Mitra Sukses, sedangkan S4 memakai PT Mitra Niaga Nusantara: jangan otomatis menyamakan entitas. Jadwal hanya tanggal tanpa tahun/as-of. Tidak ada setoran modal, detail pasangan jurnal atau receipt workflow nyata.

### S2 — Personal & Household

**Tujuan dan modul:** kekayaan, kas masuk/keluar, kategori, rekening/kartu, dana darurat dan quick input; Personal, Household, Transactions, Budget, Accounts, Assets/Loans.

**Hasil inspeksi visual:** hero net worth navy dominan; tiga KPI kecil sejajar, dana darurat berupa bar, income dan spending berupa deretan kartu penuh lebar. Tidak terlihat donut income/spending atau garis tren. Lima kartu spending ditampilkan di bawah judul “6 Kategori”. Kartu rekening rapi tetapi label panjang berdesakan dengan uang; input nominal berada jauh di bawah. Tab atas tetap menyorot Gambaran Menyeluruh sementara bottom bar menyorot Pribadi.

**Pertahankan:** net worth hero, pemisahan realized/unrealized, rekening dan outstanding kartu, target darurat dengan nominal, input cepat dan chip kategori.

**Tingkatkan:** selector personal/household eksplisit, tanggal valuasi dan basis aset, empat KPI, income/spending donut, passive coverage ring, savings trend, net-worth line, emergency ring dan budget bars; transaksi terkini dan form berlabel entitas/akun/tanggal/jenis. Gunakan satu kategori utama dengan secondary tags independen. Input global tetap mudah dijangkau lewat bottom action.

**Interaksi kode:** chip mengubah pilihan lokal; Simpan hanya memeriksa nominal >0, membuat teks toast, menutupnya setelah 3,2 detik (389–424). Tidak membuat transaksi, mengubah saldo, menyimpan lokal, atau melakukan sync. Teks “Realtime Disinkron” (385) tidak benar sebagai status operasi. Kelola Akun inert.

**Bug/gap:** lima kategori (197–266), bukan enam; emergency progress 91,6% (112) seharusnya 91,7% pada pembulatan satu desimal dari 5,5/6. Cadangan kas dan daftar rekening Rp65 juta tetapi eligible emergency Rp66 juta tanpa penjelasan aset tambahan. Health 86/100 vs S1 78 tidak punya identitas skor/scope yang menjelaskan perbedaan. S2 dapat mewakili household berbeda; ini gap koherensi, bukan bukti saldo salah antar entitas. “Bad debt 0%” tidak memiliki denominator. Kartu kredit belum punya workflow bayar pokok kewajiban tanpa expense ulang.

### S3 — Pak Tung Intelligence Center

**Tujuan dan modul:** refleksi income/spending berbasis angka; Intelligence, KPI Definitions, Recommendations, Subscriptions, Goals.

**Hasil inspeksi visual:** disclaimer pale-blue, hero navy dengan angka 50% dan ikon (bukan radial gauge), tiga KPI kecil, tiga pilar pendapatan, dua comparative bars Gajah/Kerbau, panel merah potensi penghematan, empat kebocoran, dua CTA, kutipan. Informasi rapat; teks SOP/nonaktif sangat pucat; kode internal `Sec 4.17 • P07-P22` terlihat ke pengguna. Tidak ada income donut atau tren savings.

**Pertahankan:** disclaimer, tiga pilar, penanda realized/unrealized, comparative bars dengan nominal, daftar tindakan review.

**Tingkatkan:** namai hero “Cakupan biaya esensial oleh pendapatan pasif”; nominal Rp/periodenya dan gap sejajar. Ganti klaim bebas finansial menjadi target coverage edukatif. Pisahkan cash leakage, non-cash value loss, potential savings dan realized savings. Tampilkan entity, sumber, as-of, formula, confidence dan status verifikasi tiap rekomendasi. Hapus kutipan verbatim yang tidak bersumber atau gunakan parafrasa tanpa klaim atribusi terverifikasi.

**Interaksi kode:** Batalkan (286) hanya `alert`; Tinjau Langganan dan Alokasi Produktif (342–348) hanya animasi scale dan timeout 150ms. Tidak membatalkan layanan atau mengalokasikan dana.

**Bug/gap:** Rp26,3 juta total pilar memasukkan Rp3,8 juta unrealized; perlu switch cash/all portfolio dan label non-cash, bukan total uang masuk. Rp9,6 juta/tahun berasal dari seluruh Rp800 ribu termasuk Rp477.500 depresiasi/bulan. Cash items yang tersisa Rp322.500; bahkan annualisasi Rp3,87 juta memerlukan asumsi recurring, periode dan entitas sama, serta verifikasi, bukan otomatis klaim hemat. Denda corporate harus dipisahkan dari household. Savings 36,8% tidak cocok pembulatan satu desimal 8,3/22,5 = 36,9% jika menggunakan basis S2. Threshold fixed expense <40%, “bebas waktu”, “100% Bebas Finansial” dan target investasi tidak boleh jadi klaim universal. Tidak ada basis net setelah biaya untuk passive income.

### S4 — Business Finance & Smart Pricing

**Tujuan dan modul:** profit bisnis, unit economics dan likuiditas; Business, Pricing, Inventory/COGS, Ads, AR/AP, Cash Forecast.

**Hasil inspeksi visual:** entity banner, dua KPI nominal berdampingan, empat baris ringkasan, kalkulator sebagai kartu terbesar, A/B buttons, grid biaya, output/feedback teal, dua kartu AR/AP, kas/runway. Angka penjualan mendekati batas kartu; informasi jatuh tempo terpotong dengan ellipsis; label rekening dan nominal berhimpitan. Tidak ada waterfall, margin gauge, chart ROAS, aging atau forecast; “Aging Status” hanya label.

**Pertahankan:** konteks bisnis, label Provisional, perincian biaya, scenario comparison, target/buffer, ringkasan AR/AP dan rekening.

**Tingkatkan:** KPI net sales/gross/contribution/net dibedakan; waterfall plus rincian; pricing form editable dengan fee nominal/persen/base/cap, diskon, ads, ongkir; skenario A/B/C dapat disimpan; rekomendasi hanya draft. ROAS dengan attributed sales, attribution window dan BEP yang tepat; due aging buckets, held payout, reserved cash dan runway basis.

**Interaksi kode:** `setScenario` (246–309) menetapkan string tetap Rp30.000/Rp42.000, biaya/laba/status. `toggleQuickScenario` (311–317) memilih A/B. Bukan engine input-driven. Tidak ada input harga/fee/SKU atau persist scenario.

**Bug/gap:** kasus B menghasilkan laba positif Rp12.000, kurang target Rp3.000; warna merah tidak boleh menyiratkan rugi. Maksimum subsidi yang memenuhi target dari asumsi tersebut Rp39.000, bukan rekomendasi “maksimal Rp30.000” (304); Rp30.000 boleh dijelaskan sebagai buffer konservatif, bukan batas matematis. Harga Rp153.000 cocok hanya untuk biaya nominal yang ditampilkan. Status AMAN tidak valid jika fee/ads belum diketahui. Contribution Rp38,2 juta belum direkonsiliasi dengan Rp42,4 juta S5; attributed subset mungkin berbeda tetapi tidak diberi definisi. ROAS 4,8x/BEP 2,2x tidak punya basis sebanding; jangan gunakan gross margin sebagai contribution before ads. Runway 4,8 bulan tanpa burn/window. `text-on-secondary-variant` (160, 281) bukan token warna yang didefinisikan.

### S5 — Financial Reports & Accounting

**Tujuan dan modul:** laporan dan penelusuran transaksi; Accounting, Ledger, Reporting, Approval, Audit/Export.

**Hasil inspeksi visual:** workspace, periode/ekspor dan pills, banner integrity, laporan P&L panjang, neraca sangat panjang, cash flow, dua journal cards, diagnostic di bawah. Nama perusahaan terpotong; ukuran sumber 210px menunjukkan capture keseluruhan yang diperkecil, bukan ukuran perangkat. Struktur subtotal serta angka kanan membantu pembacaan, tetapi semua laporan satu halaman memberi beban scroll tinggi. Tidak ada chart dan jurnal bukan tabel semantik.

**Pertahankan:** struktur subtotal laporan, A=L+E, cash opening-to-closing, entitas/periode, reference jurnal, debit/kredit.

**Tingkatkan:** tabs P&L/BS/CF/TB/GL/Journals; satu laporan fokus, visual ringkas + tabel accessible, compare period, sumber transaksi, actor/reason, variance numerik, jurnal draft/review/approve/post/reverse, status proses yang berbeda. Export file nyata ber-watermark entitas/periode/DEMO dan tercatat audit.

**Interaksi kode:** `switchTab` (461–494) benar-benar show/hide empat section statis di DOM; tidak meng-query atau menghitung ulang. Export (496–505) hanya mengganti label “Mengunduh...” → “Tersimpan (PDF)” via timeout; tidak menghasilkan file. Tinjau tidak punya handler.

**Bug/gap kritis:** jurnal #JRN-2026-0890 (419–434) berjudul pelunasan invoice tetapi Cr Revenue. Dengan basis akrual dan invoice yang telah diakui, harus Dr Cash / Cr AR; bila itu penjualan tunai baru, judul/source harus berbeda. D=K tidak membuktikan klasifikasi benar. Total jurnal Rp418,5 juta dan “0 Unposted” tidak dapat diverifikasi dari dua snippet.

**Gap lain:** “Audited”, “SAK EMKM Valid” tanpa proses; EBT diberi Net Margin tanpa kualifikasi pre-tax; diagnostic menyebut Rp21,8 juta sebagai budget iklan padahal P&L menggabungkan selling+ads dan S4 ads Rp18,5 juta. “Metode Langsung (Cash Accounting)” mencampur metode penyajian cash flow dengan basis akuntansi. Saran pajak konstan tanpa profil. Seluruh laporan 1–30 November dan jurnal 30 November adalah tanggal DEMO, bukan data aktual per tanggal audit 4 November.

### S6 — Fixed Assets, Depreciation & Tax

**Tujuan dan modul:** aset tetap, jadwal, simulasi dan adjustment terkontrol; Fixed Assets, Tax Rules, Accounting/Approvals. Referensi aktual merupakan perluasan S5, bukan workspace aset terpisah.

**Hasil inspeksi visual:** seluruh laporan S5 diulang; kartu penyesuaian berada sangat jauh di bawah. Dua blok depresiasi/pajak, pasangan jurnal dan impact summary diikuti tombol post penuh lebar. Sumber 160×1600 px sangat kecil; label dan angka rinci dibaca silang dengan HTML. Tidak ada register, chart nilai buku, profile selector, tanggal akuisisi atau schedule.

**Pertahankan:** preview Dr/Cr, nilai buku sebelum/sesudah, impact summary dan simulasi terpisah secara konsep.

**Tingkatkan:** jadikan route sendiri dengan profile legal/taxpayer/jurisdiction/effective period; register, residual/useful life/method, accounting vs fiscal book, line schedule + tabel. Rule version/source/configuration date, data completeness, due date, preview impact berlabel. Workflow Review → Approve → Post online, permissioned, idempotent dan ber-audit; tidak mengklaim filing/e-billing sudah tersedia.

**Interaksi kode:** tombol post (550) hanya mengganti `innerHTML` dan class menjadi sukses; tidak validasi, approval, database atau ledger. Export tetap timer. Tab `adj` ada (65–67), tetapi `tabs` dan `sections` (578–595) tidak memuatnya. Akibat kode: klik Penyesuaian menyembunyikan empat laporan; kartu adjustment tetap tampil karena tidak dikelola, dan active tab tidak tersetel. Saat memilih P&L, adjustment juga tetap tampil.

**Temuan finansial:** 75.000.000 × 25% / 12 = 1.562.500; 65.000.000 − 1.562.500 = 63.437.500; angka pajak DEMO 142.500.000 × 0,5% = 712.500; 24.800.000 − 1.562.500 − 712.500 = 22.525.000. Penjumlahan benar dengan asumsi dua penyesuaian baru. Label “Dampak ke laba setelah pajak” perlu menjelaskan keduanya, memastikan depresiasi belum tercatat, serta meng-update neraca dan equity dari jurnal. Tanpa itu dapat terjadi double posting/double expense. Header “Tarif ... Bruto” berlawanan dengan label dasar “Omzet Bersih”; validitas basis/peraturan **belum dinilai**. `DJP Tax Ready`, `Siap Bayar e-Billing`, metode/masa manfaat fiskal tetap tidak didukung konfigurasi atau integrasi.

## 6. Temuan lintas layar dan keputusan normalisasi

| ID | Konflik/bukti | Keputusan audit untuk spesifikasi berikutnya |
|---|---|---|
| F01 | docs/07: Net Sales sudah net diskon, Contribution baris 79 mengurangi Seller Discount lagi; proceeds baris 99 juga ambigu | NetSales = Gross − seller discount − return; ContributionBeforeAds = NetSales − COGS − variable selling/fulfillment. Diskon yang sudah di-net tidak dikurangi lagi. Fees yang dipotong settlement direkonsiliasi terpisah agar tidak dua kali expense. |
| F02 | docs/07:41 DSR tanpa tanda kurung | `(ScheduledPrincipal + ScheduledInterest) / RecurringNetIncome × 100%`. Nol/unknown denominator = N/A, bukan nol sehat. |
| F03 | docs/05:72 available credit limit vs docs/07 Credit Limit | Utilization memakai total approved limit, bukan remaining availability. Tampilkan outstanding/limit dan unused limit sebagai angka berbeda. |
| F04 | docs/07 emergency progress dicap 100%; docs/05 memperbolehkan overflow | Pisahkan `rawCoverage` dan `visualProgress=min(raw,1)`; teks tetap menampilkan bulan aktual serta over-target. |
| F05 | Cash/all portfolio donut bisa mencampur gain negatif/non-cash | Cash default; unrealized tabel/seri non-cash terpisah. Donut hanya positive part-to-whole; saat loss/negative component gunakan bar/tabel, bukan segmen negatif. |
| F06 | Lima kategori vs tujuh istilah perilaku | Lima primary: Produktif, Direct, Passive, Invisible, Giving; dua dual-perception sebagai tags. Tambahkan Unclassified bila perlu. Reporting akuntansi berdasarkan akun, bukan asumsi semua “produktif” adalah aset. |
| F07 | Payroll diagram/pola gaji dapat dibaca sebagai beban dua kali | Pengakuan payroll Dr Expense/Cr Payable; pelunasan Dr Payable/Cr Cash. Pembayaran langsung hanya sekali Dr Expense/Cr Cash bila belum accrued. Pasangan personal mengikuti income/account basis. |
| F08 | docs/11 memakai Phase 0–6; user Tahap 1–6; katalog P0 sangat luas | Gunakan Tahap pengguna. Prioritas fitur bukan bukti selesai dan bukan urutan build. Basic inventory diperlukan sebelum mengklaim penjualan SKU dengan HPP aktual; advanced inventory di Tahap 5. |
| F09 | Harga required price sederhana | Berlaku hanya fee linear atas base yang sama dan total rate <100%. Base gross/net, tier, cap, tax, discount harus eksplisit; kondisi invalid/incomplete tidak diberi hasil aman. |

Temuan teknis bersama: enam HTML memakai Tailwind CDN, Google Fonts/Material Symbols, logo Googleusercontent tanpa fallback. `surface-dim: "cadde8"` kehilangan `#`. Font `label-sm`/`code-sm` 11px, beberapa label gauge 10px; referensi target meminta minimal 12sp dan body penting 14sp. `rounded-full` dikonfigurasi 0,75rem, sehingga nama utility tidak selalu bermakna lingkaran; jangan adopsi token itu untuk circle. Meta viewport melarang zoom, ikon tombol tanpa accessible name yang memadai, status banyak bergantung warna, dan belum ada alternatif tabel chart/semantic summary yang lengkap. Dark-mode config bukan bukti tema gelap yang telah didesain/diuji. Header tetap menyorot Overview di semua halaman; dua laporan tidak menandai bottom destination aktif.

Tidak ditemukan pola fetch/XHR, localStorage/IndexedDB, import transaksi, server posting, atau download file pada kode aplikasi inline. Dependensi jaringan yang ada adalah presentasi, bukan API finansial. Data tampil sebagai literal dan tidak diberi watermark DEMO yang konsisten. Seluruh demo baru harus berasal dari seed terpisah yang koheren, tidak mengimpor angka screenshot menjadi akun pengguna.

## 7. Batas keluaran dan langkah berikut

Audit menghasilkan `AUDIT_REPORT.md`, `MODULE_MAP.md`, `DESIGN_GAP_LIST.md`, `MODULE_TRACEABILITY_MATRIX.md`, `AUDIT_TEST_REPORT.md`, dan `FILE_AUDIT_MANIFEST.json`. Tidak dibuat source fitur, migration, APK, atau screenshot aplikasi baru pada Tahap 1.

Tahap 2 dapat menggunakan peta modul dan gap sebagai baseline: desain komponen dan navigasi DEMO dengan kontrak KPI yang benar; fitur yang belum terhubung backend harus menyatakan statusnya. Tahap 3 harus membuktikan journal invariants dan isolasi entitas sebelum Tahap 4 mengklaim transaksi end-to-end. Detail gate, test dan keputusan konfigurasi ada di dokumen pendamping. Audit selesai bukan persetujuan produksi, validasi hukum pajak, atau kelulusan aplikasi.
