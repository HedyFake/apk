# REST API v1

Base: `https://your-server/api/v1`. JSON camelCase, IDR integer tanpa floating point untuk jurnal. Semua endpoint selain auth memerlukan `Authorization: Bearer <token>`. Token random hanya disimpan sebagai hash di PostgreSQL. Akun database/query di-scope menurut user yang berasal dari token, bukan userId kiriman klien.

| Method/path | Input / hasil |
|---|---|
| `POST /auth/register` | `{ "email": "...", "password": "..." }` → token, userId, expiresAt; tiga ledger kosong |
| `POST /auth/login` | Kredensial → token 30 menit |
| `GET /entities` | ID personal, household, business |
| `GET /journals` | Seluruh jurnal pengguna; setiap jurnal memiliki entityId dan lines |
| `POST /transactions` | DTO berikut; header Idempotency-Key harus sama dengan id |
| `POST /journals/{id}/reverse` | `{ "reason": "Alasan minimal 5 karakter" }`; pasangan owner loan dibalik atomik |
| `GET /reports/{entityId}?month=2026-11` | Saldo akhir periode, debit/kredit periode, profit, asOf, formulaVersion |
| `GET /audit` | Maksimal 500 audit event terbaru milik pengguna |
| `GET /health` (di luar `/api/v1`) | Status proses; bukan readiness database |

Contoh transaksi (ganti tanggal dengan tanggal valid hari ini/masa lalu):

```json
{
  "id": "client-generated-unique-id",
  "entityId": "personal",
  "date": "2026-11-05",
  "kind": "active",
  "category": "direct",
  "note": "Pendapatan proyek",
  "amount": 1000000,
  "cost": 0,
  "sourceId": ""
}
```

Jenis: `active`, `passive`, `expense`, `reserve`, `card_purchase`, `card_payment`, `loan_receive`, `loan_repay`, `interest`, `stock`, `sale`, `invoice`, `collect`, `supplier`, `pay_supplier`, `owner_loan`.

- Penjualan/invoice memerlukan HPP `cost > 0` dan stok nilai buku cukup. Ini HPP manual, belum quantity costing FIFO.
- Pelunasan `collect`/`pay_supplier` memerlukan `sourceId` jurnal invoice/supplier dan tidak boleh melebihi outstanding.
- `owner_loan` hanya dimulai dari personal; server membuat jurnal personal dan business dengan pairId sama, dalam satu transaction.
- Pinjaman tidak dikreditkan ke pendapatan. Pembayaran kartu tidak mendebit beban lagi.
- Server memvalidasi ulang semua data. Mutex transaksi per user + idempotency melindungi retry konkuren. ID sama dengan payload berbeda ditolak.
- Koreksi merupakan insert reversal, bukan DELETE/UPDATE. Alasan wajib; jurnal yang sudah memiliki settlement membutuhkan review. API publik tidak menyediakan delete journal.
- `accounting_periods.closed=true` menolak posting periode terkait; UI closing/approval multi-role belum tersedia.

Status: 200 sukses (termasuk duplicate retry); 401 token/kredensial; 409 duplikasi data; 422 validasi; 429 auth rate limit; 500 kegagalan tak terduga dengan traceId. Respons error tidak menyatakan posting berhasil. Retry selalu dengan ID yang sama. Skema v1 belum memakai pagination, refresh token atau OpenAPI generator; dokumentasi ini menggambarkan endpoint yang tersedia.
