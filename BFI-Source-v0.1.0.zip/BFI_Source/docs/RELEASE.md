# APK evaluasi dan release signing

Build yang diserahkan adalah **debug APK**, package `id.bfi.bfi_mobile`, version 0.1.0+1. Cocok untuk mengevaluasi UI dan ledger DEMO. Belum release produksi atau unggahan Play Store.

## Instalasi APK

Salin APK ke ponsel Android, buka melalui Files, lalu izinkan pemasangan dari aplikasi sumber tersebut jika Android meminta. Buka **BFI**. Label DEMO menandai data contoh. Untuk update debug gunakan sertifikat debug yang sama; konflik signature memerlukan paket berbeda atau uninstall, yang menghapus data lokal.

## Signing produksi

1. Selesaikan gap keamanan/operasional dan QA perangkat pada `LIMITATIONS.md`.
2. Buat upload keystore sendiri, simpan di lokasi aman di luar repository, cadangkan secara terenkripsi. Jangan kirim password/keystore melalui chat atau commit.
3. Buat `android/key.properties` lokal (sudah di-ignore) dengan `storeFile`, `storePassword`, `keyAlias`, `keyPassword`.
4. Gradle sudah membaca `signingConfigs.release` dari berkas tersebut dan menolak task release tanpa empat nilai signing yang lengkap. Jangan menyamakan APK debug yang ada dengan release signed.
5. Naikkan versionName/versionCode, lalu jalankan `flutter build appbundle --release` dan verifikasi sertifikat bundle/APK. Lakukan backup/restore, security review dan uji perangkat sebelum distribusi.

Tidak ada fallback debug signing pada task release. Tidak ada keystore, password signing atau secret server di paket source yang diserahkan. APK debug memiliki tanda tangan debug hasil toolchain Android, bukan identitas signing produksi pemilik proyek.

## Smoke test perangkat yang perlu dilakukan

- Buka app, cek logo, navigasi/back, rotasi, keyboard dan font besar.
- Catat expense DEMO lalu force-stop/reopen; lihat saldo dan jurnal tetap tersimpan.
- Bayar invoice sebagian, pastikan outstanding turun tanpa income bertambah lagi.
- Buat pinjaman pemilik, cek kedua ledger; reversal mengembalikan keduanya.
- Simpan CSV dengan Android document picker dan buka hasilnya.
- Hubungkan server HTTPS uji, daftar akun kosong, cek isolasi DEMO, antrean offline/retry/idempotency dan error token kedaluwarsa.

Tidak ada bank/payment/investment action otomatis. APK tidak menyertakan backend publik.
