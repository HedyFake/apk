# Setup pengembangan

## Toolchain yang dipakai

- Flutter 3.47.9 stable / Dart 3.13.7; JDK 17.
- Android SDK platform 36, Gradle 9.3.1; versi Android Gradle Plugin mengikuti `android/settings.gradle.kts`.
- .NET SDK 10.0.403; Npgsql 10.0.0; PostgreSQL 17 (sesuai compose).
- Dependensi Flutter terkunci di `pubspec.lock`. Internet diperlukan untuk pengunduhan pertama.

Pasang SDK resmi, tambahkan `flutter`, `dotnet`, dan Java ke PATH, lalu jalankan `flutter doctor`. Pada Windows gunakan lokasi proyek/SDK pendek agar tidak mengenai batas panjang path. Jalur SDK mesin pembuat tidak disertakan sebagai konfigurasi portabel.

## Android

```powershell
cd bfi_mobile
flutter pub get
flutter analyze
flutter test test/financial_test.dart
flutter build apk --debug
```

Hasil default: `build/app/outputs/flutter-apk/app-debug.apk`. APK universal lebih besar karena menyertakan beberapa arsitektur dan runtime debug. Untuk perangkat terhubung dengan USB debugging: `flutter devices`, lalu `flutter run` atau `adb install -r <path-apk>`. APK memakai ID `id.bfi.bfi_mobile` dan nama **BFI**.

## PostgreSQL dan API

Pilihan Docker (jika sudah terpasang):

```powershell
cd bfi_backend
$env:BFI_DB_PASSWORD = Read-Host 'Password database lokal'
docker compose up -d
$env:ConnectionStrings__Bfi = "Host=127.0.0.1;Port=5432;Database=bfi;Username=bfi;Password=$env:BFI_DB_PASSWORD"
$env:BFI_APPLY_MIGRATIONS = 'true'
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:ASPNETCORE_URLS = 'http://127.0.0.1:5080'
dotnet run
```

Alternatif: buat database/user PostgreSQL sendiri dan isi connection string. `.env.example` merupakan contoh; ASP.NET tidak otomatis membaca `.env`. Gunakan environment variables atau secret manager. Migrasi `migrations/001_initial.sql` dijalankan ketika flag true; pada deployment produksi jalankan migrasi terkontrol dengan akun migrator, lalu matikan flag tersebut. Jangan menjalankan API dengan akun superuser database di produksi.

HTTP localhost hanya untuk pengujian API di mesin pengembang. Aplikasi Android menolak URL non-HTTPS. Untuk ponsel, gunakan endpoint Kestrel HTTPS dengan sertifikat yang dipercaya Android atau deployment HTTPS yang dikonfigurasi benar. Backend memeriksa `Request.IsHttps`; terminasi TLS proxy memerlukan konfigurasi trusted proxy/forwarded headers yang belum disertakan. Jangan menonaktifkan pemeriksaan sertifikat untuk menghubungkan ponsel.

Di BFI: menu **Pengaturan & sinkronisasi**, masukkan URL dasar tanpa `/api/v1`, email dan password 12–128 karakter. **Daftar akun** membuat ledger kosong terpisah; data DEMO tidak diunggah. Setelah input, draft masuk antrean. Konfirmasi kirim di Pengaturan untuk posting server. Retry memakai ID yang sama agar tidak terjadi duplikasi; error validasi ditahan untuk review. Token berlaku 30 menit, lalu masuk lagi.

## Pengujian

```powershell
dotnet build
dotnet run --project tests/Bfi.FinancialTests.csproj
```

Flutter: `flutter test test/financial_test.dart` menguji ledger, pricing, SQLite reopen dan rollback. `flutter test test/screens_test.dart --update-goldens` merender seluruh layar pada 360/390/430 × 844; screenshot 390 px tersimpan di `test/screenshots`. Ini pengujian widget, bukan emulator Android. Lihat laporan tes untuk batas pengujian server/perangkat.

## Data

SQLite berada di application support directory Android dengan nama `bfi_v1.sqlite`. Tabel `journals` dipisahkan dengan kolom `mode` (`demo` atau namespace URL+user); antrean tidak dianggap saldo posted. Uninstall Android dapat menghapus data lokal. Backup/restore belum tersedia dan Android cloud backup dinonaktifkan. Jangan menjadikan build ini satu-satunya penyimpanan pembukuan nyata.
