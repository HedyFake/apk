# Laporan pengujian BFI 0.1.0

Tanggal: 5 November 2026. Status produk: **preview MVP, belum production-ready**.

## Hasil yang dijalankan

| Pemeriksaan | Hasil | Bukti / cakupan |
|---|---|---|
| Flutter domain + SQLite | **PASS 9/9** | Semua jurnal seed seimbang dan isolasi entitas; pinjaman; kartu kredit; invoice; owner loan; penolakan input; pricing; SQLite reopen/audit/namespace; rollback batch |
| Flutter layar | **PASS 3/3** | 10 halaman pada lebar 360, 390, 430 px × tinggi 844 px; navigasi, back dan scroll; tidak ada exception/overflow |
| Flutter alur transaksi | **PASS 1/1** | Form kosong ditolak; input expense → preview → konfirmasi → saldo berkurang → jurnal/audit tersimpan |
| .NET financial domain | **PASS 6/6** | Pinjaman, kartu kredit, invoice, dua sisi owner loan, invalid/future/overdraft, pricing |
| Analisis Flutter | **PASS** | Run final: no issues found; log disertakan |
| Build ASP.NET Core | **PASS** | Build ulang: 0 warning, 0 error; log disertakan |
| Build Android debug | **PASS** | Universal APK final terbentuk; apksigner memverifikasi signature, logo/font diverifikasi di dalam APK |
| Visual | **Diperiksa** | Screenshot widget Flutter 390 × 844, font Arial untuk renderer Windows; logo/Material icons lokal |

Log mentah yang disertakan di `evidence/` merupakan sumber hasil final. Screenshot adalah rendering Flutter test, **bukan screenshot emulator/perangkat fisik**. Pengujian layar menguji exception/overflow/navigasi dan menghasilkan baseline; tidak mengklaim perbandingan pixel terhadap desain Stitch.

## Temuan yang sudah diperbaiki

- Surface kartu memakai Material agar ink/sentuhan ListTile tidak tersembunyi.
- Header responsif: judul fleksibel, label bisa membungkus, periode memakai Wrap.
- Dropdown kategori di-reset ketika entitas berubah, sehingga kategori bisnis tidak tertinggal pada form personal.
- Kesalahan connect memulihkan state akun sebelumnya; namespace DEMO tidak tercampur server.
- Tanggal transaksi diperiksa dan tanggal seed tidak melewati hari ini.
- Neraca CSV menyertakan laba kumulatif dan pemeriksaan persamaan saldo.
- Font ikon dimuat dalam screenshot test; semua launcher icon berasal dari logo pengguna.
- Release build tidak memakai debug signing sebagai fallback dan ditolak jika signing belum dikonfigurasi.

## Belum dijalankan / tidak boleh dianggap lulus

| Pemeriksaan | Status |
|---|---|
| API integration end-to-end dengan PostgreSQL | **NOT RUN** — unduhan PostgreSQL portable gagal timeout; tidak ada database uji aktif yang digunakan |
| Eksekusi migration/trigger pada PostgreSQL, race/idempotency/tenant-isolation integration | **NOT RUN**; kode dan migration tersedia, butuh database uji |
| Instalasi/launch pada perangkat Android fisik atau emulator | **NOT RUN** |
| CSV lewat document picker Android, secure-storage plugin pada perangkat | **NOT RUN**; native Kotlin berhasil dikompilasi |
| Offline network failure/reconnect nyata, token expiry, TLS endpoint ponsel | **NOT RUN**; antrean/namespace diuji pada SQLite, belum network integration |
| Backup/restore, load/performance, pentest, TalkBack, OEM compatibility | **NOT RUN** |
| AAB release signing | **NOT RUN**; pemilik proyek harus menyediakan keystore sendiri |

13 tes Flutter dan 6 tes .NET tidak membuktikan seluruh brief selesai. Modul lanjutan dan dependensi produksi dijelaskan dalam `LIMITATIONS.md`; fitur tidak diklaim memenuhi Definition of Done produksi sebelum API/perangkat dan cakupan terkait lulus.
